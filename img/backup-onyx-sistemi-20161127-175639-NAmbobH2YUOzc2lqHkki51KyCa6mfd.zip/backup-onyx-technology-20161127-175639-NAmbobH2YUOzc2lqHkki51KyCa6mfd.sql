DROP TABLE IF EXISTS `otot_commentmeta`;

CREATE TABLE `otot_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_comments`;

CREATE TABLE `otot_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_comments` VALUES("1","1","Un commentatore di WordPress","wapuu@wordpress.example","https://wordpress.org/","","2016-10-03 15:37:30","2016-10-03 13:37:30","Ciao, questo è un commento.
Per iniziare a moderare, modificare e cancellare commenti, visita la schermata commenti nella bacheca.
Gli avatar di chi lascia un commento sono forniti da <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","","0","0");


DROP TABLE IF EXISTS `otot_itsec_lockouts`;

CREATE TABLE `otot_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_itsec_log`;

CREATE TABLE `otot_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_itsec_temp`;

CREATE TABLE `otot_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(60) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_links`;

CREATE TABLE `otot_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_microblogposter_accounts`;

CREATE TABLE `otot_microblogposter_accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(200) DEFAULT NULL,
  `consumer_key` varchar(200) DEFAULT NULL,
  `consumer_secret` varchar(200) DEFAULT NULL,
  `access_token` varchar(200) DEFAULT NULL,
  `access_token_secret` varchar(200) DEFAULT NULL,
  `type` varchar(100) NOT NULL DEFAULT '',
  `message_format` text,
  `extra` text,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `username_type` (`username`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `otot_microblogposter_logs`;

CREATE TABLE `otot_microblogposter_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `account_type` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(200) NOT NULL DEFAULT '',
  `post_id` bigint(20) unsigned NOT NULL,
  `action_result` tinyint(4) NOT NULL,
  `update_message` text,
  `log_type` varchar(50) NOT NULL DEFAULT 'regular',
  `log_message` text,
  `log_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `otot_microblogposter_old_items`;

CREATE TABLE `otot_microblogposter_old_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `publish_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `item_type` varchar(50) NOT NULL DEFAULT 'post',
  `extra` text,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `otot_microblogposter_user_accounts`;

CREATE TABLE `otot_microblogposter_user_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `otot_options`;

CREATE TABLE `otot_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=749 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_options` VALUES("1","siteurl","http://www.onyxsistemi.it/restyling","yes");
INSERT INTO `otot_options` VALUES("2","home","http://www.onyxsistemi.it/restyling","yes");
INSERT INTO `otot_options` VALUES("3","blogname","Onyx Technology","yes");
INSERT INTO `otot_options` VALUES("4","blogdescription","“La barca che vince ha lo stesso vento delle altre ma ha un equipaggio migliore.”","yes");
INSERT INTO `otot_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `otot_options` VALUES("6","admin_email","c.alberti@onyxtechnology.it","yes");
INSERT INTO `otot_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `otot_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `otot_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `otot_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `otot_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `otot_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `otot_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `otot_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `otot_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `otot_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `otot_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `otot_options` VALUES("18","default_category","1","yes");
INSERT INTO `otot_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `otot_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `otot_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `otot_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `otot_options` VALUES("23","date_format","j F Y","yes");
INSERT INTO `otot_options` VALUES("24","time_format","G:i","yes");
INSERT INTO `otot_options` VALUES("25","links_updated_date_format","j F Y G:i","yes");
INSERT INTO `otot_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `otot_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `otot_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `otot_options` VALUES("29","rewrite_rules","a:129:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:10:\"annunci/?$\";s:27:\"index.php?post_type=annunci\";s:40:\"annunci/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=annunci&feed=$matches[1]\";s:35:\"annunci/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=annunci&feed=$matches[1]\";s:27:\"annunci/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=annunci&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:53:\"parolechiave/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?parole_chiave=$matches[1]&feed=$matches[2]\";s:48:\"parolechiave/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?parole_chiave=$matches[1]&feed=$matches[2]\";s:29:\"parolechiave/([^/]+)/embed/?$\";s:46:\"index.php?parole_chiave=$matches[1]&embed=true\";s:41:\"parolechiave/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?parole_chiave=$matches[1]&paged=$matches[2]\";s:23:\"parolechiave/([^/]+)/?$\";s:35:\"index.php?parole_chiave=$matches[1]\";s:41:\"cookielawinfo/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:51:\"cookielawinfo/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:71:\"cookielawinfo/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"cookielawinfo/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"cookielawinfo/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:47:\"cookielawinfo/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:30:\"cookielawinfo/([^/]+)/embed/?$\";s:46:\"index.php?cookielawinfo=$matches[1]&embed=true\";s:34:\"cookielawinfo/([^/]+)/trackback/?$\";s:40:\"index.php?cookielawinfo=$matches[1]&tb=1\";s:42:\"cookielawinfo/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?cookielawinfo=$matches[1]&paged=$matches[2]\";s:49:\"cookielawinfo/([^/]+)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?cookielawinfo=$matches[1]&cpage=$matches[2]\";s:38:\"cookielawinfo/([^/]+)(?:/([0-9]+))?/?$\";s:52:\"index.php?cookielawinfo=$matches[1]&page=$matches[2]\";s:30:\"cookielawinfo/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"cookielawinfo/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"cookielawinfo/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"cookielawinfo/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"cookielawinfo/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"cookielawinfo/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"annunci/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"annunci/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"annunci/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"annunci/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"annunci/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"annunci/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"annunci/([^/]+)/embed/?$\";s:40:\"index.php?annunci=$matches[1]&embed=true\";s:28:\"annunci/([^/]+)/trackback/?$\";s:34:\"index.php?annunci=$matches[1]&tb=1\";s:48:\"annunci/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?annunci=$matches[1]&feed=$matches[2]\";s:43:\"annunci/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?annunci=$matches[1]&feed=$matches[2]\";s:36:\"annunci/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?annunci=$matches[1]&paged=$matches[2]\";s:43:\"annunci/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?annunci=$matches[1]&cpage=$matches[2]\";s:32:\"annunci/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?annunci=$matches[1]&page=$matches[2]\";s:24:\"annunci/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"annunci/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"annunci/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"annunci/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"annunci/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"annunci/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `otot_options` VALUES("30","hack_file","0","yes");
INSERT INTO `otot_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `otot_options` VALUES("32","moderation_keys","","no");
INSERT INTO `otot_options` VALUES("33","active_plugins","a:12:{i:0;s:25:\"add-to-any/add-to-any.php\";i:1;s:41:\"better-wp-security/better-wp-security.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:35:\"cookie-law-info/cookie-law-info.php\";i:4;s:37:\"gestione-annunci/gestione-annunci.php\";i:5;s:17:\"iframe/iframe.php\";i:6;s:47:\"jonradio-private-site/jonradio-private-site.php\";i:7;s:36:\"microblog-poster/microblogposter.php\";i:8;s:27:\"qtranslate-x/qtranslate.php\";i:9;s:27:\"scroll-me-up/scrollmeup.php\";i:10;s:31:\"search-filter/search-filter.php\";i:11;s:35:\"wp-database-admin/wda_functions.php\";}","yes");
INSERT INTO `otot_options` VALUES("34","category_base","","yes");
INSERT INTO `otot_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `otot_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `otot_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `otot_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `otot_options` VALUES("39","recently_edited","a:3:{i:0;s:77:\"/home/ony59143/public_html/restyling/wp-content/plugins/scroll-me-up/show.php\";i:2;s:83:\"/home/ony59143/public_html/restyling/wp-content/plugins/scroll-me-up/scrollmeup.php\";i:3;s:0:\"\";}","no");
INSERT INTO `otot_options` VALUES("40","template","onyx_new","yes");
INSERT INTO `otot_options` VALUES("41","stylesheet","onyx_new","yes");
INSERT INTO `otot_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `otot_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `otot_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `otot_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `otot_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `otot_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `otot_options` VALUES("48","db_version","37965","yes");
INSERT INTO `otot_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `otot_options` VALUES("50","upload_path","","yes");
INSERT INTO `otot_options` VALUES("51","blog_public","0","yes");
INSERT INTO `otot_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `otot_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `otot_options` VALUES("54","tag_base","","yes");
INSERT INTO `otot_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `otot_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `otot_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `otot_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `otot_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `otot_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `otot_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `otot_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `otot_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `otot_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `otot_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `otot_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `otot_options` VALUES("67","image_default_size","","yes");
INSERT INTO `otot_options` VALUES("68","image_default_align","","yes");
INSERT INTO `otot_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `otot_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `otot_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `otot_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `otot_options` VALUES("73","page_comments","0","yes");
INSERT INTO `otot_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `otot_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `otot_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `otot_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `otot_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("81","uninstall_plugins","a:2:{s:35:\"cookie-law-info/cookie-law-info.php\";s:30:\"cookielawinfo_uninstall_plugin\";s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:12:\"on_uninstall\";}}","no");
INSERT INTO `otot_options` VALUES("82","timezone_string","Europe/Rome","yes");
INSERT INTO `otot_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `otot_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `otot_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `otot_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `otot_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `otot_options` VALUES("88","site_icon","0","yes");
INSERT INTO `otot_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `otot_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `otot_options` VALUES("91","initial_db_version","37965","yes");
INSERT INTO `otot_options` VALUES("92","otot_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:36:\"microblogposter_who_can_auto_publish\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:36:\"microblogposter_who_can_auto_publish\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:11:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:36:\"microblogposter_who_can_auto_publish\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:6:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:36:\"microblogposter_who_can_auto_publish\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:3:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;s:36:\"microblogposter_who_can_auto_publish\";b:1;}}}","yes");
INSERT INTO `otot_options` VALUES("93","WPLANG","it_IT","yes");
INSERT INTO `otot_options` VALUES("94","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("95","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("96","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("97","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("98","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("99","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `otot_options` VALUES("100","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("101","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("102","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("103","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("104","cron","a:5:{i:1480285156;a:2:{s:16:\"itsec_purge_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"itsec_purge_lockouts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1480297050;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1480340270;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1480341208;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `otot_options` VALUES("114","can_compress_scripts","1","no");
INSERT INTO `otot_options` VALUES("315","_site_transient_browser_5e06a2d838c1690d9a4db2dbdca80389","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"53.0.2785.143\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("166","recently_activated","a:1:{s:37:\"my-upload-images/my-upload-images.php\";i:1480204186;}","yes");
INSERT INTO `otot_options` VALUES("167","jr_ps_internal_settings","a:1:{s:7:\"version\";s:6:\"2.14.1\";}","yes");
INSERT INTO `otot_options` VALUES("168","jr_ps_settings","a:13:{s:12:\"private_site\";b:1;s:19:\"reveal_registration\";b:0;s:11:\"wplogin_php\";b:0;s:13:\"override_omit\";b:0;s:12:\"custom_login\";b:0;s:19:\"custom_login_onsite\";b:1;s:9:\"excl_home\";b:0;s:12:\"specific_url\";s:0:\"\";s:7:\"landing\";s:4:\"home\";s:9:\"login_url\";s:0:\"\";s:10:\"check_role\";b:1;s:8:\"excl_url\";a:0:{}s:15:\"excl_url_prefix\";a:0:{}}","yes");
INSERT INTO `otot_options` VALUES("735","_site_transient_timeout_theme_roots","1480267044","no");
INSERT INTO `otot_options` VALUES("736","_site_transient_theme_roots","a:1:{s:8:\"onyx_new\";s:7:\"/themes\";}","no");
INSERT INTO `otot_options` VALUES("188","_site_transient_timeout_browser_d7ebeddeee1c10c06a3c4cf170141814","1476779891","no");
INSERT INTO `otot_options` VALUES("189","_site_transient_browser_d7ebeddeee1c10c06a3c4cf170141814","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"49.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("624","_transient_timeout_feed_mod_dbc574053cccd058bc63a08b9c8e458e","1479461039","no");
INSERT INTO `otot_options` VALUES("625","_transient_feed_mod_dbc574053cccd058bc63a08b9c8e458e","1479417839","no");
INSERT INTO `otot_options` VALUES("683","_site_transient_timeout_browser_bbe17f0a746d1d92d88f5944fc82bf7f","1480372795","no");
INSERT INTO `otot_options` VALUES("684","_site_transient_browser_bbe17f0a746d1d92d88f5944fc82bf7f","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"54.0.2840.99\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("571","_site_transient_browser_cd07c4a7a86f684d711f0467bdfe13bf","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Safari\";s:7:\"version\";s:6:\"10.0.1\";s:10:\"update_url\";s:28:\"http://www.apple.com/safari/\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/safari.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/safari.png\";s:15:\"current_version\";s:1:\"5\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("570","_site_transient_timeout_browser_cd07c4a7a86f684d711f0467bdfe13bf","1479734069","no");
INSERT INTO `otot_options` VALUES("382","wpcf7","a:2:{s:7:\"version\";s:5:\"4.5.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";d:1477862687;s:7:\"version\";s:5:\"4.5.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `otot_options` VALUES("418","_site_transient_timeout_browser_0a59b19295de58488e477927c110bae5","1478645786","no");
INSERT INTO `otot_options` VALUES("419","_site_transient_browser_0a59b19295de58488e477927c110bae5","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"54.0.2840.71\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("433","_site_transient_timeout_browser_7fbb3da0dd1d829e2aa03f69d88f328c","1479153025","no");
INSERT INTO `otot_options` VALUES("434","_site_transient_browser_7fbb3da0dd1d829e2aa03f69d88f328c","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"54.0.2840.71\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("630","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1479461042","no");
INSERT INTO `otot_options` VALUES("631","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Nov 2016 21:10:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"1169@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 15 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"Secure your website with the most comprehensive WordPress security plugin. Firewall, malware scan, blocking, live traffic, login security &#38; more.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"W3 Total Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/w3-total-cache/#post-12073\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2009 18:46:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"12073@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"Search Engine (SEO) &#38; Performance Optimization (WPO) via caching. Integrated caching: CDN, Minify, Page, Object, Fragment, Database support.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Frederick Townes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Regenerate Thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 23 Aug 2008 14:38:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"6743@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"Allows you to regenerate your thumbnails after changing the thumbnail sizes.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Alex Mills (Viper007Bond)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"51888@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"Extends and enhances TinyMCE, the WordPress Visual Editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Really Simple CAPTCHA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/really-simple-captcha/#post-9542\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Mar 2009 02:17:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"9542@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"One of the most downloaded plugins for WordPress (over 30 million downloads since 2007). Use All in One SEO Pack to automatically optimize your site f\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Duplicate Post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/duplicate-post/#post-2646\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2007 17:40:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2646@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Clone posts and pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Lopo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/hello-dolly/#post-5790\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 May 2008 22:11:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5790@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Yoast SEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"Increase your traffic, view your stats, speed up your site, and protect yourself from hackers with Jetpack.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-PageNavi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wp-pagenavi/#post-363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 23:17:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"363@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Adds a more advanced paging navigation interface.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Lester Chan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"Google Analytics by MonsterInsights\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"Connect Google Analytics with WordPress by adding your Google Analytics tracking code. Get the stats that matter.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Syed Balkhi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Clef Two-Factor Authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wpclef/#post-47509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Dec 2012 01:25:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"47509@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:139:\"Modern two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical login experience.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Dave Ross\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"UpdraftPlus WordPress Backup Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/updraftplus/#post-38058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 May 2012 15:14:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38058@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Anderson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Disable Comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/disable-comments/#post-26907\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 May 2011 04:42:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26907@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Samir Shah\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WP Multibyte Patch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Jul 2011 12:22:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"28395@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Multibyte functionality enhancement for the WordPress Japanese package.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"plugin-master\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Duplicator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/duplicator/#post-26607\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2011 12:15:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26607@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"Duplicate, clone, backup, move and transfer an entire site from one location to another.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Cory Lamle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"iThemes Security (formerly Better WP Security)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"21738@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:146:\"Take the guesswork out of WordPress security. iThemes Security offers 30+ ways to lock down WordPress in an easy-to-use WordPress security plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"iThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Meta Slider\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/ml-slider/#post-49521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Feb 2013 16:56:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"49521@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"Easy to use WordPress Slider plugin. Create responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Matcha Labs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 17 Nov 2016 21:24:03 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Thu, 17 Nov 2016 21:45:18 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Thu, 17 Nov 2016 21:10:18 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20161003130356\";}","no");
INSERT INTO `otot_options` VALUES("628","_transient_timeout_feed_mod_13e268f84d68a386face41f0af9b3e48","1479461041","no");
INSERT INTO `otot_options` VALUES("629","_transient_feed_mod_13e268f84d68a386face41f0af9b3e48","1479417841","no");
INSERT INTO `otot_options` VALUES("632","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1479461042","no");
INSERT INTO `otot_options` VALUES("633","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1479417842","no");
INSERT INTO `otot_options` VALUES("612","_transient_timeout_plugin_slugs","1480352122","no");
INSERT INTO `otot_options` VALUES("613","_transient_plugin_slugs","a:16:{i:0;s:25:\"add-to-any/add-to-any.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:35:\"cookie-law-info/cookie-law-info.php\";i:4;s:37:\"gestione-annunci/gestione-annunci.php\";i:5;s:9:\"hello.php\";i:6;s:17:\"iframe/iframe.php\";i:7;s:41:\"better-wp-security/better-wp-security.php\";i:8;s:47:\"linkedin-auto-publish/linkedin-auto-publish.php\";i:9;s:36:\"microblog-poster/microblogposter.php\";i:10;s:47:\"jonradio-private-site/jonradio-private-site.php\";i:11;s:27:\"qtranslate-x/qtranslate.php\";i:12;s:27:\"scroll-me-up/scrollmeup.php\";i:13;s:31:\"search-filter/search-filter.php\";i:14;s:33:\"w3-total-cache/w3-total-cache.php\";i:15;s:35:\"wp-database-admin/wda_functions.php\";}","no");
INSERT INTO `otot_options` VALUES("685","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1479780157","no");
INSERT INTO `otot_options` VALUES("686","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"6110\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3747\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3738\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"3244\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2869\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"2546\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2229\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"2155\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"2104\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"2089\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"2044\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:4:\"2025\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1965\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1937\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1756\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1653\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1625\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1469\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1380\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1299\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1296\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:4:\"1152\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:4:\"1136\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:4:\"1065\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:4:\"1027\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:4:\"1017\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"969\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"964\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"963\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"932\";}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";s:3:\"929\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"916\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"861\";}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";s:3:\"851\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"841\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"821\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"788\";}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"Share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";s:3:\"783\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"783\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"770\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"759\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"751\";}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";s:3:\"749\";}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";s:3:\"743\";}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"CSS\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";s:3:\"736\";}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";s:3:\"731\";}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";s:3:\"725\";}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";s:3:\"718\";}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";s:3:\"718\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"710\";}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";s:3:\"701\";}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";s:3:\"656\";}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";s:3:\"652\";}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";s:3:\"640\";}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";s:3:\"635\";}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";s:3:\"629\";}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";s:3:\"616\";}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";s:3:\"615\";}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";s:3:\"614\";}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";s:3:\"612\";}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";s:3:\"601\";}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";s:3:\"585\";}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";s:3:\"585\";}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";s:3:\"584\";}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";s:3:\"580\";}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";s:3:\"563\";}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";s:3:\"553\";}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";s:3:\"549\";}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";s:3:\"546\";}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";s:3:\"540\";}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";s:3:\"540\";}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";s:3:\"538\";}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";s:3:\"534\";}s:4:\"shop\";a:3:{s:4:\"name\";s:4:\"shop\";s:4:\"slug\";s:4:\"shop\";s:5:\"count\";s:3:\"522\";}s:7:\"picture\";a:3:{s:4:\"name\";s:7:\"picture\";s:4:\"slug\";s:7:\"picture\";s:5:\"count\";s:3:\"519\";}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";s:3:\"509\";}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";s:3:\"507\";}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";s:3:\"496\";}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";s:3:\"484\";}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";s:3:\"471\";}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";s:3:\"469\";}s:8:\"pictures\";a:3:{s:4:\"name\";s:8:\"pictures\";s:4:\"slug\";s:8:\"pictures\";s:5:\"count\";s:3:\"467\";}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";s:3:\"462\";}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";s:3:\"459\";}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";s:3:\"448\";}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";s:3:\"447\";}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";s:3:\"443\";}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";s:3:\"438\";}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";s:3:\"436\";}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";s:3:\"430\";}s:6:\"paypal\";a:3:{s:4:\"name\";s:6:\"paypal\";s:4:\"slug\";s:6:\"paypal\";s:5:\"count\";s:3:\"427\";}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";s:3:\"426\";}s:6:\"upload\";a:3:{s:4:\"name\";s:6:\"upload\";s:4:\"slug\";s:6:\"upload\";s:5:\"count\";s:3:\"425\";}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";s:3:\"424\";}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"News\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";s:3:\"422\";}s:7:\"sharing\";a:3:{s:4:\"name\";s:7:\"sharing\";s:4:\"slug\";s:7:\"sharing\";s:5:\"count\";s:3:\"422\";}s:5:\"flash\";a:3:{s:4:\"name\";s:5:\"flash\";s:4:\"slug\";s:5:\"flash\";s:5:\"count\";s:3:\"421\";}s:9:\"thumbnail\";a:3:{s:4:\"name\";s:9:\"thumbnail\";s:4:\"slug\";s:9:\"thumbnail\";s:5:\"count\";s:3:\"417\";}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";s:3:\"414\";}s:8:\"linkedin\";a:3:{s:4:\"name\";s:8:\"linkedin\";s:4:\"slug\";s:8:\"linkedin\";s:5:\"count\";s:3:\"413\";}}","no");
INSERT INTO `otot_options` VALUES("132","theme_mods_twentysixteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1475501895;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `otot_options` VALUES("133","current_theme","Onyx","yes");
INSERT INTO `otot_options` VALUES("134","theme_mods_onyx","a:2:{i:0;b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1475508331;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:18:\"orphaned_widgets_1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `otot_options` VALUES("135","theme_switched","","yes");
INSERT INTO `otot_options` VALUES("136","theme_switched_via_customizer","","yes");
INSERT INTO `otot_options` VALUES("622","_transient_timeout_feed_dbc574053cccd058bc63a08b9c8e458e","1479461039","no");
INSERT INTO `otot_options` VALUES("623","_transient_feed_dbc574053cccd058bc63a08b9c8e458e","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Blog – Italia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://it.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"mar, 15 Nov 2016 08:00:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"it-IT\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=4.7-beta4-39275\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Global WordPress Translation Day II – 12 novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 06:56:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Eventi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:9:\"Polyglots\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1312\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"Il team Polyglots di WordPress sta organizzando il secondo Global WordPress Translation Day per il 12 novembre. Tutti sono invitati a partecipare da tutto il mondo! Tradurre è uno dei modi più semplici e immediati per iniziare a contribuire al progetto open source WordPress. Il Global WordPress Translation Day è un&#8217;ottima occasione per conoscere le procedure [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Francesca Marano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4910:\"<p>Il team Polyglots di WordPress sta organizzando il secondo <a href=\"https://wptranslationday.org/\">Global WordPress Translation Day</a> per il 12 novembre. Tutti sono invitati a partecipare da tutto il mondo!</p>
<p><strong>Tradurre è uno dei modi più semplici e immediati per iniziare a contribuire al progetto open source WordPress</strong>. Il Global WordPress Translation Day è un&#8217;ottima occasione per conoscere le procedure che stanno dietro alla traduzione di WordPress, conoscere nuove persone e aiutare a tradurre WordPress in <a href=\"https://make.wordpress.org/polyglots/teams\">una delle 160 lingue al momento disponibili</a>.</p>
<h2>Unisciti a noi il 12 novembre, ovunque tu sia!</h2>
<p>La giornata di traduzioni inizia sabato 12 novembre alle 0:00 UTC e finisce 24 ore dopo. <a href=\"http://arewemeetingyet.com/UTC/2016-11-12/00:00/Global%20WordPress%20Translation%20Day%202\">Controlla a che ora inizia per te</a>! Puoi unirti all&#8217;inizio o a un orario qualsiasi che sia comodo per te durante la giornata.</p>
<h2>Cosa faremo?</h2>
<p>Giornate dal vivo di traduzioni sono in programma in giro per il mondo, anche in Italia, e sono un ottimo modo per andare a conoscere i contributor e iniziare a dare una mano. <a href=\"https://wptranslationday.org/#locations\">Controlla questa mappa</a> per vedere se c&#8217;è qualcosa nella tua zona. Non trovi nulla? <a href=\"https://make.wordpress.org/polyglots/2016/09/22/global-wordpress-translation-day-2-on-november-12th-2016/\">Organizza un evento nella tua città!</a></p>
<p>Puoi anche partecipare online, seguendo <a href=\"https://www.crowdcast.io/e/gwtd2/register\">la community in 24 ore di sessioni in streaming</a> in numerose lingue. Le sessioni copriranno temi come la localizzazione, l&#8217;internazionalizzazione, la mentorship e come tradurre WordPress nella tua lingua.</p>
<h2>A chi si rivolge?</h2>
<p>Che tu voglia imparare a tradurre o sia già un translation editor che vuole organizzare un team di persone per la propria lingua, il Translation Day fa per te! Anche chi si occupa di sviluppo troverà spunti interessanti nei talk di contributor esperti che parleranno di internazionalizzazione, ma anche di procedure per trovare traduttori per i propri temi e plugin. Insomma, c&#8217;è <strong>una sessione per tutti!</strong></p>
<h2>Partecipa!</h2>
<p>Partecipare è facile. Il 12 novembre, all&#8217;ora che preferisci, inizi a <a href=\"https://translate.wordpress.org/\">tradurre WordPress</a> o uno dei tuoi temi o plugin preferiti, mentre segui le sessioni in streaming che si alterneranno durante la giornata.</p>
<p>Vuoi prendere una parte attiva nell&#8217;organizzazione dell&#8217;evento? <a href=\"https://make.wordpress.org/polyglots/2016/09/22/global-wordpress-translation-day-2-on-november-12th-2016/\">Organizza un evento</a> dal vivo e invita la tua comunità locale a tradurre insieme il 12 novembre. Gli eventi possono essere formali e strutturati o completamente informali &#8211; prendi il tuo laptop, un paio di amici, vai in un bar della tua città e traduci per un&#8217;ora o due.</p>
<h3><em>Can you get involved if you only speak English?</em></h3>
<p><em>Absolutely! Even if you only speak English, there are great sessions about internationalization that can benefit every developer. There are also lots of English variants that need your help! For example, English is spoken and written differently in Australia, Canada, New Zealand, South Africa, and the United Kingdom. You can learn about these differences and why these variants are important during the sessions.</em></p>
<p>E se vuoi divertirti, prova a tradurre WordPress in emoji! Sì, abbiamo una traduzione anche in emoji! <img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30e.png\" alt=\"🌎\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30d.png\" alt=\"🌍\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30f.png\" alt=\"🌏\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>
<h2>Domande?</h2>
<p>Se hai domande, puoi trovare il team Polyglots e gli organizzatori dell&#8217;evento sia nel canale internazionale <a href=\"http://wordpress.slack.com/messages/polyglots/\">#polyglots in Slack</a> che in quello <a href=\"https://italia-wp-community.slack.com/messages/polyglots\">italiano</a> e siamo felici di poterti aiutare! (Ottieni un invito a Slack su <a href=\"https://chat.wordpress.org/\">chat.wordpress.org</a>.)</p>
<h2>Iscriviti per partecipare sul <a href=\"https://wptranslationday.org/\">sito ufficiale</a>, ti aspettiamo!</h2>
<p><em>Post originale: <a href=\"https://wordpress.org/news/2016/10/join-us-again-for-global-wordpress-translation-day/\">https://wordpress.org/news/2016/10/join-us-again-for-global-wordpress-translation-day/</a> </em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Meetup Ragusa: 25 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Nov 2016 08:00:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"ragusa\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1411\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:386:\"Secondo Meetup a Ragusa! Un nuovo incontro: venerdì 25 novembre 2016, ci troviamo alle 18.00 presso 2.0 Due punto Zero &#8211; Via G. Tomasi 80, Ragusa.  Programma Vedremo più nel dettaglio come installare un tema e come funziona, e cominceremo a conoscere i plugin fondamentali per WP! Iscrizione Il WordPress Meetup è aperto a tutti, iscriviti all&#8217;evento su Meetup.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:554:\"<h1>Secondo Meetup a Ragusa!</h1>
<p>Un nuovo incontro: <strong>venerdì 25 novembre 2016, ci troviamo alle 18.00 presso </strong><strong>2.0 Due punto Zero &#8211; Via G. Tomasi 80, Ragusa. </strong></p>
<h2>Programma</h2>
<p>Vedremo più nel dettaglio come installare un tema e come funziona, e cominceremo a conoscere i plugin fondamentali per WP!</p>
<h2>Iscrizione</h2>
<p>Il WordPress Meetup è aperto a tutti, <a href=\"https://www.meetup.com/it-IT/wordpress-meetup-ragusa/events/235488483/\">iscriviti all&#8217;evento su Meetup.com</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Meetup Bologna: 17 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Nov 2016 08:00:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"bologna\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1407\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:381:\"A Bologna gli appassionati di WordPress si incontrano giovedì 17 Novembre dalle ore 18.15, presso Working Capital #WCAP in Via Guglielmo Oberdan 22 Programma Sicurezza per WordPress Consigli e tecniche per mettere in sicurezza il proprio sito in WordPress. Altro speech da definire Iscrizione Per partecipare è sufficiente iscriversi all’evento su meetup.com, non mancare!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:652:\"<p>A Bologna gli appassionati di WordPress si incontrano <strong>giovedì 17 Novembre</strong> <strong>dalle ore 18.15</strong>, presso <strong>Working Capital #WCAP in Via Guglielmo Oberdan 22</strong></p>
<h2>Programma</h2>
<ul>
<li><strong>Sicurezza per WordPress</strong><br />
Consigli e tecniche per mettere in sicurezza il proprio sito in WordPress.<strong><br />
</strong></li>
<li><em>Altro speech da definire </em></li>
</ul>
<h2>Iscrizione</h2>
<p>Per partecipare è sufficiente <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Bologna/events/235439083/\" target=\"_blank\">iscriversi all’evento su meetup.com</a>, non mancare!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Meetup Padova: 15 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2016 08:00:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"padova\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1405\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:450:\"Il prossimo WordPress Meetup a Padova è Martedì 15 Novembre, alle 19, presso TalentLab (via Monselice 15/a, Padova)  Programma dell&#8217;incontro WordPress SEO Gli strumenti migliori per monitorare il traffico sul nostro sito WordPress, comprendere i dati e ottenere maggiore visibilità nei motori di ricerca. WooCommerce Dimostrazione pratica sulle principali caratteristiche del popolare plugin che trasforma WordPress in un vero [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1062:\"<p>Il prossimo WordPress Meetup a Padova è <strong>Martedì 15 Novembre, alle 19, presso TalentLab</strong> <strong>(via Monselice 15/a, Padova) </strong></p>
<h2>Programma dell&#8217;incontro</h2>
<ul>
<li><strong>WordPress SEO</strong><br />
Gli strumenti migliori per monitorare il traffico sul nostro sito WordPress, comprendere i dati e ottenere maggiore visibilità nei motori di ricerca.</li>
<li><strong>WooCommerce</strong><br />
Dimostrazione pratica sulle principali caratteristiche del popolare plugin che trasforma WordPress in un vero e-commerce. Dall’installazione alla scelta del tema ideale, cercheremo una risposta a molte curiosità. Quali tipologie di prodotto possiamo creare? Come possiamo gestire gli ordini? possiamo espandere le funzionalità di default in base alle nostre esigenze?</li>
</ul>
<h2>Come partecipare</h2>
<p><a href=\"http://www.meetup.com/it-IT/Padova-WordPress-Meetup/events/235438289/\" target=\"_blank\">Iscriviti all&#8217;evento su Meetup!</a> La partecipazione è libera e aperta a tutti. Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"Partecipa alla giornata mondiale di traduzione di WP! Eventi locali in Italia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:115:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Nov 2016 10:38:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:6:\"Eventi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:9:\"Polyglots\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1384\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:428:\"Partecipa al WordPress Global Translation Day: in Italia sono organizzati eventi locali a Barletta, Catania, Milano, Roma, Torino, Vicenza. Segnati la data se vuoi aiutarci nella traduzione di WordPress (core, plugin, temi &#8230;) o se vuoi imparare come si traduce WordPress. Informazioni sugli eventi Barletta Quando: Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 20.00 Dove: Fabbrica42 &#8211; Corso Cavour [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5080:\"<p>Partecipa al <a href=\"https://wptranslationday.org\" target=\"_blank\">WordPress Global Translation Day</a>: in Italia sono organizzati eventi locali a Barletta, Catania, Milano, Roma, Torino, Vicenza.</p>
<p>Segnati la data se vuoi aiutarci nella traduzione di WordPress (core, plugin, temi &#8230;) o se vuoi imparare come si traduce WordPress.</p>
<h2>Informazioni sugli eventi</h2>
<h2>Barletta</h2>
<ul>
<li><strong>Quando:</strong> Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 20.00</li>
<li><strong>Dove:</strong> Fabbrica42 &#8211; Corso Cavour 32, Barletta</li>
<li><strong>Programma: </strong>
<ul>
<li>Introdurremo alla community di WordPress e alla sua attività italiana e mondiale;</li>
<li>Spiegheremo cos&#8217;è il progetto Polyglots e come poter contribuire alla traduzione di WordPress in tutte le sue parti, dai temi ai plugin;</li>
<li>Seguiremo alcune delle sessioni online mondiali organizzate dalla community sui temi come la localizzazione, l’internazionalizzazione, la mentorship e come tradurre WordPress nella tua lingua;</li>
<li>Tradurremo insieme WordPress</li>
</ul>
</li>
<li><strong>Iscrizione:</strong><a href=\"https://www.meetup.com/it-IT/Barletta-WordPress-Meetup/events/235327909/\" target=\"_blank\"> Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Catania</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 9.30 alle 12.00</li>
<li><strong>Dove: </strong>Karma Lab &#8211; Via J. Kennedy 6/8 &#8211; Aci Sant’Antonio &#8211; Catania</li>
<li><strong>Programma:</strong>
<ul>
<li><strong>Introduzione alla traduzione di temi e plugin </strong></li>
<li><strong>Gli strumenti necessari alla traduzione </strong></li>
<li><strong>GlotPress </strong></li>
<li><strong>Traduzione collettiva</strong></li>
</ul>
</li>
<li><strong>Iscrizione: </strong><a href=\"http://www.meetup.com/it-IT/Meetup-WordPress-Catania/events/235413788/\" target=\"_blank\">meetup.com</a></li>
</ul>
<h2></h2>
<h2>Milano</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 19.00</li>
<li><strong>Dove:</strong> inCOWORK &#8211; via Lodovico Montegani, 23, Milano</li>
<li><strong>Programma: </strong>Traduciamo insieme! Non ti far bloccare dalla paura di “non sapere come e cosa fare” perché ti verrà spiegato come tradurre temi e plugin per WordPress e tanto altro.</li>
<li><strong>Iscrizione:</strong> <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Milano/events/235376830/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Roma</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 14.00 alle 18.00</li>
<li><strong>Dove: </strong>Talent Garden Roma &#8211; Via Giuseppe Andreoli, 9, Roma</li>
<li><strong>Programma: </strong>
<ul>
<li>14:00 &#8211; 14:30 &#8211; Registrazione dei partecipanti e tour del TAG</li>
<li>14:30 &#8211; 15:00 &#8211; Sessione di mentoring e coaching per chi non ha mai tradotto WP (gli altri inizieranno subito a tradurre)</li>
<li>15:00 &#8211; 18:00 &#8211; Si traducono più stringhe possibili per provare a battere ogni record mondiale!</li>
</ul>
</li>
<li><strong>Iscrizione: </strong><a href=\"https://www.meetup.com/it-IT/RomaWordPress/events/235150036/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Torino</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 10.00 alle 15.00</li>
<li><strong>Dove: </strong>Torteria Berlicabarbis &#8211; corso Moncalieri 214, Torino</li>
<li><strong>Programma: </strong>Tradurremo insieme e seguiremo gli streaming davanti a the e torte</li>
<li><strong>Iscrizione: </strong><a href=\"https://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/235173608/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Vicenza (community di Verona e Padova)</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 09.00 alle 12.00</li>
<li><strong>Dove: </strong>Villino Rossi di Povolaro &#8211; Via Molinetto, frazione Povolaro &#8211; Dueville (VI)</li>
<li><strong><strong>Programma:</strong></strong> Impariamo insieme a tradurre!</li>
<li><strong>Iscrizione</strong>: <a href=\"http://www.meetup.com/it-IT/Verona-WordPress-Meetup/events/235324992/?eventId=235324992\" target=\"_blank\">Meetup Verona</a></li>
</ul>
<p>&nbsp;</p>
<h2>Risorse utili</h2>
<p>Se i progetti di traduzione di WordPress ti sono nuovi, puoi vedere questi link:</p>
<ul>
<li><a href=\"https://it.wordpress.org/traduzioni/\">Guida per iniziare a tradurre (e guida di stile) </a></li>
<li><a href=\"https://translate.wordpress.org/projects/wp/dev/it/default/glossary\">Glossario </a></li>
<li><a href=\"https://it.wordpress.org/slack/\">Come iscriverti alla Community Italiana su Slack</a></li>
</ul>
<p>&nbsp;</p>
<p>Tradurre WordPress è un ottimo modo per essere coinvolti e contribuire al progetto. Durante il WordPress Global Translation Day, non solo sarai aiutato dai TE (Translation Editor) locali, ma anche da molti dei Polyglot dell&#8217;intera community WordPress di tutto il mondo.</p>
<p>Vieni a tradurre con noi!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Meetup Torino Contributor Night: 11 novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Nov 2016 08:09:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"torino\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1390\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:427:\"Torino raddoppia! Da Novembre c&#8217;è un secondo appuntamento mensile della community WordPress torinese: le Contributor Nights, dedicate a studiare e lavorare insieme. Ogni mese selezioneremo uno dei team attivi su make.wordpress.org. Per alcuni team potremo contare sul supporto di lead, italiani e stranieri, mentre per altri ci autogestiremo con lo studio, leggendo la documentazione, andando a vedere quali [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2126:\"<h1>Torino raddoppia!</h1>
<p>Da Novembre c&#8217;è un secondo appuntamento mensile della community WordPress torinese: le <strong>Contributor Nights, dedicate a studiare e lavorare insieme.</strong><br />
Ogni mese selezioneremo uno dei team attivi su make.wordpress.org. Per alcuni team potremo contare sul supporto di lead, italiani e stranieri, mentre per altri ci autogestiremo con lo studio, leggendo la documentazione, andando a vedere quali sono le discussioni attive su trac e su Slack.</p>
<p><strong>Per questa prima serata siamo felici di avere con noi John Blackbourn, WordPress engineer presso Human Made e uno dei WordPress Core developer, che ci aiuterà a scoprire il team Core. </strong></p>
<p><strong>Appuntamento da Toolbox Coworking, Venerdì 11 novembre dalle 18:00 alle 21:45</strong></p>
<h2>Programma</h2>
<ul>
<li>18:00 &#8211; 18:30 &#8211; Registrazione/Installazione di VVV/Networking</li>
<li>18:30 &#8211; 19:30 &#8211; Intro to Core &#8211; la sessione di John sul team Core (in inglese)</li>
<li>19:30 &#8211; 21:45 &#8211; Studio, lavoro, domande, chiacchiere!</li>
</ul>
<h2>Per chi è questa serata</h2>
<ul>
<li>Per gli sviluppatori che vogliono iniziare a contribuire a WordPress</li>
<li>Per gli sviluppatori che già contribuiscono e vogliono confrontarsi con altri contributor esperti</li>
<li>Per chi vuole aiutare con test, documentazione, feedback, bug gardening (è comunque richiesta una buona conoscenza di WordPress e dei suoi componenti)</li>
</ul>
<h2>Come partecipare</h2>
<p>Porta il tuo computer e carica batteria. È fortemente consigliato arrivare preparati con un ambiente di sviluppo e WordPress già installati in locale.</p>
<h2>Iscrizione</h2>
<p>La partecipazione è libera,<a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/235251911/\" target=\"_blank\"> iscriviti all&#8217;evento su Meetup</a>. I posti disponibili sono limitati.<br />
<em>Se rispondete che siete interessati a venire e poi dovete cancellare, fatecelo sapere tempestivamente in modo da poter assegnare il vostro posto a un altro contributor. </em></p>
<p>&nbsp;</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Meetup Piacenza: 7 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Nov 2016 12:30:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Piacenza\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1381\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:499:\"WordPress Meetup Piacenza, #2 Ci vediamo Lunedì 7 Novembre alle 18.30 presso Spazio2 &#8211; Via XXIV Maggio 51/53, Piacenza.  Programma 8:30-19:00 Benvenuto + Networking  Resoconto del recente WordCamp Milano. 19:00-19:30 Divagazioni sui temi di WordPress #2   La seconda parte dell&#8217;interessante presentazione sulla struttura, la scelta e la personalizzazione dei temi di WordPress. 19:30-20:00 Un plugin al giorno&#8230;  Nasce una nuova rubrica che ci accompagnerà [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1224:\"<h1>WordPress Meetup Piacenza, #2</h1>
<p>Ci vediamo <strong>Lunedì 7 Novembre alle 18.30 presso Spazio2 &#8211; Via XXIV Maggio 51/53, Piacenza. </strong></p>
<h2>Programma</h2>
<ul>
<li><strong>8:30-19:00 Benvenuto + Networking </strong><br />
Resoconto del recente WordCamp Milano.</li>
<li><strong>19:00-19:30 Divagazioni sui temi di WordPress #2  </strong><br />
La seconda parte dell&#8217;interessante presentazione sulla struttura, la scelta e la personalizzazione dei temi di WordPress.</li>
<li><strong>19:30-20:00 Un plugin al giorno&#8230;  </strong><br />
Nasce una nuova rubrica che ci accompagnerà in tutti i prossimi appuntamenti. Cominceremo cercando di stilare un elenco dei plugin che non dovrebbero mai mancare in una corretta installazione di WordPress.</li>
<li><strong>20:00-20:30 Networking </strong><br />
Spazio libero per discussioni, domande e risposte sugli argomenti trattati e su altri proposti dai partecipanti.</li>
</ul>
<h2>Come partecipare</h2>
<p>L&#8217;incontro è gratuito, aperto a tutti: basta <a href=\"http://www.meetup.com/it-IT/Piacenza-WordPress-Meetup/events/235177019/\" target=\"_blank\">iscriversi all&#8217;evento su Meetup. </a></p>
<p>Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Meetup Milano: 8 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 Nov 2016 08:11:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"milano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1330\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:400:\"Dopo il WordCamp, ci rivediamo al Meetup! Appuntamento di Novembre con il WordPress Meetup di Milano: martedì 8 Novembre alle 19, come sempre presso MotorK Italia, Via Ludovico D&#8217;Aragona, 9, Milano.  Programma &#8220;WP API &#8211; The time is now&#8221;  Cosa sono le WordPress API? A cosa servono? Perché dovremmo usarle? E come? In questo talk cerchiamo di rispondere a un [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1062:\"<h1>Dopo il WordCamp, ci rivediamo al Meetup!</h1>
<p>Appuntamento di Novembre con il WordPress Meetup di Milano: <strong>martedì 8 Novembre alle 19</strong>, come sempre presso <strong>MotorK Italia, Via Ludovico D&#8217;Aragona, 9, Milano. </strong></p>
<h2>Programma</h2>
<ul>
<li><strong>&#8220;WP API &#8211; The time is now&#8221; </strong><br />
Cosa sono le WordPress API? A cosa servono? Perché dovremmo usarle? E come? In questo talk cerchiamo di rispondere a un pó di curiositá, domande, dubbi</li>
<li><strong>&#8220;AMP &#8211; Accelerated Mobile Pages&#8221; </strong><br />
What Is AMP? What are the benefits of Accelerated Mobile Pages? How do Accelerated Mobile Pages work? So it works for publishers, does it bring benefits for you too?</li>
</ul>
<h2>Per partecipare</h2>
<p>Tutti possono partecipare, è libero e gratuito! Devi solo <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Milano/events/235149483/\" target=\"_blank\">iscriverti all&#8217;evento su Meetup,</a> così sappiamo quanti siamo.<br />
Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Meetup Torino: 9 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 07:11:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"torino\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1326\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:403:\"A Torino siamo a quota 16 Meetup! Il prossimo incontro è Mercoledì 9 Novembre, alle 18, come sempre presso Toolbox Coworking, Via Agostino da Montefeltro 2, Torino. Programma Cos&#8217;è e come si realizza un Plugin Come funziona l’Open Source? Non lo so, impariamo insieme? Come si partecipa L’ingresso è libero e gratuito e per partecipare è sufficiente registrarsi all’evento [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:664:\"<h1 class=\"text--display3\">A Torino siamo a quota 16 Meetup!</h1>
<p>Il prossimo incontro è <strong>Mercoledì 9 Novembre, alle 18, </strong>come sempre presso<strong> Toolbox Coworking</strong>, <strong>Via Agostino da Montefeltro 2, Torino.</strong></p>
<h2>Programma</h2>
<ul>
<li>Cos&#8217;è e come si realizza un Plugin</li>
<li>Come funziona l’Open Source? Non lo so, impariamo insieme?</li>
</ul>
<h2>Come si partecipa</h2>
<p>L’ingresso è libero e gratuito e per partecipare è sufficiente <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/234938015/\" target=\"_blank\">registrarsi all’evento su Meetup</a>. Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Primo Meetup a Brindisi: 4 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 07:00:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"brindisi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1334\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:383:\"Una nuova community locale: ecco il gruppo di Brindisi! Il primo incontro sarà Venerdì 4 Novembre, alle ore 17, presso FabLab Brindisi, via Fulvia 116 Brindisi.  Programma Il programma dell&#8217;incontro è sostanzialmente: conoscerci! Parleremo di Cos&#8217;è e cosa non è un meetup? Prossimi eventi della community Idee per i prossimi incontri Come si partecipa? In [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:802:\"<h1>Una nuova community locale: ecco il gruppo di Brindisi!</h1>
<p>Il primo incontro sarà <strong>Venerdì 4 Novembre, alle ore 17, presso FabLab Brindisi, via Fulvia 116 Brindisi. </strong></p>
<h2>Programma</h2>
<p>Il programma dell&#8217;incontro è sostanzialmente: conoscerci!</p>
<p>Parleremo di</p>
<ul>
<li>Cos&#8217;è e cosa non è un meetup?</li>
<li>Prossimi eventi della community</li>
<li>Idee per i prossimi incontri</li>
</ul>
<h2>Come si partecipa?</h2>
<p>In attesa del nostro &#8220;posto&#8221; su Meeetup.com, ci siamo organizzati su Facebook: <a href=\"https://www.facebook.com/groups/925287654243765/\" target=\"_blank\">ci trovi in questo gruppo aperto.</a></p>
<p>La partecipazione è libera, aperta a tutti gli interessati e appassionati a WordPress.</p>
<p>Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://it.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 17 Nov 2016 21:24:00 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 28 Oct 2016 09:19:52 GMT\";s:4:\"link\";s:61:\"<https://it.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}}s:5:\"build\";s:14:\"20161003130356\";}","no");
INSERT INTO `otot_options` VALUES("139","theme_mods_onyx_new","a:2:{i:0;b:0;s:16:\"header_textcolor\";s:6:\"d6d6d6\";}","yes");
INSERT INTO `otot_options` VALUES("146","_site_transient_timeout_browser_3761e5c4733742374ba4795bb2ae7f72","1476173001","no");
INSERT INTO `otot_options` VALUES("147","_site_transient_browser_3761e5c4733742374ba4795bb2ae7f72","a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"47.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","no");
INSERT INTO `otot_options` VALUES("730","_site_transient_timeout_available_translations","1480215633","no");
INSERT INTO `otot_options` VALUES("314","_site_transient_timeout_browser_5e06a2d838c1690d9a4db2dbdca80389","1478296418","no");
INSERT INTO `otot_options` VALUES("650","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/it_IT/wordpress-4.6.1.zip\";s:6:\"locale\";s:5:\"it_IT\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/it_IT/wordpress-4.6.1.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.6.1\";s:7:\"version\";s:5:\"4.6.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.4\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1480265244;s:15:\"version_checked\";s:5:\"4.6.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `otot_options` VALUES("731","_site_transient_available_translations","a:86:{s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-21 10:19:10\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.6.1/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-16 18:36:09\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-29 08:38:56\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-11 22:42:10\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-24 13:13:07\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-20 16:53:20\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-05 09:44:12\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.5.4\";s:7:\"updated\";s:19:\"2016-04-19 23:16:37\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.5.4/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-20 10:29:54\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.4.3\";s:7:\"updated\";s:19:\"2016-02-16 15:34:57\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.3/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-11 18:32:36\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:12:\"Čeština‎\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.4.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-01 16:18:09\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-29 14:03:59\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-15 12:56:13\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-24 19:08:40\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.6.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-24 19:08:22\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-15 12:59:43\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.6.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-09 20:42:31\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-11 23:19:29\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-11 22:36:25\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-16 11:54:12\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-20 07:14:07\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-12 02:18:44\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-02 22:25:56\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-29 15:07:52\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-17 17:56:31\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_GT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-31 08:03:58\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-17 22:11:44\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-19 13:48:04\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_AR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"4.3-RC\";s:7:\"updated\";s:19:\"2015-08-04 06:10:33\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.3-RC/es_CO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-17 12:34:44\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/es_VE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-22 16:41:36\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-27 18:10:49\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-23 20:20:40\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-15 18:30:48\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-10 18:42:25\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-02 11:49:52\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-15 19:02:20\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-21 15:44:17\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-08 11:09:06\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-25 19:56:49\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-03 13:43:01\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-07 15:12:28\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-27 09:44:27\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2016-02-04 07:13:54\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-22 05:34:53\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-25 00:32:39\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-09 11:19:59\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-01 15:23:06\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-29 11:51:34\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-24 07:18:31\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-11 21:29:34\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-26 17:38:44\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.5.4\";s:7:\"updated\";s:19:\"2016-05-12 13:55:28\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.5.4/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-13 20:38:52\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-14 14:18:43\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.13\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.13/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-16 13:09:49\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-14 13:24:10\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.6.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-26 10:08:38\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-28 08:58:28\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-23 13:45:11\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.6.1/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-22 09:54:16\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.13\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.13/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-24 10:39:55\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-26 20:21:25\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-21 00:44:33\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-30 19:40:04\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-13 10:00:06\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-11-04 18:38:43\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-14 07:00:01\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-12 16:41:17\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-29 09:19:19\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.6.1/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-12 07:04:13\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-11-27 15:51:36\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-16 10:50:15\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.5.4\";s:7:\"updated\";s:19:\"2016-06-22 12:27:05\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.5.4/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-18 10:43:17\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.6.1/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-09 01:01:25\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.4.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-10-10 01:34:25\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.6.1\";s:7:\"updated\";s:19:\"2016-08-18 13:53:15\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.6.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.5.4\";s:7:\"updated\";s:19:\"2016-04-17 03:29:01\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.5.4/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}","no");
INSERT INTO `otot_options` VALUES("535","category_children","a:0:{}","yes");
INSERT INTO `otot_options` VALUES("626","_transient_timeout_feed_13e268f84d68a386face41f0af9b3e48","1479461041","no");
INSERT INTO `otot_options` VALUES("627","_transient_feed_13e268f84d68a386face41f0af9b3e48","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"Italia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://it.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"mar, 15 Nov 2016 08:00:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"it-IT\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=4.7-beta4-39275\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Meetup Ragusa: 25 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Nov 2016 08:00:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"ragusa\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1411\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:386:\"Secondo Meetup a Ragusa! Un nuovo incontro: venerdì 25 novembre 2016, ci troviamo alle 18.00 presso 2.0 Due punto Zero &#8211; Via G. Tomasi 80, Ragusa.  Programma Vedremo più nel dettaglio come installare un tema e come funziona, e cominceremo a conoscere i plugin fondamentali per WP! Iscrizione Il WordPress Meetup è aperto a tutti, iscriviti all&#8217;evento su Meetup.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:554:\"<h1>Secondo Meetup a Ragusa!</h1>
<p>Un nuovo incontro: <strong>venerdì 25 novembre 2016, ci troviamo alle 18.00 presso </strong><strong>2.0 Due punto Zero &#8211; Via G. Tomasi 80, Ragusa. </strong></p>
<h2>Programma</h2>
<p>Vedremo più nel dettaglio come installare un tema e come funziona, e cominceremo a conoscere i plugin fondamentali per WP!</p>
<h2>Iscrizione</h2>
<p>Il WordPress Meetup è aperto a tutti, <a href=\"https://www.meetup.com/it-IT/wordpress-meetup-ragusa/events/235488483/\">iscriviti all&#8217;evento su Meetup.com</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://it.wordpress.org/news/2016/11/meetup-ragusa-25-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Meetup Bologna: 17 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Nov 2016 08:00:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"bologna\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1407\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:381:\"A Bologna gli appassionati di WordPress si incontrano giovedì 17 Novembre dalle ore 18.15, presso Working Capital #WCAP in Via Guglielmo Oberdan 22 Programma Sicurezza per WordPress Consigli e tecniche per mettere in sicurezza il proprio sito in WordPress. Altro speech da definire Iscrizione Per partecipare è sufficiente iscriversi all’evento su meetup.com, non mancare!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:652:\"<p>A Bologna gli appassionati di WordPress si incontrano <strong>giovedì 17 Novembre</strong> <strong>dalle ore 18.15</strong>, presso <strong>Working Capital #WCAP in Via Guglielmo Oberdan 22</strong></p>
<h2>Programma</h2>
<ul>
<li><strong>Sicurezza per WordPress</strong><br />
Consigli e tecniche per mettere in sicurezza il proprio sito in WordPress.<strong><br />
</strong></li>
<li><em>Altro speech da definire </em></li>
</ul>
<h2>Iscrizione</h2>
<p>Per partecipare è sufficiente <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Bologna/events/235439083/\" target=\"_blank\">iscriversi all’evento su meetup.com</a>, non mancare!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://it.wordpress.org/news/2016/11/meetup-bologna-17-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Meetup Padova: 15 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2016 08:00:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"padova\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1405\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:450:\"Il prossimo WordPress Meetup a Padova è Martedì 15 Novembre, alle 19, presso TalentLab (via Monselice 15/a, Padova)  Programma dell&#8217;incontro WordPress SEO Gli strumenti migliori per monitorare il traffico sul nostro sito WordPress, comprendere i dati e ottenere maggiore visibilità nei motori di ricerca. WooCommerce Dimostrazione pratica sulle principali caratteristiche del popolare plugin che trasforma WordPress in un vero [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1062:\"<p>Il prossimo WordPress Meetup a Padova è <strong>Martedì 15 Novembre, alle 19, presso TalentLab</strong> <strong>(via Monselice 15/a, Padova) </strong></p>
<h2>Programma dell&#8217;incontro</h2>
<ul>
<li><strong>WordPress SEO</strong><br />
Gli strumenti migliori per monitorare il traffico sul nostro sito WordPress, comprendere i dati e ottenere maggiore visibilità nei motori di ricerca.</li>
<li><strong>WooCommerce</strong><br />
Dimostrazione pratica sulle principali caratteristiche del popolare plugin che trasforma WordPress in un vero e-commerce. Dall’installazione alla scelta del tema ideale, cercheremo una risposta a molte curiosità. Quali tipologie di prodotto possiamo creare? Come possiamo gestire gli ordini? possiamo espandere le funzionalità di default in base alle nostre esigenze?</li>
</ul>
<h2>Come partecipare</h2>
<p><a href=\"http://www.meetup.com/it-IT/Padova-WordPress-Meetup/events/235438289/\" target=\"_blank\">Iscriviti all&#8217;evento su Meetup!</a> La partecipazione è libera e aperta a tutti. Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://it.wordpress.org/news/2016/11/meetup-padova-15-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"Partecipa alla giornata mondiale di traduzione di WP! Eventi locali in Italia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:115:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Nov 2016 10:38:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:6:\"Eventi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:9:\"Polyglots\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1384\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:428:\"Partecipa al WordPress Global Translation Day: in Italia sono organizzati eventi locali a Barletta, Catania, Milano, Roma, Torino, Vicenza. Segnati la data se vuoi aiutarci nella traduzione di WordPress (core, plugin, temi &#8230;) o se vuoi imparare come si traduce WordPress. Informazioni sugli eventi Barletta Quando: Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 20.00 Dove: Fabbrica42 &#8211; Corso Cavour [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5080:\"<p>Partecipa al <a href=\"https://wptranslationday.org\" target=\"_blank\">WordPress Global Translation Day</a>: in Italia sono organizzati eventi locali a Barletta, Catania, Milano, Roma, Torino, Vicenza.</p>
<p>Segnati la data se vuoi aiutarci nella traduzione di WordPress (core, plugin, temi &#8230;) o se vuoi imparare come si traduce WordPress.</p>
<h2>Informazioni sugli eventi</h2>
<h2>Barletta</h2>
<ul>
<li><strong>Quando:</strong> Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 20.00</li>
<li><strong>Dove:</strong> Fabbrica42 &#8211; Corso Cavour 32, Barletta</li>
<li><strong>Programma: </strong>
<ul>
<li>Introdurremo alla community di WordPress e alla sua attività italiana e mondiale;</li>
<li>Spiegheremo cos&#8217;è il progetto Polyglots e come poter contribuire alla traduzione di WordPress in tutte le sue parti, dai temi ai plugin;</li>
<li>Seguiremo alcune delle sessioni online mondiali organizzate dalla community sui temi come la localizzazione, l’internazionalizzazione, la mentorship e come tradurre WordPress nella tua lingua;</li>
<li>Tradurremo insieme WordPress</li>
</ul>
</li>
<li><strong>Iscrizione:</strong><a href=\"https://www.meetup.com/it-IT/Barletta-WordPress-Meetup/events/235327909/\" target=\"_blank\"> Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Catania</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 9.30 alle 12.00</li>
<li><strong>Dove: </strong>Karma Lab &#8211; Via J. Kennedy 6/8 &#8211; Aci Sant’Antonio &#8211; Catania</li>
<li><strong>Programma:</strong>
<ul>
<li><strong>Introduzione alla traduzione di temi e plugin </strong></li>
<li><strong>Gli strumenti necessari alla traduzione </strong></li>
<li><strong>GlotPress </strong></li>
<li><strong>Traduzione collettiva</strong></li>
</ul>
</li>
<li><strong>Iscrizione: </strong><a href=\"http://www.meetup.com/it-IT/Meetup-WordPress-Catania/events/235413788/\" target=\"_blank\">meetup.com</a></li>
</ul>
<h2></h2>
<h2>Milano</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 15.00 alle 19.00</li>
<li><strong>Dove:</strong> inCOWORK &#8211; via Lodovico Montegani, 23, Milano</li>
<li><strong>Programma: </strong>Traduciamo insieme! Non ti far bloccare dalla paura di “non sapere come e cosa fare” perché ti verrà spiegato come tradurre temi e plugin per WordPress e tanto altro.</li>
<li><strong>Iscrizione:</strong> <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Milano/events/235376830/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Roma</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 14.00 alle 18.00</li>
<li><strong>Dove: </strong>Talent Garden Roma &#8211; Via Giuseppe Andreoli, 9, Roma</li>
<li><strong>Programma: </strong>
<ul>
<li>14:00 &#8211; 14:30 &#8211; Registrazione dei partecipanti e tour del TAG</li>
<li>14:30 &#8211; 15:00 &#8211; Sessione di mentoring e coaching per chi non ha mai tradotto WP (gli altri inizieranno subito a tradurre)</li>
<li>15:00 &#8211; 18:00 &#8211; Si traducono più stringhe possibili per provare a battere ogni record mondiale!</li>
</ul>
</li>
<li><strong>Iscrizione: </strong><a href=\"https://www.meetup.com/it-IT/RomaWordPress/events/235150036/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Torino</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 10.00 alle 15.00</li>
<li><strong>Dove: </strong>Torteria Berlicabarbis &#8211; corso Moncalieri 214, Torino</li>
<li><strong>Programma: </strong>Tradurremo insieme e seguiremo gli streaming davanti a the e torte</li>
<li><strong>Iscrizione: </strong><a href=\"https://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/235173608/\" target=\"_blank\">Meetup.com</a></li>
</ul>
<h3></h3>
<h2>Vicenza (community di Verona e Padova)</h2>
<ul>
<li><strong>Quando: </strong>Sabato 12 Novembre 2016 &#8211; dalle 09.00 alle 12.00</li>
<li><strong>Dove: </strong>Villino Rossi di Povolaro &#8211; Via Molinetto, frazione Povolaro &#8211; Dueville (VI)</li>
<li><strong><strong>Programma:</strong></strong> Impariamo insieme a tradurre!</li>
<li><strong>Iscrizione</strong>: <a href=\"http://www.meetup.com/it-IT/Verona-WordPress-Meetup/events/235324992/?eventId=235324992\" target=\"_blank\">Meetup Verona</a></li>
</ul>
<p>&nbsp;</p>
<h2>Risorse utili</h2>
<p>Se i progetti di traduzione di WordPress ti sono nuovi, puoi vedere questi link:</p>
<ul>
<li><a href=\"https://it.wordpress.org/traduzioni/\">Guida per iniziare a tradurre (e guida di stile) </a></li>
<li><a href=\"https://translate.wordpress.org/projects/wp/dev/it/default/glossary\">Glossario </a></li>
<li><a href=\"https://it.wordpress.org/slack/\">Come iscriverti alla Community Italiana su Slack</a></li>
</ul>
<p>&nbsp;</p>
<p>Tradurre WordPress è un ottimo modo per essere coinvolti e contribuire al progetto. Durante il WordPress Global Translation Day, non solo sarai aiutato dai TE (Translation Editor) locali, ma anche da molti dei Polyglot dell&#8217;intera community WordPress di tutto il mondo.</p>
<p>Vieni a tradurre con noi!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"https://it.wordpress.org/news/2016/11/partecipa-alla-giornata-mondiale-di-traduzione-di-wp-eventi-locali-in-italia/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Meetup Torino Contributor Night: 11 novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Nov 2016 08:09:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"torino\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1390\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:427:\"Torino raddoppia! Da Novembre c&#8217;è un secondo appuntamento mensile della community WordPress torinese: le Contributor Nights, dedicate a studiare e lavorare insieme. Ogni mese selezioneremo uno dei team attivi su make.wordpress.org. Per alcuni team potremo contare sul supporto di lead, italiani e stranieri, mentre per altri ci autogestiremo con lo studio, leggendo la documentazione, andando a vedere quali [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2126:\"<h1>Torino raddoppia!</h1>
<p>Da Novembre c&#8217;è un secondo appuntamento mensile della community WordPress torinese: le <strong>Contributor Nights, dedicate a studiare e lavorare insieme.</strong><br />
Ogni mese selezioneremo uno dei team attivi su make.wordpress.org. Per alcuni team potremo contare sul supporto di lead, italiani e stranieri, mentre per altri ci autogestiremo con lo studio, leggendo la documentazione, andando a vedere quali sono le discussioni attive su trac e su Slack.</p>
<p><strong>Per questa prima serata siamo felici di avere con noi John Blackbourn, WordPress engineer presso Human Made e uno dei WordPress Core developer, che ci aiuterà a scoprire il team Core. </strong></p>
<p><strong>Appuntamento da Toolbox Coworking, Venerdì 11 novembre dalle 18:00 alle 21:45</strong></p>
<h2>Programma</h2>
<ul>
<li>18:00 &#8211; 18:30 &#8211; Registrazione/Installazione di VVV/Networking</li>
<li>18:30 &#8211; 19:30 &#8211; Intro to Core &#8211; la sessione di John sul team Core (in inglese)</li>
<li>19:30 &#8211; 21:45 &#8211; Studio, lavoro, domande, chiacchiere!</li>
</ul>
<h2>Per chi è questa serata</h2>
<ul>
<li>Per gli sviluppatori che vogliono iniziare a contribuire a WordPress</li>
<li>Per gli sviluppatori che già contribuiscono e vogliono confrontarsi con altri contributor esperti</li>
<li>Per chi vuole aiutare con test, documentazione, feedback, bug gardening (è comunque richiesta una buona conoscenza di WordPress e dei suoi componenti)</li>
</ul>
<h2>Come partecipare</h2>
<p>Porta il tuo computer e carica batteria. È fortemente consigliato arrivare preparati con un ambiente di sviluppo e WordPress già installati in locale.</p>
<h2>Iscrizione</h2>
<p>La partecipazione è libera,<a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/235251911/\" target=\"_blank\"> iscriviti all&#8217;evento su Meetup</a>. I posti disponibili sono limitati.<br />
<em>Se rispondete che siete interessati a venire e poi dovete cancellare, fatecelo sapere tempestivamente in modo da poter assegnare il vostro posto a un altro contributor. </em></p>
<p>&nbsp;</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://it.wordpress.org/news/2016/11/meetup-torino-contributor-night-11-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Meetup Piacenza: 7 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Nov 2016 12:30:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Piacenza\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1381\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:499:\"WordPress Meetup Piacenza, #2 Ci vediamo Lunedì 7 Novembre alle 18.30 presso Spazio2 &#8211; Via XXIV Maggio 51/53, Piacenza.  Programma 8:30-19:00 Benvenuto + Networking  Resoconto del recente WordCamp Milano. 19:00-19:30 Divagazioni sui temi di WordPress #2   La seconda parte dell&#8217;interessante presentazione sulla struttura, la scelta e la personalizzazione dei temi di WordPress. 19:30-20:00 Un plugin al giorno&#8230;  Nasce una nuova rubrica che ci accompagnerà [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1224:\"<h1>WordPress Meetup Piacenza, #2</h1>
<p>Ci vediamo <strong>Lunedì 7 Novembre alle 18.30 presso Spazio2 &#8211; Via XXIV Maggio 51/53, Piacenza. </strong></p>
<h2>Programma</h2>
<ul>
<li><strong>8:30-19:00 Benvenuto + Networking </strong><br />
Resoconto del recente WordCamp Milano.</li>
<li><strong>19:00-19:30 Divagazioni sui temi di WordPress #2  </strong><br />
La seconda parte dell&#8217;interessante presentazione sulla struttura, la scelta e la personalizzazione dei temi di WordPress.</li>
<li><strong>19:30-20:00 Un plugin al giorno&#8230;  </strong><br />
Nasce una nuova rubrica che ci accompagnerà in tutti i prossimi appuntamenti. Cominceremo cercando di stilare un elenco dei plugin che non dovrebbero mai mancare in una corretta installazione di WordPress.</li>
<li><strong>20:00-20:30 Networking </strong><br />
Spazio libero per discussioni, domande e risposte sugli argomenti trattati e su altri proposti dai partecipanti.</li>
</ul>
<h2>Come partecipare</h2>
<p>L&#8217;incontro è gratuito, aperto a tutti: basta <a href=\"http://www.meetup.com/it-IT/Piacenza-WordPress-Meetup/events/235177019/\" target=\"_blank\">iscriversi all&#8217;evento su Meetup. </a></p>
<p>Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://it.wordpress.org/news/2016/11/meetup-piacenza-7-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Meetup Milano: 8 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 Nov 2016 08:11:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"milano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1330\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:400:\"Dopo il WordCamp, ci rivediamo al Meetup! Appuntamento di Novembre con il WordPress Meetup di Milano: martedì 8 Novembre alle 19, come sempre presso MotorK Italia, Via Ludovico D&#8217;Aragona, 9, Milano.  Programma &#8220;WP API &#8211; The time is now&#8221;  Cosa sono le WordPress API? A cosa servono? Perché dovremmo usarle? E come? In questo talk cerchiamo di rispondere a un [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1062:\"<h1>Dopo il WordCamp, ci rivediamo al Meetup!</h1>
<p>Appuntamento di Novembre con il WordPress Meetup di Milano: <strong>martedì 8 Novembre alle 19</strong>, come sempre presso <strong>MotorK Italia, Via Ludovico D&#8217;Aragona, 9, Milano. </strong></p>
<h2>Programma</h2>
<ul>
<li><strong>&#8220;WP API &#8211; The time is now&#8221; </strong><br />
Cosa sono le WordPress API? A cosa servono? Perché dovremmo usarle? E come? In questo talk cerchiamo di rispondere a un pó di curiositá, domande, dubbi</li>
<li><strong>&#8220;AMP &#8211; Accelerated Mobile Pages&#8221; </strong><br />
What Is AMP? What are the benefits of Accelerated Mobile Pages? How do Accelerated Mobile Pages work? So it works for publishers, does it bring benefits for you too?</li>
</ul>
<h2>Per partecipare</h2>
<p>Tutti possono partecipare, è libero e gratuito! Devi solo <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Milano/events/235149483/\" target=\"_blank\">iscriverti all&#8217;evento su Meetup,</a> così sappiamo quanti siamo.<br />
Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://it.wordpress.org/news/2016/11/meetup-milano-8-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Meetup Torino: 9 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 07:11:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"torino\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1326\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:403:\"A Torino siamo a quota 16 Meetup! Il prossimo incontro è Mercoledì 9 Novembre, alle 18, come sempre presso Toolbox Coworking, Via Agostino da Montefeltro 2, Torino. Programma Cos&#8217;è e come si realizza un Plugin Come funziona l’Open Source? Non lo so, impariamo insieme? Come si partecipa L’ingresso è libero e gratuito e per partecipare è sufficiente registrarsi all’evento [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:664:\"<h1 class=\"text--display3\">A Torino siamo a quota 16 Meetup!</h1>
<p>Il prossimo incontro è <strong>Mercoledì 9 Novembre, alle 18, </strong>come sempre presso<strong> Toolbox Coworking</strong>, <strong>Via Agostino da Montefeltro 2, Torino.</strong></p>
<h2>Programma</h2>
<ul>
<li>Cos&#8217;è e come si realizza un Plugin</li>
<li>Come funziona l’Open Source? Non lo so, impariamo insieme?</li>
</ul>
<h2>Come si partecipa</h2>
<p>L’ingresso è libero e gratuito e per partecipare è sufficiente <a href=\"http://www.meetup.com/it-IT/WordPress-Meetup-Torino/events/234938015/\" target=\"_blank\">registrarsi all’evento su Meetup</a>. Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://it.wordpress.org/news/2016/10/meetup-torino-9-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"Primo Meetup a Brindisi: 4 Novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 07:00:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"brindisi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1334\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:383:\"Una nuova community locale: ecco il gruppo di Brindisi! Il primo incontro sarà Venerdì 4 Novembre, alle ore 17, presso FabLab Brindisi, via Fulvia 116 Brindisi.  Programma Il programma dell&#8217;incontro è sostanzialmente: conoscerci! Parleremo di Cos&#8217;è e cosa non è un meetup? Prossimi eventi della community Idee per i prossimi incontri Come si partecipa? In [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Giulia Tosato\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:802:\"<h1>Una nuova community locale: ecco il gruppo di Brindisi!</h1>
<p>Il primo incontro sarà <strong>Venerdì 4 Novembre, alle ore 17, presso FabLab Brindisi, via Fulvia 116 Brindisi. </strong></p>
<h2>Programma</h2>
<p>Il programma dell&#8217;incontro è sostanzialmente: conoscerci!</p>
<p>Parleremo di</p>
<ul>
<li>Cos&#8217;è e cosa non è un meetup?</li>
<li>Prossimi eventi della community</li>
<li>Idee per i prossimi incontri</li>
</ul>
<h2>Come si partecipa?</h2>
<p>In attesa del nostro &#8220;posto&#8221; su Meeetup.com, ci siamo organizzati su Facebook: <a href=\"https://www.facebook.com/groups/925287654243765/\" target=\"_blank\">ci trovi in questo gruppo aperto.</a></p>
<p>La partecipazione è libera, aperta a tutti gli interessati e appassionati a WordPress.</p>
<p>Ti aspettiamo!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://it.wordpress.org/news/2016/10/primo-meetup-a-brindisi-4-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Global WordPress Translation Day II – 12 novembre 2016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 28 Oct 2016 06:56:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:6:\"Eventi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:9:\"Polyglots\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://it.wordpress.org/?p=1312\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"Il team Polyglots di WordPress sta organizzando il secondo Global WordPress Translation Day per il 12 novembre. Tutti sono invitati a partecipare da tutto il mondo! Tradurre è uno dei modi più semplici e immediati per iniziare a contribuire al progetto open source WordPress. Il Global WordPress Translation Day è un&#8217;ottima occasione per conoscere le procedure [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Francesca Marano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4910:\"<p>Il team Polyglots di WordPress sta organizzando il secondo <a href=\"https://wptranslationday.org/\">Global WordPress Translation Day</a> per il 12 novembre. Tutti sono invitati a partecipare da tutto il mondo!</p>
<p><strong>Tradurre è uno dei modi più semplici e immediati per iniziare a contribuire al progetto open source WordPress</strong>. Il Global WordPress Translation Day è un&#8217;ottima occasione per conoscere le procedure che stanno dietro alla traduzione di WordPress, conoscere nuove persone e aiutare a tradurre WordPress in <a href=\"https://make.wordpress.org/polyglots/teams\">una delle 160 lingue al momento disponibili</a>.</p>
<h2>Unisciti a noi il 12 novembre, ovunque tu sia!</h2>
<p>La giornata di traduzioni inizia sabato 12 novembre alle 0:00 UTC e finisce 24 ore dopo. <a href=\"http://arewemeetingyet.com/UTC/2016-11-12/00:00/Global%20WordPress%20Translation%20Day%202\">Controlla a che ora inizia per te</a>! Puoi unirti all&#8217;inizio o a un orario qualsiasi che sia comodo per te durante la giornata.</p>
<h2>Cosa faremo?</h2>
<p>Giornate dal vivo di traduzioni sono in programma in giro per il mondo, anche in Italia, e sono un ottimo modo per andare a conoscere i contributor e iniziare a dare una mano. <a href=\"https://wptranslationday.org/#locations\">Controlla questa mappa</a> per vedere se c&#8217;è qualcosa nella tua zona. Non trovi nulla? <a href=\"https://make.wordpress.org/polyglots/2016/09/22/global-wordpress-translation-day-2-on-november-12th-2016/\">Organizza un evento nella tua città!</a></p>
<p>Puoi anche partecipare online, seguendo <a href=\"https://www.crowdcast.io/e/gwtd2/register\">la community in 24 ore di sessioni in streaming</a> in numerose lingue. Le sessioni copriranno temi come la localizzazione, l&#8217;internazionalizzazione, la mentorship e come tradurre WordPress nella tua lingua.</p>
<h2>A chi si rivolge?</h2>
<p>Che tu voglia imparare a tradurre o sia già un translation editor che vuole organizzare un team di persone per la propria lingua, il Translation Day fa per te! Anche chi si occupa di sviluppo troverà spunti interessanti nei talk di contributor esperti che parleranno di internazionalizzazione, ma anche di procedure per trovare traduttori per i propri temi e plugin. Insomma, c&#8217;è <strong>una sessione per tutti!</strong></p>
<h2>Partecipa!</h2>
<p>Partecipare è facile. Il 12 novembre, all&#8217;ora che preferisci, inizi a <a href=\"https://translate.wordpress.org/\">tradurre WordPress</a> o uno dei tuoi temi o plugin preferiti, mentre segui le sessioni in streaming che si alterneranno durante la giornata.</p>
<p>Vuoi prendere una parte attiva nell&#8217;organizzazione dell&#8217;evento? <a href=\"https://make.wordpress.org/polyglots/2016/09/22/global-wordpress-translation-day-2-on-november-12th-2016/\">Organizza un evento</a> dal vivo e invita la tua comunità locale a tradurre insieme il 12 novembre. Gli eventi possono essere formali e strutturati o completamente informali &#8211; prendi il tuo laptop, un paio di amici, vai in un bar della tua città e traduci per un&#8217;ora o due.</p>
<h3><em>Can you get involved if you only speak English?</em></h3>
<p><em>Absolutely! Even if you only speak English, there are great sessions about internationalization that can benefit every developer. There are also lots of English variants that need your help! For example, English is spoken and written differently in Australia, Canada, New Zealand, South Africa, and the United Kingdom. You can learn about these differences and why these variants are important during the sessions.</em></p>
<p>E se vuoi divertirti, prova a tradurre WordPress in emoji! Sì, abbiamo una traduzione anche in emoji! <img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30e.png\" alt=\"🌎\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30d.png\" alt=\"🌍\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /><img src=\"https://s.w.org/images/core/emoji/2.2.1/72x72/1f30f.png\" alt=\"🌏\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>
<h2>Domande?</h2>
<p>Se hai domande, puoi trovare il team Polyglots e gli organizzatori dell&#8217;evento sia nel canale internazionale <a href=\"http://wordpress.slack.com/messages/polyglots/\">#polyglots in Slack</a> che in quello <a href=\"https://italia-wp-community.slack.com/messages/polyglots\">italiano</a> e siamo felici di poterti aiutare! (Ottieni un invito a Slack su <a href=\"https://chat.wordpress.org/\">chat.wordpress.org</a>.)</p>
<h2>Iscriviti per partecipare sul <a href=\"https://wptranslationday.org/\">sito ufficiale</a>, ti aspettiamo!</h2>
<p><em>Post originale: <a href=\"https://wordpress.org/news/2016/10/join-us-again-for-global-wordpress-translation-day/\">https://wordpress.org/news/2016/10/join-us-again-for-global-wordpress-translation-day/</a> </em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://it.wordpress.org/news/2016/10/global-wordpress-translation-day-2-12-novembre-2016/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:30:\"https://it.wordpress.org/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 17 Nov 2016 21:24:02 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Tue, 15 Nov 2016 08:00:55 GMT\";s:4:\"link\";s:61:\"<https://it.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}}s:5:\"build\";s:14:\"20161003130356\";}","no");
INSERT INTO `otot_options` VALUES("469","searchandfilter_version","1.2.9","yes");
INSERT INTO `otot_options` VALUES("723","_site_transient_timeout_itsec_wp_upload_dir","1480285956","no");
INSERT INTO `otot_options` VALUES("724","_site_transient_itsec_wp_upload_dir","a:6:{s:4:\"path\";s:63:\"/home/ony59143/public_html/restyling/wp-content/uploads/2016/11\";s:3:\"url\";s:62:\"http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11\";s:6:\"subdir\";s:8:\"/2016/11\";s:7:\"basedir\";s:55:\"/home/ony59143/public_html/restyling/wp-content/uploads\";s:7:\"baseurl\";s:54:\"http://www.onyxsistemi.it/restyling/wp-content/uploads\";s:5:\"error\";b:0;}","no");
INSERT INTO `otot_options` VALUES("656","itsec_data","a:5:{s:5:\"build\";i:4044;s:20:\"activation_timestamp\";i:1479421156;s:17:\"already_supported\";b:0;s:15:\"setup_completed\";b:0;s:18:\"tooltips_dismissed\";b:0;}","no");
INSERT INTO `otot_options` VALUES("657","itsec_free_just_activated","1","no");
INSERT INTO `otot_options` VALUES("658","itsec_malware","a:2:{s:7:\"enabled\";b:0;s:7:\"api_key\";s:0:\"\";}","no");
INSERT INTO `otot_options` VALUES("659","itsec_initials","a:0:{}","no");
INSERT INTO `otot_options` VALUES("660","itsec_api_nag","1","no");
INSERT INTO `otot_options` VALUES("661","itsec_global","a:24:{s:18:\"notification_email\";a:1:{i:0;s:27:\"c.alberti@onyxtechnology.it\";}s:12:\"backup_email\";a:1:{i:0;s:27:\"c.alberti@onyxtechnology.it\";}s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:19:\"email_notifications\";b:1;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:12:\"log_rotation\";i:14;s:8:\"log_type\";i:0;s:12:\"log_location\";s:77:\"/home/ony59143/public_html/restyling/wp-content/uploads/ithemes-security/logs\";s:14:\"allow_tracking\";b:0;s:11:\"write_files\";b:0;s:10:\"nginx_file\";s:47:\"/home/ony59143/public_html/restyling/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:11:\"did_upgrade\";b:0;s:9:\"lock_file\";b:0;s:12:\"digest_email\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;s:8:\"log_info\";s:46:\"onyx-technology-TzdD7Rmg2W6D88qfLgbivRDjrZVlYH\";}","no");
INSERT INTO `otot_options` VALUES("738","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1480265670;s:7:\"checked\";a:17:{s:25:\"add-to-any/add-to-any.php\";s:5:\"1.7.2\";s:19:\"akismet/akismet.php\";s:3:\"3.2\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"4.5.1\";s:35:\"cookie-law-info/cookie-law-info.php\";s:5:\"1.5.3\";s:37:\"gestione-annunci/gestione-annunci.php\";s:3:\"1.0\";s:9:\"hello.php\";s:3:\"1.6\";s:17:\"iframe/iframe.php\";s:3:\"4.3\";s:41:\"better-wp-security/better-wp-security.php\";s:5:\"5.7.1\";s:47:\"linkedin-auto-publish/linkedin-auto-publish.php\";s:5:\"1.4.1\";s:36:\"microblog-poster/microblogposter.php\";s:5:\"1.7.6\";s:47:\"jonradio-private-site/jonradio-private-site.php\";s:6:\"2.14.1\";s:37:\"my-upload-images/my-upload-images.php\";s:7:\"1.3.8.2\";s:27:\"qtranslate-x/qtranslate.php\";s:7:\"3.4.6.8\";s:27:\"scroll-me-up/scrollmeup.php\";s:3:\"1.0\";s:31:\"search-filter/search-filter.php\";s:5:\"1.2.9\";s:33:\"w3-total-cache/w3-total-cache.php\";s:7:\"0.9.5.1\";s:35:\"wp-database-admin/wda_functions.php\";s:5:\"1.0.3\";}s:8:\"response\";a:1:{s:36:\"microblog-poster/microblogposter.php\";O:8:\"stdClass\":8:{s:2:\"id\";s:5:\"27896\";s:4:\"slug\";s:16:\"microblog-poster\";s:6:\"plugin\";s:36:\"microblog-poster/microblogposter.php\";s:11:\"new_version\";s:5:\"1.7.7\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/microblog-poster/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/microblog-poster.1.7.7.zip\";s:6:\"tested\";s:5:\"4.6.1\";s:13:\"compatibility\";O:8:\"stdClass\":1:{s:6:\"scalar\";O:8:\"stdClass\":1:{s:6:\"scalar\";b:0;}}}}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:12:\"qtranslate-x\";s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:7:\"3.4.6.8\";s:7:\"updated\";s:19:\"2016-11-12 16:13:42\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/qtranslate-x/3.4.6.8/it_IT.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:15:{s:25:\"add-to-any/add-to-any.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"429\";s:4:\"slug\";s:10:\"add-to-any\";s:6:\"plugin\";s:25:\"add-to-any/add-to-any.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/add-to-any/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/add-to-any.1.7.2.zip\";}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"3.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.3.2.zip\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:3:\"790\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"4.5.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.4.5.1.zip\";}s:35:\"cookie-law-info/cookie-law-info.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"31598\";s:4:\"slug\";s:15:\"cookie-law-info\";s:6:\"plugin\";s:35:\"cookie-law-info/cookie-law-info.php\";s:11:\"new_version\";s:5:\"1.5.3\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/cookie-law-info/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/cookie-law-info.1.5.3.zip\";}s:9:\"hello.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"3564\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";}s:17:\"iframe/iframe.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"22208\";s:4:\"slug\";s:6:\"iframe\";s:6:\"plugin\";s:17:\"iframe/iframe.php\";s:11:\"new_version\";s:3:\"4.3\";s:3:\"url\";s:37:\"https://wordpress.org/plugins/iframe/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/plugin/iframe.4.3.zip\";}s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":7:{s:2:\"id\";s:5:\"18308\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:5:\"5.7.1\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/better-wp-security.5.7.1.zip\";s:14:\"upgrade_notice\";s:88:\"Version 5.7.1 contains many bug fixes and improvements. It is recommended for all users.\";}s:47:\"linkedin-auto-publish/linkedin-auto-publish.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"43764\";s:4:\"slug\";s:21:\"linkedin-auto-publish\";s:6:\"plugin\";s:47:\"linkedin-auto-publish/linkedin-auto-publish.php\";s:11:\"new_version\";s:5:\"1.4.1\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/linkedin-auto-publish/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/linkedin-auto-publish.1.4.1.zip\";}s:47:\"jonradio-private-site/jonradio-private-site.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"32596\";s:4:\"slug\";s:21:\"jonradio-private-site\";s:6:\"plugin\";s:47:\"jonradio-private-site/jonradio-private-site.php\";s:11:\"new_version\";s:6:\"2.14.1\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/jonradio-private-site/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/jonradio-private-site.2.14.1.zip\";}s:37:\"my-upload-images/my-upload-images.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"56725\";s:4:\"slug\";s:16:\"my-upload-images\";s:6:\"plugin\";s:37:\"my-upload-images/my-upload-images.php\";s:11:\"new_version\";s:7:\"1.3.8.2\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/my-upload-images/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/my-upload-images.zip\";}s:27:\"qtranslate-x/qtranslate.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"56032\";s:4:\"slug\";s:12:\"qtranslate-x\";s:6:\"plugin\";s:27:\"qtranslate-x/qtranslate.php\";s:11:\"new_version\";s:7:\"3.4.6.8\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/qtranslate-x/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/qtranslate-x.3.4.6.8.zip\";}s:27:\"scroll-me-up/scrollmeup.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"60007\";s:4:\"slug\";s:12:\"scroll-me-up\";s:6:\"plugin\";s:27:\"scroll-me-up/scrollmeup.php\";s:11:\"new_version\";s:3:\"1.0\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/scroll-me-up/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/scroll-me-up.zip\";}s:31:\"search-filter/search-filter.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"43823\";s:4:\"slug\";s:13:\"search-filter\";s:6:\"plugin\";s:31:\"search-filter/search-filter.php\";s:11:\"new_version\";s:5:\"1.2.9\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/search-filter/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/search-filter.1.2.9.zip\";}s:33:\"w3-total-cache/w3-total-cache.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"9376\";s:4:\"slug\";s:14:\"w3-total-cache\";s:6:\"plugin\";s:33:\"w3-total-cache/w3-total-cache.php\";s:11:\"new_version\";s:7:\"0.9.5.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/w3-total-cache/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.5.1.zip\";}s:35:\"wp-database-admin/wda_functions.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"54842\";s:4:\"slug\";s:17:\"wp-database-admin\";s:6:\"plugin\";s:35:\"wp-database-admin/wda_functions.php\";s:11:\"new_version\";s:5:\"1.0.3\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/wp-database-admin/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wp-database-admin.zip\";}}}","no");
INSERT INTO `otot_options` VALUES("696","addtoany_options","a:33:{s:8:\"position\";s:6:\"bottom\";s:30:\"display_in_posts_on_front_page\";s:2:\"-1\";s:33:\"display_in_posts_on_archive_pages\";s:2:\"-1\";s:19:\"display_in_excerpts\";s:2:\"-1\";s:16:\"display_in_posts\";s:2:\"-1\";s:16:\"display_in_pages\";s:2:\"-1\";s:22:\"display_in_attachments\";s:2:\"-1\";s:15:\"display_in_feed\";s:2:\"-1\";s:7:\"onclick\";s:2:\"-1\";s:9:\"icon_size\";s:2:\"32\";s:6:\"button\";s:10:\"A2A_SVG_32\";s:13:\"button_custom\";s:0:\"\";s:17:\"button_show_count\";s:2:\"-1\";s:6:\"header\";s:0:\"\";s:23:\"additional_js_variables\";s:0:\"\";s:14:\"additional_css\";s:0:\"\";s:12:\"custom_icons\";s:2:\"-1\";s:16:\"custom_icons_url\";s:1:\"/\";s:17:\"custom_icons_type\";s:3:\"png\";s:18:\"custom_icons_width\";s:0:\"\";s:19:\"custom_icons_height\";s:0:\"\";s:10:\"inline_css\";s:1:\"1\";s:5:\"cache\";s:2:\"-1\";s:28:\"display_in_cpt_cookielawinfo\";s:2:\"-1\";s:22:\"display_in_cpt_annunci\";s:1:\"1\";s:11:\"button_text\";s:9:\"Condividi\";s:24:\"special_facebook_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:15:\"active_services\";a:3:{i:0;s:8:\"facebook\";i:1;s:7:\"twitter\";i:2;s:11:\"google_plus\";}s:29:\"special_facebook_like_options\";a:1:{s:4:\"verb\";s:4:\"like\";}s:29:\"special_twitter_tweet_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:30:\"special_google_plusone_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:33:\"special_google_plus_share_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}s:29:\"special_pinterest_pin_options\";a:1:{s:10:\"show_count\";s:2:\"-1\";}}","yes");
INSERT INTO `otot_options` VALUES("652","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1480265251;s:7:\"checked\";a:1:{s:8:\"onyx_new\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `otot_options` VALUES("662","microblogposter_who_can_auto_publish","[\"administrator\",\"editor\",\"author\",\"contributor\",\"subscriber\"]","yes");
INSERT INTO `otot_options` VALUES("663","itsec_temp_whitelist_ip","a:2:{s:14:\"151.28.235.107\";i:1480293247;s:12:\"151.25.7.255\";i:1480351640;}","no");
INSERT INTO `otot_options` VALUES("664","widget_a2a_share_save_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("665","widget_a2a_follow_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("667","itsec-storage","a:4:{s:6:\"backup\";a:9:{s:9:\"all_sites\";b:1;s:6:\"method\";i:1;s:8:\"location\";s:80:\"/home/ony59143/public_html/restyling/wp-content/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:3:{i:0;s:14:\"itsec_lockouts\";i:1;s:9:\"itsec_log\";i:2;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:30;s:8:\"last_run\";i:1479421156;}s:6:\"global\";a:27:{s:18:\"notification_email\";a:1:{i:0;s:27:\"c.alberti@onyxtechnology.it\";}s:12:\"backup_email\";a:1:{i:0;s:27:\"c.alberti@onyxtechnology.it\";}s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:19:\"email_notifications\";b:1;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:12:\"log_rotation\";i:14;s:8:\"log_type\";s:8:\"database\";s:12:\"log_location\";s:77:\"/home/ony59143/public_html/restyling/wp-content/uploads/ithemes-security/logs\";s:8:\"log_info\";s:46:\"onyx-technology-1E30pG94NL2Xz7lsLyVqyxyBKUGTyp\";s:14:\"allow_tracking\";b:0;s:11:\"write_files\";b:1;s:10:\"nginx_file\";s:47:\"/home/ony59143/public_html/restyling/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:11:\"did_upgrade\";b:0;s:9:\"lock_file\";b:0;s:12:\"digest_email\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;s:16:\"show_error_codes\";b:0;s:25:\"show_new_dashboard_notice\";b:0;s:19:\"show_security_check\";b:0;}s:19:\"network-brute-force\";a:5:{s:7:\"api_key\";s:0:\"\";s:10:\"api_secret\";s:0:\"\";s:10:\"enable_ban\";b:1;s:13:\"updates_optin\";b:1;s:7:\"api_nag\";b:0;}s:16:\"wordpress-tweaks\";a:11:{s:18:\"wlwmanifest_header\";b:0;s:14:\"edituri_header\";b:0;s:12:\"comment_spam\";b:0;s:11:\"file_editor\";b:1;s:14:\"disable_xmlrpc\";i:0;s:22:\"allow_xmlrpc_multiauth\";b:0;s:11:\"safe_jquery\";b:0;s:12:\"login_errors\";b:0;s:21:\"force_unique_nicename\";b:0;s:27:\"disable_unused_author_pages\";b:0;s:14:\"jquery_version\";s:6:\"1.12.4\";}}","no");
INSERT INTO `otot_options` VALUES("668","CookieLawInfo-0.9","a:43:{s:18:\"animate_speed_hide\";s:3:\"500\";s:18:\"animate_speed_show\";s:3:\"500\";s:10:\"background\";s:7:\"#77001b\";s:14:\"background_url\";s:0:\"\";s:6:\"border\";s:4:\"#444\";s:9:\"border_on\";b:1;s:13:\"button_1_text\";s:2:\"OK\";s:12:\"button_1_url\";s:1:\"#\";s:15:\"button_1_action\";s:27:\"#cookie_action_close_header\";s:20:\"button_1_link_colour\";s:4:\"#fff\";s:16:\"button_1_new_win\";b:1;s:18:\"button_1_as_button\";b:1;s:22:\"button_1_button_colour\";s:7:\"#4f4f4f\";s:20:\"button_1_button_size\";s:6:\"medium\";s:13:\"button_2_text\";s:17:\"Più Informazioni\";s:12:\"button_2_url\";s:43:\"http://www.onyxsistemi.it/restyling/privacy\";s:15:\"button_2_action\";s:17:\"CONSTANT_OPEN_URL\";s:20:\"button_2_link_colour\";s:4:\"#444\";s:16:\"button_2_new_win\";b:1;s:18:\"button_2_as_button\";b:0;s:22:\"button_2_button_colour\";s:4:\"#333\";s:20:\"button_2_button_size\";s:6:\"medium\";s:11:\"font_family\";s:7:\"inherit\";s:10:\"header_fix\";b:0;s:5:\"is_on\";b:1;s:19:\"notify_animate_hide\";b:1;s:19:\"notify_animate_show\";b:1;s:13:\"notify_div_id\";s:20:\"#cookie-law-info-bar\";s:26:\"notify_position_horizontal\";s:5:\"right\";s:24:\"notify_position_vertical\";s:6:\"bottom\";s:14:\"notify_message\";s:95:\"Questo sito usa i cookie per consentirti una navigazione migliore.[cookie_button] [cookie_link]\";s:12:\"scroll_close\";b:1;s:19:\"scroll_close_reload\";b:0;s:20:\"showagain_background\";s:4:\"#fff\";s:16:\"showagain_border\";s:4:\"#000\";s:14:\"showagain_text\";s:23:\"Privacy & Cookie Policy\";s:16:\"showagain_div_id\";s:22:\"#cookie-law-info-again\";s:13:\"showagain_tab\";b:0;s:20:\"showagain_x_position\";s:5:\"100px\";s:4:\"text\";s:7:\"#ffffff\";s:17:\"use_colour_picker\";b:1;s:12:\"show_once_yn\";b:0;s:9:\"show_once\";s:5:\"10000\";}","yes");
INSERT INTO `otot_options` VALUES("675","mui_options","a:10:{s:8:\"posttype\";a:1:{i:0;s:7:\"annunci\";}s:5:\"pages\";s:0:\"\";s:10:\"keepvalues\";s:4:\"keep\";s:9:\"postthumb\";s:4:\"none\";s:6:\"maxnum\";s:0:\"\";s:8:\"imgtitle\";s:7:\"display\";s:10:\"editbutton\";s:4:\"none\";s:9:\"imgheight\";s:3:\"120\";s:5:\"title\";s:17:\"Aggiungi Immagine\";s:8:\"position\";s:4:\"side\";}","yes");
INSERT INTO `otot_options` VALUES("739","qtranslate_admin_notices","a:2:{s:11:\"next_thanks\";i:1480265717;s:26:\"survey-translation-service\";i:1480265787;}","yes");
INSERT INTO `otot_options` VALUES("740","qtranslate_enabled_languages","a:2:{i:0;s:2:\"it\";i:1;s:2:\"en\";}","yes");
INSERT INTO `otot_options` VALUES("741","qtranslate_default_language","it","yes");
INSERT INTO `otot_options` VALUES("742","qtranslate_version_previous","34680","yes");
INSERT INTO `otot_options` VALUES("743","qtranslate_versions","a:2:{i:34680;i:1480265717;s:1:\"l\";i:1480265717;}","yes");
INSERT INTO `otot_options` VALUES("744","qtranslate_admin_config","a:7:{s:4:\"post\";a:4:{s:5:\"pages\";a:2:{s:8:\"post.php\";s:0:\"\";s:12:\"post-new.php\";s:0:\"\";}s:7:\"anchors\";a:1:{s:17:\"post-body-content\";a:1:{s:5:\"where\";s:10:\"first last\";}}s:5:\"forms\";a:2:{s:4:\"post\";a:1:{s:6:\"fields\";a:8:{s:5:\"title\";a:0:{}s:7:\"excerpt\";a:0:{}s:18:\"attachment_caption\";a:0:{}s:14:\"attachment_alt\";a:0:{}s:13:\"view-post-btn\";a:1:{s:6:\"encode\";s:7:\"display\";}s:14:\"wp-editor-area\";a:1:{s:6:\"jquery\";s:15:\".wp-editor-area\";}s:15:\"gallery-caption\";a:2:{s:6:\"jquery\";s:16:\".gallery-caption\";s:6:\"encode\";s:4:\"none\";}s:15:\"wp-caption-text\";a:2:{s:6:\"jquery\";s:16:\".wp-caption-text\";s:6:\"encode\";s:7:\"display\";}}}s:14:\"wpbody-content\";a:1:{s:6:\"fields\";a:2:{s:7:\"wrap-h1\";a:2:{s:6:\"jquery\";s:8:\".wrap h1\";s:6:\"encode\";s:7:\"display\";}s:7:\"wrap-h2\";a:2:{s:6:\"jquery\";s:8:\".wrap h2\";s:6:\"encode\";s:7:\"display\";}}}}s:7:\"js-exec\";a:1:{s:9:\"post-exec\";a:1:{s:3:\"src\";s:27:\"./admin/js/post-exec.min.js\";}}}s:15:\"options-general\";a:3:{s:14:\"preg_delimiter\";s:1:\"#\";s:5:\"pages\";a:1:{s:19:\"options-general.php\";s:21:\"^(?!.*page=[^=&]+).*$\";}s:5:\"forms\";a:1:{s:7:\"options\";a:1:{s:6:\"fields\";a:3:{s:8:\"blogname\";a:0:{}s:15:\"blogdescription\";a:0:{}s:10:\"head-title\";a:2:{s:6:\"jquery\";s:10:\"head title\";s:6:\"encode\";s:7:\"display\";}}}}}s:7:\"widgets\";a:4:{s:5:\"pages\";a:1:{s:11:\"widgets.php\";s:0:\"\";}s:7:\"anchors\";a:1:{s:13:\"widgets-right\";a:1:{s:5:\"where\";s:12:\"before after\";}}s:5:\"forms\";a:1:{s:13:\"widgets-right\";a:1:{s:6:\"fields\";a:3:{s:12:\"widget-title\";a:1:{s:6:\"jquery\";s:34:\"input[id^=\'widget-\'][id$=\'-title\']\";}s:16:\"widget-text-text\";a:1:{s:6:\"jquery\";s:41:\"textarea[id^=\'widget-text-\'][id$=\'-text\']\";}s:15:\"in-widget-title\";a:2:{s:6:\"jquery\";s:20:\"span.in-widget-title\";s:6:\"encode\";s:7:\"display\";}}}}s:7:\"js-exec\";a:1:{s:12:\"widgets-exec\";a:1:{s:3:\"src\";s:30:\"./admin/js/widgets-exec.min.js\";}}}s:8:\"edit-tag\";a:3:{s:5:\"pages\";a:2:{s:8:\"term.php\";s:0:\"\";s:13:\"edit-tags.php\";s:11:\"action=edit\";}s:5:\"forms\";a:1:{s:7:\"edittag\";a:1:{s:6:\"fields\";a:3:{s:4:\"name\";a:0:{}s:11:\"description\";a:0:{}s:6:\"parent\";a:1:{s:6:\"encode\";s:7:\"display\";}}}}s:7:\"js-exec\";a:1:{s:13:\"edit-tag-exec\";a:1:{s:3:\"src\";s:31:\"./admin/js/edit-tag-exec.min.js\";}}}s:9:\"edit-tags\";a:5:{s:14:\"preg_delimiter\";s:1:\"#\";s:5:\"pages\";a:1:{s:13:\"edit-tags.php\";s:21:\"^(?!.*action=edit).*$\";}s:7:\"anchors\";a:1:{s:12:\"posts-filter\";a:1:{s:5:\"where\";s:12:\"before after\";}}s:5:\"forms\";a:3:{s:6:\"addtag\";a:1:{s:6:\"fields\";a:3:{s:8:\"tag-name\";a:0:{}s:15:\"tag-description\";a:0:{}s:6:\"parent\";a:1:{s:6:\"encode\";s:7:\"display\";}}}s:8:\"col-left\";a:1:{s:6:\"fields\";a:1:{s:8:\"tagcloud\";a:2:{s:6:\"jquery\";s:13:\".tagcloud > a\";s:6:\"encode\";s:7:\"display\";}}}s:8:\"the-list\";a:1:{s:6:\"fields\";a:2:{s:9:\"row-title\";a:2:{s:6:\"jquery\";s:10:\".row-title\";s:6:\"encode\";s:7:\"display\";}s:11:\"description\";a:2:{s:6:\"jquery\";s:12:\".description\";s:6:\"encode\";s:7:\"display\";}}}}s:7:\"js-exec\";a:1:{s:14:\"edit-tags-exec\";a:1:{s:3:\"src\";s:32:\"./admin/js/edit-tags-exec.min.js\";}}}s:9:\"nav-menus\";a:4:{s:5:\"pages\";a:1:{s:13:\"nav-menus.php\";s:23:\"action=edit|menu=\\d+|^$\";}s:7:\"anchors\";a:1:{s:12:\"menu-to-edit\";a:1:{s:5:\"where\";s:12:\"before after\";}}s:5:\"forms\";a:2:{s:15:\"update-nav-menu\";a:1:{s:6:\"fields\";a:5:{s:5:\"title\";a:1:{s:6:\"jquery\";s:27:\"[id^=edit-menu-item-title-]\";}s:10:\"attr-title\";a:1:{s:6:\"jquery\";s:32:\"[id^=edit-menu-item-attr-title-]\";}s:11:\"description\";a:1:{s:6:\"jquery\";s:33:\"[id^=edit-menu-item-description-]\";}s:10:\"span.title\";a:2:{s:6:\"jquery\";s:20:\"span.menu-item-title\";s:6:\"encode\";s:7:\"display\";}s:16:\"link-to-original\";a:2:{s:6:\"jquery\";s:20:\".link-to-original >a\";s:6:\"encode\";s:7:\"display\";}}}s:14:\"side-sortables\";a:1:{s:6:\"fields\";a:2:{s:11:\"label.title\";a:2:{s:6:\"jquery\";s:21:\"label.menu-item-title\";s:6:\"encode\";s:7:\"display\";}s:23:\"accordion-section-title\";a:2:{s:6:\"jquery\";s:26:\"h3.accordion-section-title\";s:6:\"encode\";s:7:\"display\";}}}}s:7:\"js-exec\";a:1:{s:14:\"nav-menus-exec\";a:1:{s:3:\"src\";s:32:\"./admin/js/nav-menus-exec.min.js\";}}}s:9:\"all-pages\";a:1:{s:7:\"filters\";a:1:{s:4:\"text\";a:1:{s:11:\"admin_title\";s:2:\"20\";}}}}","yes");
INSERT INTO `otot_options` VALUES("745","qtranslate_front_config","a:1:{s:9:\"all-pages\";a:1:{s:7:\"filters\";a:3:{s:4:\"text\";a:11:{s:12:\"widget_title\";s:2:\"20\";s:11:\"widget_text\";s:2:\"20\";s:9:\"the_title\";s:2:\"20\";s:20:\"category_description\";s:2:\"20\";s:9:\"list_cats\";s:2:\"20\";s:16:\"wp_dropdown_cats\";s:2:\"20\";s:9:\"term_name\";s:2:\"20\";s:18:\"get_comment_author\";s:2:\"20\";s:10:\"the_author\";s:2:\"20\";s:9:\"tml_title\";s:2:\"20\";s:16:\"term_description\";s:2:\"20\";}s:4:\"term\";a:10:{s:7:\"cat_row\";s:1:\"0\";s:8:\"cat_rows\";s:1:\"0\";s:19:\"wp_get_object_terms\";s:1:\"0\";s:16:\"single_cat_title\";s:1:\"0\";s:16:\"single_tag_title\";s:1:\"0\";s:17:\"single_term_title\";s:1:\"0\";s:12:\"the_category\";s:1:\"0\";s:8:\"get_term\";s:1:\"0\";s:9:\"get_terms\";s:1:\"0\";s:12:\"get_category\";s:1:\"0\";}s:3:\"url\";a:16:{s:16:\"author_feed_link\";s:2:\"10\";s:11:\"author_link\";s:2:\"10\";s:27:\"get_comment_author_url_link\";s:2:\"10\";s:23:\"post_comments_feed_link\";s:2:\"10\";s:8:\"day_link\";s:2:\"10\";s:10:\"month_link\";s:2:\"10\";s:9:\"year_link\";s:2:\"10\";s:9:\"page_link\";s:2:\"10\";s:9:\"post_link\";s:2:\"10\";s:13:\"category_link\";s:2:\"10\";s:18:\"category_feed_link\";s:2:\"10\";s:8:\"tag_link\";s:2:\"10\";s:9:\"term_link\";s:2:\"10\";s:13:\"the_permalink\";s:2:\"10\";s:9:\"feed_link\";s:2:\"10\";s:13:\"tag_feed_link\";s:2:\"10\";}}}}","yes");
INSERT INTO `otot_options` VALUES("746","widget_qtranslate","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `otot_options` VALUES("747","qtranslate_next_thanks","1501692917","yes");
INSERT INTO `otot_options` VALUES("748","qtranslate_next_update_mo","1480870517","yes");


DROP TABLE IF EXISTS `otot_postmeta`;

CREATE TABLE `otot_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=745 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("165","84","_thumbnail_id","86");
INSERT INTO `otot_postmeta` VALUES("161","84","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("162","84","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("163","86","_wp_attached_file","2016/11/assistenza-sistemistica.jpg");
INSERT INTO `otot_postmeta` VALUES("164","86","_wp_attachment_metadata","a:5:{s:5:\"width\";i:500;s:6:\"height\";i:334;s:4:\"file\";s:35:\"2016/11/assistenza-sistemistica.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"assistenza-sistemistica-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"assistenza-sistemistica-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("160","84","_edit_lock","1478982954:1");
INSERT INTO `otot_postmeta` VALUES("21","12","_edit_lock","1476276008:1");
INSERT INTO `otot_postmeta` VALUES("22","13","_edit_lock","1476277573:1");
INSERT INTO `otot_postmeta` VALUES("23","14","_edit_lock","1476278368:1");
INSERT INTO `otot_postmeta` VALUES("24","18","_edit_lock","1478641496:1");
INSERT INTO `otot_postmeta` VALUES("33","22","_wp_page_template","page-chi-siamo.php");
INSERT INTO `otot_postmeta` VALUES("32","22","_edit_lock","1477047257:1");
INSERT INTO `otot_postmeta` VALUES("34","24","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("31","22","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("35","24","_edit_lock","1477060944:1");
INSERT INTO `otot_postmeta` VALUES("36","25","_wp_attached_file","2016/10/stefania-romano-resize.jpg");
INSERT INTO `otot_postmeta` VALUES("37","25","_wp_attachment_metadata","a:5:{s:5:\"width\";i:345;s:6:\"height\";i:345;s:4:\"file\";s:34:\"2016/10/stefania-romano-resize.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"stefania-romano-resize-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"stefania-romano-resize-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("38","24","_thumbnail_id","25");
INSERT INTO `otot_postmeta` VALUES("41","28","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("42","28","_edit_lock","1477060673:1");
INSERT INTO `otot_postmeta` VALUES("43","29","_wp_attached_file","2016/10/flavia-anzalone.jpg");
INSERT INTO `otot_postmeta` VALUES("44","29","_wp_attachment_metadata","a:5:{s:5:\"width\";i:375;s:6:\"height\";i:375;s:4:\"file\";s:27:\"2016/10/flavia-anzalone.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"flavia-anzalone-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"flavia-anzalone-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("45","28","_thumbnail_id","29");
INSERT INTO `otot_postmeta` VALUES("47","31","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("48","31","_edit_lock","1477061494:1");
INSERT INTO `otot_postmeta` VALUES("49","32","_wp_attached_file","2016/10/Flammia-e1477061322690.jpg");
INSERT INTO `otot_postmeta` VALUES("50","32","_wp_attachment_metadata","a:5:{s:5:\"width\";i:450;s:6:\"height\";i:802;s:4:\"file\";s:34:\"2016/10/Flammia-e1477061322690.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Flammia-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Flammia-168x300.jpg\";s:5:\"width\";i:168;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Flammia-768x1368.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1368;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Flammia-575x1024.jpg\";s:5:\"width\";i:575;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.4\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:18:\"Lumia 532 Dual SIM\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1446628060\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.03\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("51","31","_thumbnail_id","32");
INSERT INTO `otot_postmeta` VALUES("53","34","_wp_attached_file","2016/10/stefania-romano.jpg");
INSERT INTO `otot_postmeta` VALUES("54","34","_wp_attachment_metadata","a:5:{s:5:\"width\";i:255;s:6:\"height\";i:255;s:4:\"file\";s:27:\"2016/10/stefania-romano.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"stefania-romano-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("56","35","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("57","35","_edit_lock","1477061038:1");
INSERT INTO `otot_postmeta` VALUES("58","36","_wp_attached_file","2016/10/17.png");
INSERT INTO `otot_postmeta` VALUES("59","36","_wp_attachment_metadata","a:5:{s:5:\"width\";i:538;s:6:\"height\";i:486;s:4:\"file\";s:14:\"2016/10/17.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"17-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"17-300x271.png\";s:5:\"width\";i:300;s:6:\"height\";i:271;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("60","35","_thumbnail_id","36");
INSERT INTO `otot_postmeta` VALUES("62","32","_wp_attachment_backup_sizes","a:1:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:916;s:6:\"height\";i:1632;s:4:\"file\";s:11:\"Flammia.jpg\";}}");
INSERT INTO `otot_postmeta` VALUES("64","38","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("65","38","_edit_lock","1477292569:1");
INSERT INTO `otot_postmeta` VALUES("66","39","_wp_attached_file","2016/10/ilaria-alborghetti.jpg");
INSERT INTO `otot_postmeta` VALUES("67","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:345;s:6:\"height\";i:613;s:4:\"file\";s:30:\"2016/10/ilaria-alborghetti.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"ilaria-alborghetti-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"ilaria-alborghetti-169x300.jpg\";s:5:\"width\";i:169;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("68","38","_thumbnail_id","39");
INSERT INTO `otot_postmeta` VALUES("70","42","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("71","42","_edit_lock","1477691615:1");
INSERT INTO `otot_postmeta` VALUES("72","43","_wp_attached_file","2016/10/vittoria.png");
INSERT INTO `otot_postmeta` VALUES("73","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:256;s:6:\"height\";i:280;s:4:\"file\";s:20:\"2016/10/vittoria.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"vittoria-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("74","42","_thumbnail_id","43");
INSERT INTO `otot_postmeta` VALUES("76","45","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("77","45","_edit_lock","1477691747:1");
INSERT INTO `otot_postmeta` VALUES("78","46","_wp_attached_file","2016/10/Aniello.jpg");
INSERT INTO `otot_postmeta` VALUES("79","46","_wp_attachment_metadata","a:5:{s:5:\"width\";i:258;s:6:\"height\";i:258;s:4:\"file\";s:19:\"2016/10/Aniello.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Aniello-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("80","45","_thumbnail_id","46");
INSERT INTO `otot_postmeta` VALUES("82","48","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("83","48","_edit_lock","1477691916:1");
INSERT INTO `otot_postmeta` VALUES("84","49","_wp_attached_file","2016/10/Camilletti.jpg");
INSERT INTO `otot_postmeta` VALUES("85","49","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:22:\"2016/10/Camilletti.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"Camilletti-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"Camilletti-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("86","48","_thumbnail_id","49");
INSERT INTO `otot_postmeta` VALUES("88","51","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("89","51","_edit_lock","1477691984:1");
INSERT INTO `otot_postmeta` VALUES("90","52","_wp_attached_file","2016/10/giovanna-la-gatta.jpg");
INSERT INTO `otot_postmeta` VALUES("91","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:337;s:6:\"height\";i:337;s:4:\"file\";s:29:\"2016/10/giovanna-la-gatta.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"giovanna-la-gatta-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"giovanna-la-gatta-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("92","51","_thumbnail_id","52");
INSERT INTO `otot_postmeta` VALUES("94","54","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("95","54","_edit_lock","1477692092:1");
INSERT INTO `otot_postmeta` VALUES("96","55","_wp_attached_file","2016/10/carlo-eugenio-romano.jpg");
INSERT INTO `otot_postmeta` VALUES("97","55","_wp_attachment_metadata","a:5:{s:5:\"width\";i:160;s:6:\"height\";i:160;s:4:\"file\";s:32:\"2016/10/carlo-eugenio-romano.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"carlo-eugenio-romano-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("98","54","_thumbnail_id","55");
INSERT INTO `otot_postmeta` VALUES("100","57","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("101","57","_edit_lock","1477692240:1");
INSERT INTO `otot_postmeta` VALUES("102","58","_wp_attached_file","2016/10/andrea-nobili.jpg");
INSERT INTO `otot_postmeta` VALUES("103","58","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:25:\"2016/10/andrea-nobili.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"andrea-nobili-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"andrea-nobili-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("104","57","_thumbnail_id","58");
INSERT INTO `otot_postmeta` VALUES("107","60","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("108","60","_edit_lock","1477692347:1");
INSERT INTO `otot_postmeta` VALUES("109","61","_wp_attached_file","2016/10/tony-rossi.jpg");
INSERT INTO `otot_postmeta` VALUES("110","61","_wp_attachment_metadata","a:5:{s:5:\"width\";i:345;s:6:\"height\";i:380;s:4:\"file\";s:22:\"2016/10/tony-rossi.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"tony-rossi-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"tony-rossi-272x300.jpg\";s:5:\"width\";i:272;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("111","60","_thumbnail_id","61");
INSERT INTO `otot_postmeta` VALUES("113","64","_edit_lock","1477864084:1");
INSERT INTO `otot_postmeta` VALUES("114","64","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("115","65","_form","<label> Il tuo nome (richiesto)
    [text* your-name] </label>

<label> La tua email (richiesto)
    [email* your-email] </label>

<label> Oggetto
    [text your-subject] </label>

<label> Il tuo messaggio
    [textarea your-message] </label>

[submit \"Invia\"]");
INSERT INTO `otot_postmeta` VALUES("116","65","_mail","a:8:{s:7:\"subject\";s:32:\"Onyx Technology \"[your-subject]\"\";s:6:\"sender\";s:38:\"[your-name] <wordpress@onyxsistemi.it>\";s:4:\"body\";s:208:\"Da: [your-name] <[your-email]>
Oggetto: [your-subject]

Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:27:\"c.alberti@onyxtechnology.it\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `otot_postmeta` VALUES("117","65","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:32:\"Onyx Technology \"[your-subject]\"\";s:6:\"sender\";s:42:\"Onyx Technology <wordpress@onyxsistemi.it>\";s:4:\"body\";s:152:\"Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:37:\"Reply-To: c.alberti@onyxtechnology.it\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}");
INSERT INTO `otot_postmeta` VALUES("118","65","_messages","a:8:{s:12:\"mail_sent_ok\";s:46:\"Grazie per il tuo messaggio. È stato inviato.\";s:12:\"mail_sent_ng\";s:88:\"Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.\";s:16:\"validation_error\";s:69:\"Uno o più campi hanno errori. Per favore controlla e prova di nuovo.\";s:4:\"spam\";s:88:\"Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.\";s:12:\"accept_terms\";s:70:\"Devi accettare termini e condizioni prima di inviare il tuo messaggio.\";s:16:\"invalid_required\";s:22:\"Il campo è richiesto.\";s:16:\"invalid_too_long\";s:25:\"Il campo è troppo lungo.\";s:17:\"invalid_too_short\";s:25:\"Il campo è troppo corto.\";}");
INSERT INTO `otot_postmeta` VALUES("119","65","_additional_settings","");
INSERT INTO `otot_postmeta` VALUES("120","65","_locale","it_IT");
INSERT INTO `otot_postmeta` VALUES("121","66","_form","<label> Il tuo nome *
    [text* your-name] </label>

<label> La tua email *
    [email* your-email] </label>

<label> Incolla qui il titolo dell\'annuncio * 
[text* titolo-annuncio]</label>

<label> Curriculum vitae [file* curriculum filetypes:doc|docx|pdf]</label>

Autorizzo Onyx Technology al trattamento dei dati [acceptance accetto-condizioni]
[submit \"Invia\"]");
INSERT INTO `otot_postmeta` VALUES("122","66","_mail","a:8:{s:7:\"subject\";s:49:\"E\' arrivata una nuova candidatura per un annuncio\";s:6:\"sender\";s:38:\"[your-name] <wordpress@onyxsistemi.it>\";s:4:\"body\";s:363:\"Da: [your-name] <[your-email]>
Oggetto: E\' arrivata una nuova candidatura per un annuncio

Ciao HR,
è arrivata una nuova candidatura per l\'annuncio \"[titolo-annuncio]\" pubblicato sul sito di Onyx Technology. Il nome del candidato è [your-name].

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:27:\"c.alberti@onyxtechnology.it\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:12:\"[curriculum]\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `otot_postmeta` VALUES("123","66","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:32:\"Onyx Technology \"[your-subject]\"\";s:6:\"sender\";s:42:\"Onyx Technology <wordpress@onyxsistemi.it>\";s:4:\"body\";s:152:\"Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:37:\"Reply-To: c.alberti@onyxtechnology.it\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `otot_postmeta` VALUES("124","66","_messages","a:23:{s:12:\"mail_sent_ok\";s:36:\"La tua candidatura è stata inviata.\";s:12:\"mail_sent_ng\";s:92:\"Si è verificato un errore durante l\'invio della tua candidatura. Per favore prova di nuovo.\";s:16:\"validation_error\";s:69:\"Uno o più campi hanno errori. Per favore controlla e prova di nuovo.\";s:4:\"spam\";s:88:\"Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.\";s:12:\"accept_terms\";s:70:\"Devi accettare termini e condizioni prima di inviare il tuo messaggio.\";s:16:\"invalid_required\";s:22:\"Il campo è richiesto.\";s:16:\"invalid_too_long\";s:25:\"Il campo è troppo lungo.\";s:17:\"invalid_too_short\";s:25:\"Il campo è troppo corto.\";s:12:\"invalid_date\";s:38:\"Il formato della data non è corretto.\";s:14:\"date_too_early\";s:50:\"La data è antecedente alla prima data consentita.\";s:13:\"date_too_late\";s:49:\"La data è successiva all\'ultima data consentita.\";s:13:\"upload_failed\";s:71:\"Si è verificato un errore sconosciuto durante il caricamento del file.\";s:24:\"upload_file_type_invalid\";s:56:\"Non sei abilitato al caricamenti di file di questo tipo.\";s:21:\"upload_file_too_large\";s:25:\"Il file è troppo grande.\";s:23:\"upload_failed_php_error\";s:48:\"Si è verificato un errore nel caricare il file.\";s:14:\"invalid_number\";s:34:\"Il formato numerico non è valido.\";s:16:\"number_too_small\";s:44:\"Il numero è inferiore al minimo consentito.\";s:16:\"number_too_large\";s:45:\"Il numero è superiore al massimo consentito.\";s:23:\"quiz_answer_not_correct\";s:36:\"La risposta al quiz non è corretta.\";s:17:\"captcha_not_match\";s:41:\"Il codice che hai inserito non è valido.\";s:13:\"invalid_email\";s:42:\"L\'indirizzo e-mail inserito non è valido.\";s:11:\"invalid_url\";s:20:\"L\'URL non è valido.\";s:11:\"invalid_tel\";s:36:\"Il numero di telefono non è valido.\";}");
INSERT INTO `otot_postmeta` VALUES("125","66","_additional_settings","");
INSERT INTO `otot_postmeta` VALUES("126","66","_locale","it_IT");
INSERT INTO `otot_postmeta` VALUES("127","68","url-associato","http://wordpress.stackexchange.com/questions/8569/wp-insert-post-php-function-and-custom-fields");
INSERT INTO `otot_postmeta` VALUES("128","69","_edit_lock","1479129651:3");
INSERT INTO `otot_postmeta` VALUES("129","69","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("132","72","_form","<label> Il tuo nome *
    [text* your-name] </label>

<label> La tua email *
    [email* your-email] </label>

<label> Oggetto *
    [text* your-subject] </label>

<label> Il tuo messaggio *
    [textarea* your-message] </label>

Allega CV [file curriculum-contatti filetypes:pdf|doc|docx]

Acconsento al trattamento dei dati [checkbox* checkbox-507]
[submit \"Invia\"]");
INSERT INTO `otot_postmeta` VALUES("133","72","_mail","a:8:{s:7:\"subject\";s:32:\"Onyx Technology \"[your-subject]\"\";s:6:\"sender\";s:38:\"[your-name] <wordpress@onyxsistemi.it>\";s:4:\"body\";s:208:\"Da: [your-name] <[your-email]>
Oggetto: [your-subject]

Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:27:\"c.alberti@onyxtechnology.it\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:21:\"[curriculum-contatti]\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `otot_postmeta` VALUES("134","72","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:32:\"Onyx Technology \"[your-subject]\"\";s:6:\"sender\";s:42:\"Onyx Technology <wordpress@onyxsistemi.it>\";s:4:\"body\";s:152:\"Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:37:\"Reply-To: c.alberti@onyxtechnology.it\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `otot_postmeta` VALUES("135","72","_messages","a:23:{s:12:\"mail_sent_ok\";s:46:\"Grazie per il tuo messaggio. È stato inviato.\";s:12:\"mail_sent_ng\";s:88:\"Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.\";s:16:\"validation_error\";s:69:\"Uno o più campi hanno errori. Per favore controlla e prova di nuovo.\";s:4:\"spam\";s:88:\"Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.\";s:12:\"accept_terms\";s:70:\"Devi accettare termini e condizioni prima di inviare il tuo messaggio.\";s:16:\"invalid_required\";s:22:\"Il campo è richiesto.\";s:16:\"invalid_too_long\";s:25:\"Il campo è troppo lungo.\";s:17:\"invalid_too_short\";s:25:\"Il campo è troppo corto.\";s:12:\"invalid_date\";s:38:\"Il formato della data non è corretto.\";s:14:\"date_too_early\";s:50:\"La data è antecedente alla prima data consentita.\";s:13:\"date_too_late\";s:49:\"La data è successiva all\'ultima data consentita.\";s:13:\"upload_failed\";s:71:\"Si è verificato un errore sconosciuto durante il caricamento del file.\";s:24:\"upload_file_type_invalid\";s:56:\"Non sei abilitato al caricamenti di file di questo tipo.\";s:21:\"upload_file_too_large\";s:25:\"Il file è troppo grande.\";s:23:\"upload_failed_php_error\";s:48:\"Si è verificato un errore nel caricare il file.\";s:14:\"invalid_number\";s:34:\"Il formato numerico non è valido.\";s:16:\"number_too_small\";s:44:\"Il numero è inferiore al minimo consentito.\";s:16:\"number_too_large\";s:45:\"Il numero è superiore al massimo consentito.\";s:23:\"quiz_answer_not_correct\";s:36:\"La risposta al quiz non è corretta.\";s:17:\"captcha_not_match\";s:41:\"Il codice che hai inserito non è valido.\";s:13:\"invalid_email\";s:42:\"L\'indirizzo e-mail inserito non è valido.\";s:11:\"invalid_url\";s:20:\"L\'URL non è valido.\";s:11:\"invalid_tel\";s:36:\"Il numero di telefono non è valido.\";}");
INSERT INTO `otot_postmeta` VALUES("136","72","_additional_settings","");
INSERT INTO `otot_postmeta` VALUES("137","72","_locale","it_IT");
INSERT INTO `otot_postmeta` VALUES("138","73","_edit_lock","1478041433:1");
INSERT INTO `otot_postmeta` VALUES("139","73","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("140","73","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("141","76","_edit_lock","1480206002:1");
INSERT INTO `otot_postmeta` VALUES("142","76","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("143","77","_wp_attached_file","2016/11/usa-computer-rg-e1478549979975.jpg");
INSERT INTO `otot_postmeta` VALUES("144","77","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:337;s:4:\"file\";s:42:\"2016/11/usa-computer-rg-e1478549979975.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"usa-computer-rg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"usa-computer-rg-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:27:\"usa-computer-rg-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:28:\"usa-computer-rg-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:30:\"(c) Aircoolsa | Dreamstime.com\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("145","77","_wp_attachment_backup_sizes","a:1:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1257;s:6:\"height\";i:707;s:4:\"file\";s:19:\"usa-computer-rg.jpg\";}}");
INSERT INTO `otot_postmeta` VALUES("146","76","_thumbnail_id","77");
INSERT INTO `otot_postmeta` VALUES("148","79","_edit_lock","1478551929:1");
INSERT INTO `otot_postmeta` VALUES("149","79","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("150","79","_wp_page_template","page-notizie.php");
INSERT INTO `otot_postmeta` VALUES("152","82","url-associato","http://offerte-lavoro.monster.it/v2/job/View?JobID=169478195&MESCOID=1500129001001&jobPosition=5");
INSERT INTO `otot_postmeta` VALUES("153","68","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("154","68","_wp_trash_meta_time","1478557585");
INSERT INTO `otot_postmeta` VALUES("155","68","_wp_desired_post_slug","wp-insert-post-php-function-and-custom-fields-wordpress-development-stack-exchange");
INSERT INTO `otot_postmeta` VALUES("156","82","_edit_lock","1478640025:1");
INSERT INTO `otot_postmeta` VALUES("167","87","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("166","87","_edit_lock","1478983084:1");
INSERT INTO `otot_postmeta` VALUES("159","82","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("168","88","_wp_attached_file","2016/11/mobile-development.jpg");
INSERT INTO `otot_postmeta` VALUES("169","88","_wp_attachment_metadata","a:5:{s:5:\"width\";i:595;s:6:\"height\";i:335;s:4:\"file\";s:30:\"2016/11/mobile-development.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"mobile-development-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"mobile-development-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("170","87","_thumbnail_id","88");
INSERT INTO `otot_postmeta` VALUES("171","87","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("172","90","_edit_lock","1478983242:1");
INSERT INTO `otot_postmeta` VALUES("173","90","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("174","91","_wp_attached_file","2016/11/frontend.jpg");
INSERT INTO `otot_postmeta` VALUES("175","91","_wp_attachment_metadata","a:5:{s:5:\"width\";i:712;s:6:\"height\";i:378;s:4:\"file\";s:20:\"2016/11/frontend.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"frontend-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"frontend-300x159.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:159;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("176","90","_thumbnail_id","91");
INSERT INTO `otot_postmeta` VALUES("177","90","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("178","93","_edit_lock","1478983355:1");
INSERT INTO `otot_postmeta` VALUES("179","93","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("180","94","_wp_attached_file","2016/11/backend.jpg");
INSERT INTO `otot_postmeta` VALUES("181","94","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:260;s:4:\"file\";s:19:\"2016/11/backend.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"backend-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"backend-300x130.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("182","93","_thumbnail_id","94");
INSERT INTO `otot_postmeta` VALUES("183","93","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("184","96","_edit_lock","1478987678:1");
INSERT INTO `otot_postmeta` VALUES("185","96","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("186","97","_wp_attached_file","2016/11/network.jpg");
INSERT INTO `otot_postmeta` VALUES("187","97","_wp_attachment_metadata","a:5:{s:5:\"width\";i:275;s:6:\"height\";i:183;s:4:\"file\";s:19:\"2016/11/network.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"network-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("188","96","_thumbnail_id","97");
INSERT INTO `otot_postmeta` VALUES("189","96","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("190","100","_edit_lock","1479129666:3");
INSERT INTO `otot_postmeta` VALUES("191","100","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("192","101","_edit_lock","1478988532:1");
INSERT INTO `otot_postmeta` VALUES("193","101","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("194","102","_wp_attached_file","2016/11/sistemi_operativi.png");
INSERT INTO `otot_postmeta` VALUES("195","102","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1239;s:6:\"height\";i:639;s:4:\"file\";s:29:\"2016/11/sistemi_operativi.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"sistemi_operativi-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"sistemi_operativi-300x155.png\";s:5:\"width\";i:300;s:6:\"height\";i:155;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"sistemi_operativi-768x396.png\";s:5:\"width\";i:768;s:6:\"height\";i:396;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"sistemi_operativi-1024x528.png\";s:5:\"width\";i:1024;s:6:\"height\";i:528;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("196","101","_thumbnail_id","102");
INSERT INTO `otot_postmeta` VALUES("197","101","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("198","104","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("199","104","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("200","104","_edit_lock","1479129700:3");
INSERT INTO `otot_postmeta` VALUES("201","106","_edit_lock","1478990838:1");
INSERT INTO `otot_postmeta` VALUES("202","106","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("203","107","_wp_attached_file","2016/11/reti-informatiche.jpg");
INSERT INTO `otot_postmeta` VALUES("204","107","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:152;s:4:\"file\";s:29:\"2016/11/reti-informatiche.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"reti-informatiche-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"reti-informatiche-300x114.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:114;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("205","106","_thumbnail_id","107");
INSERT INTO `otot_postmeta` VALUES("206","106","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("207","109","_edit_lock","1479129115:3");
INSERT INTO `otot_postmeta` VALUES("208","109","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("209","110","_wp_attached_file","2016/11/software-engineer.jpg");
INSERT INTO `otot_postmeta` VALUES("210","110","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:261;s:4:\"file\";s:29:\"2016/11/software-engineer.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"software-engineer-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"software-engineer-300x196.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:196;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("211","109","_thumbnail_id","110");
INSERT INTO `otot_postmeta` VALUES("212","109","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("213","112","_edit_lock","1479046779:1");
INSERT INTO `otot_postmeta` VALUES("214","112","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("215","112","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("216","114","_wp_attached_file","2016/11/db.png");
INSERT INTO `otot_postmeta` VALUES("217","114","_wp_attachment_metadata","a:5:{s:5:\"width\";i:460;s:6:\"height\";i:200;s:4:\"file\";s:14:\"2016/11/db.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"db-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"db-300x130.png\";s:5:\"width\";i:300;s:6:\"height\";i:130;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("218","112","_thumbnail_id","114");
INSERT INTO `otot_postmeta` VALUES("219","115","_edit_lock","1479046913:1");
INSERT INTO `otot_postmeta` VALUES("220","115","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("221","116","_wp_attached_file","2016/11/applicaiton-server.png");
INSERT INTO `otot_postmeta` VALUES("222","116","_wp_attachment_metadata","a:5:{s:5:\"width\";i:620;s:6:\"height\";i:318;s:4:\"file\";s:30:\"2016/11/applicaiton-server.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"applicaiton-server-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"applicaiton-server-300x154.png\";s:5:\"width\";i:300;s:6:\"height\";i:154;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("223","115","_thumbnail_id","116");
INSERT INTO `otot_postmeta` VALUES("224","115","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("225","118","_edit_lock","1479047277:1");
INSERT INTO `otot_postmeta` VALUES("226","118","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("227","119","_wp_attached_file","2016/11/amministrazione-portale.jpg");
INSERT INTO `otot_postmeta` VALUES("228","119","_wp_attachment_metadata","a:5:{s:5:\"width\";i:400;s:6:\"height\";i:204;s:4:\"file\";s:35:\"2016/11/amministrazione-portale.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"amministrazione-portale-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"amministrazione-portale-300x153.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:153;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("229","118","_thumbnail_id","119");
INSERT INTO `otot_postmeta` VALUES("230","118","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("231","121","_edit_lock","1479048671:1");
INSERT INTO `otot_postmeta` VALUES("232","121","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("233","122","_wp_attached_file","2016/11/sviluppo-web.jpg");
INSERT INTO `otot_postmeta` VALUES("234","122","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1236;s:6:\"height\";i:255;s:4:\"file\";s:24:\"2016/11/sviluppo-web.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"sviluppo-web-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"sviluppo-web-300x62.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:62;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"sviluppo-web-768x158.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:158;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"sviluppo-web-1024x211.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:33:\"(c) Bakhtiarzein | Dreamstime.com\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("235","121","_thumbnail_id","122");
INSERT INTO `otot_postmeta` VALUES("236","121","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("237","124","_edit_lock","1479129657:3");
INSERT INTO `otot_postmeta` VALUES("238","124","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("239","125","_wp_attached_file","2016/11/marcoferretti-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("240","125","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:33:\"2016/11/marcoferretti-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"marcoferretti-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"marcoferretti-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("241","124","_thumbnail_id","125");
INSERT INTO `otot_postmeta` VALUES("243","127","_edit_lock","1479048866:1");
INSERT INTO `otot_postmeta` VALUES("244","127","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("245","128","_wp_attached_file","2016/11/francesco-panebianco-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("246","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:40:\"2016/11/francesco-panebianco-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"francesco-panebianco-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"francesco-panebianco-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("247","127","_thumbnail_id","128");
INSERT INTO `otot_postmeta` VALUES("249","130","_edit_lock","1479048955:1");
INSERT INTO `otot_postmeta` VALUES("250","130","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("251","131","_wp_attached_file","2016/11/domenico-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("252","131","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:28:\"2016/11/domenico-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"domenico-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"domenico-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("253","130","_thumbnail_id","131");
INSERT INTO `otot_postmeta` VALUES("255","133","_edit_lock","1479049016:1");
INSERT INTO `otot_postmeta` VALUES("256","133","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("257","134","_wp_attached_file","2016/11/luca-sistemista.jpg");
INSERT INTO `otot_postmeta` VALUES("258","134","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:27:\"2016/11/luca-sistemista.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"luca-sistemista-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"luca-sistemista-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("259","133","_thumbnail_id","134");
INSERT INTO `otot_postmeta` VALUES("261","136","_edit_lock","1479049087:1");
INSERT INTO `otot_postmeta` VALUES("262","136","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("263","137","_wp_attached_file","2016/11/Pigliacelli.png");
INSERT INTO `otot_postmeta` VALUES("264","137","_wp_attachment_metadata","a:5:{s:5:\"width\";i:294;s:6:\"height\";i:311;s:4:\"file\";s:23:\"2016/11/Pigliacelli.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"Pigliacelli-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"Pigliacelli-284x300.png\";s:5:\"width\";i:284;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("265","136","_thumbnail_id","137");
INSERT INTO `otot_postmeta` VALUES("267","139","_edit_lock","1479049190:1");
INSERT INTO `otot_postmeta` VALUES("268","139","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("269","140","_wp_attached_file","2016/11/briganti.png");
INSERT INTO `otot_postmeta` VALUES("270","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:148;s:6:\"height\";i:169;s:4:\"file\";s:20:\"2016/11/briganti.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"briganti-148x150.png\";s:5:\"width\";i:148;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("271","139","_thumbnail_id","140");
INSERT INTO `otot_postmeta` VALUES("273","142","_edit_lock","1479049256:1");
INSERT INTO `otot_postmeta` VALUES("274","142","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("275","143","_wp_attached_file","2016/11/Laurenzi-foto-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("276","143","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:33:\"2016/11/Laurenzi-foto-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Laurenzi-foto-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Laurenzi-foto-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("277","142","_thumbnail_id","143");
INSERT INTO `otot_postmeta` VALUES("279","145","_edit_lock","1479049351:1");
INSERT INTO `otot_postmeta` VALUES("280","145","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("281","146","_wp_attached_file","2016/11/De-Dominicis-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("282","146","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:32:\"2016/11/De-Dominicis-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"De-Dominicis-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"De-Dominicis-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("283","145","_thumbnail_id","146");
INSERT INTO `otot_postmeta` VALUES("285","148","_edit_lock","1479049419:1");
INSERT INTO `otot_postmeta` VALUES("286","148","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("287","149","_wp_attached_file","2016/11/luca-help-desk.jpg");
INSERT INTO `otot_postmeta` VALUES("288","149","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:26:\"2016/11/luca-help-desk.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"luca-help-desk-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"luca-help-desk-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("289","148","_thumbnail_id","149");
INSERT INTO `otot_postmeta` VALUES("291","151","_edit_lock","1479049484:1");
INSERT INTO `otot_postmeta` VALUES("292","151","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("293","152","_wp_attached_file","2016/11/Scricco-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("294","152","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:27:\"2016/11/Scricco-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"Scricco-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"Scricco-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("295","151","_thumbnail_id","152");
INSERT INTO `otot_postmeta` VALUES("297","154","_edit_lock","1479129639:3");
INSERT INTO `otot_postmeta` VALUES("298","154","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("299","155","_wp_attached_file","2016/11/Zugaro-380x380.jpg");
INSERT INTO `otot_postmeta` VALUES("300","155","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:26:\"2016/11/Zugaro-380x380.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"Zugaro-380x380-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"Zugaro-380x380-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("301","154","_thumbnail_id","155");
INSERT INTO `otot_postmeta` VALUES("303","157","_edit_lock","1479111740:1");
INSERT INTO `otot_postmeta` VALUES("304","157","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("305","158","_wp_attached_file","2016/11/stanislao.jpg");
INSERT INTO `otot_postmeta` VALUES("306","158","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:21:\"2016/11/stanislao.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"stanislao-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"stanislao-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("307","157","_thumbnail_id","158");
INSERT INTO `otot_postmeta` VALUES("309","160","_menu_item_type","custom");
INSERT INTO `otot_postmeta` VALUES("310","160","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("311","160","_menu_item_object_id","160");
INSERT INTO `otot_postmeta` VALUES("312","160","_menu_item_object","custom");
INSERT INTO `otot_postmeta` VALUES("313","160","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("314","160","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("315","160","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("316","160","_menu_item_url","http://www.onyxsistemi.it/restyling/");
INSERT INTO `otot_postmeta` VALUES("317","160","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("318","161","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("319","161","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("320","161","_menu_item_object_id","84");
INSERT INTO `otot_postmeta` VALUES("321","161","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("322","161","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("323","161","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("324","161","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("325","161","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("326","161","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("327","162","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("328","162","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("329","162","_menu_item_object_id","93");
INSERT INTO `otot_postmeta` VALUES("330","162","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("331","162","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("332","162","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("333","162","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("334","162","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("335","162","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("336","163","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("337","163","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("338","163","_menu_item_object_id","22");
INSERT INTO `otot_postmeta` VALUES("339","163","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("340","163","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("341","163","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("342","163","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("343","163","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("344","163","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("345","164","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("346","164","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("347","164","_menu_item_object_id","73");
INSERT INTO `otot_postmeta` VALUES("348","164","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("349","164","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("350","164","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("351","164","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("352","164","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("353","164","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("354","165","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("355","165","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("356","165","_menu_item_object_id","104");
INSERT INTO `otot_postmeta` VALUES("357","165","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("358","165","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("359","165","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("360","165","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("361","165","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("362","165","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("363","166","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("364","166","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("365","166","_menu_item_object_id","115");
INSERT INTO `otot_postmeta` VALUES("366","166","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("367","166","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("368","166","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("369","166","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("370","166","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("371","166","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("372","167","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("373","167","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("374","167","_menu_item_object_id","118");
INSERT INTO `otot_postmeta` VALUES("375","167","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("376","167","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("377","167","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("378","167","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("379","167","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("380","167","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("381","168","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("382","168","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("383","168","_menu_item_object_id","112");
INSERT INTO `otot_postmeta` VALUES("384","168","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("385","168","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("386","168","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("387","168","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("388","168","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("389","168","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("390","169","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("391","169","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("392","169","_menu_item_object_id","106");
INSERT INTO `otot_postmeta` VALUES("393","169","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("394","169","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("395","169","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("396","169","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("397","169","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("398","169","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("399","170","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("400","170","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("401","170","_menu_item_object_id","101");
INSERT INTO `otot_postmeta` VALUES("402","170","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("403","170","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("404","170","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("405","170","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("406","170","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("407","170","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("408","171","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("409","171","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("410","171","_menu_item_object_id","109");
INSERT INTO `otot_postmeta` VALUES("411","171","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("412","171","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("413","171","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("414","171","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("415","171","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("416","171","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("417","172","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("418","172","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("419","172","_menu_item_object_id","121");
INSERT INTO `otot_postmeta` VALUES("420","172","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("421","172","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("422","172","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("423","172","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("424","172","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("425","172","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("426","173","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("427","173","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("428","173","_menu_item_object_id","90");
INSERT INTO `otot_postmeta` VALUES("429","173","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("430","173","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("431","173","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("432","173","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("433","173","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("434","173","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("435","174","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("436","174","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("437","174","_menu_item_object_id","87");
INSERT INTO `otot_postmeta` VALUES("438","174","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("439","174","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("440","174","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("441","174","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("442","174","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("443","174","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("444","175","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("445","175","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("446","175","_menu_item_object_id","96");
INSERT INTO `otot_postmeta` VALUES("447","175","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("448","175","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("449","175","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("450","175","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("451","175","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("452","175","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("453","176","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("454","176","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("455","176","_menu_item_object_id","79");
INSERT INTO `otot_postmeta` VALUES("456","176","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("457","176","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("458","176","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("459","176","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("460","176","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("461","176","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("462","177","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("463","177","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("464","177","_menu_item_object_id","2");
INSERT INTO `otot_postmeta` VALUES("465","177","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("466","177","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("467","177","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("468","177","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("469","177","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("470","177","_menu_item_orphaned","1479129194");
INSERT INTO `otot_postmeta` VALUES("471","178","_menu_item_type","custom");
INSERT INTO `otot_postmeta` VALUES("472","178","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("473","178","_menu_item_object_id","178");
INSERT INTO `otot_postmeta` VALUES("474","178","_menu_item_object","custom");
INSERT INTO `otot_postmeta` VALUES("475","178","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("476","178","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("477","178","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("478","178","_menu_item_url","http://www.onyxsistemi.it/restyling/");
INSERT INTO `otot_postmeta` VALUES("479","178","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("480","179","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("481","179","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("482","179","_menu_item_object_id","84");
INSERT INTO `otot_postmeta` VALUES("483","179","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("484","179","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("485","179","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("486","179","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("487","179","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("488","179","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("489","180","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("490","180","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("491","180","_menu_item_object_id","93");
INSERT INTO `otot_postmeta` VALUES("492","180","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("493","180","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("494","180","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("495","180","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("496","180","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("497","180","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("498","181","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("499","181","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("500","181","_menu_item_object_id","22");
INSERT INTO `otot_postmeta` VALUES("501","181","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("502","181","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("503","181","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("504","181","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("505","181","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("506","181","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("507","182","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("508","182","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("509","182","_menu_item_object_id","73");
INSERT INTO `otot_postmeta` VALUES("510","182","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("511","182","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("512","182","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("513","182","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("514","182","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("515","182","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("516","183","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("517","183","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("518","183","_menu_item_object_id","104");
INSERT INTO `otot_postmeta` VALUES("519","183","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("520","183","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("521","183","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("522","183","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("523","183","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("524","183","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("525","184","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("526","184","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("527","184","_menu_item_object_id","115");
INSERT INTO `otot_postmeta` VALUES("528","184","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("529","184","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("530","184","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("531","184","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("532","184","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("533","184","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("534","185","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("535","185","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("536","185","_menu_item_object_id","118");
INSERT INTO `otot_postmeta` VALUES("537","185","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("538","185","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("539","185","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("540","185","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("541","185","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("542","185","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("543","186","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("544","186","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("545","186","_menu_item_object_id","112");
INSERT INTO `otot_postmeta` VALUES("546","186","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("547","186","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("548","186","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("549","186","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("550","186","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("551","186","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("552","187","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("553","187","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("554","187","_menu_item_object_id","106");
INSERT INTO `otot_postmeta` VALUES("555","187","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("556","187","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("557","187","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("558","187","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("559","187","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("560","187","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("561","188","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("562","188","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("563","188","_menu_item_object_id","101");
INSERT INTO `otot_postmeta` VALUES("564","188","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("565","188","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("566","188","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("567","188","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("568","188","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("569","188","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("570","189","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("571","189","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("572","189","_menu_item_object_id","109");
INSERT INTO `otot_postmeta` VALUES("573","189","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("574","189","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("575","189","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("576","189","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("577","189","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("578","189","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("579","190","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("580","190","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("581","190","_menu_item_object_id","121");
INSERT INTO `otot_postmeta` VALUES("582","190","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("583","190","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("584","190","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("585","190","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("586","190","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("587","190","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("588","191","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("589","191","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("590","191","_menu_item_object_id","90");
INSERT INTO `otot_postmeta` VALUES("591","191","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("592","191","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("593","191","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("594","191","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("595","191","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("596","191","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("597","192","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("598","192","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("599","192","_menu_item_object_id","87");
INSERT INTO `otot_postmeta` VALUES("600","192","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("601","192","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("602","192","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("603","192","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("604","192","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("605","192","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("606","193","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("607","193","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("608","193","_menu_item_object_id","96");
INSERT INTO `otot_postmeta` VALUES("609","193","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("610","193","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("611","193","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("612","193","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("613","193","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("614","193","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("615","194","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("616","194","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("617","194","_menu_item_object_id","79");
INSERT INTO `otot_postmeta` VALUES("618","194","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("619","194","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("620","194","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("621","194","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("622","194","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("623","194","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("624","195","_menu_item_type","post_type");
INSERT INTO `otot_postmeta` VALUES("625","195","_menu_item_menu_item_parent","0");
INSERT INTO `otot_postmeta` VALUES("626","195","_menu_item_object_id","2");
INSERT INTO `otot_postmeta` VALUES("627","195","_menu_item_object","page");
INSERT INTO `otot_postmeta` VALUES("628","195","_menu_item_target","");
INSERT INTO `otot_postmeta` VALUES("629","195","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `otot_postmeta` VALUES("630","195","_menu_item_xfn","");
INSERT INTO `otot_postmeta` VALUES("631","195","_menu_item_url","");
INSERT INTO `otot_postmeta` VALUES("632","195","_menu_item_orphaned","1479129237");
INSERT INTO `otot_postmeta` VALUES("633","2","_edit_lock","1479129257:3");
INSERT INTO `otot_postmeta` VALUES("634","198","_edit_lock","1479339289:1");
INSERT INTO `otot_postmeta` VALUES("635","198","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("636","199","_wp_attached_file","2016/11/squadra-rg.jpg");
INSERT INTO `otot_postmeta` VALUES("637","199","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:547;s:4:\"file\";s:22:\"2016/11/squadra-rg.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"squadra-rg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"squadra-rg-300x137.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:137;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"squadra-rg-768x350.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:350;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"squadra-rg-1024x467.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:467;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:28:\"(c) Auremar | Dreamstime.com\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("638","200","_wp_attached_file","2016/11/team-building.jpg");
INSERT INTO `otot_postmeta` VALUES("639","200","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1731;s:6:\"height\";i:1109;s:4:\"file\";s:25:\"2016/11/team-building.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"team-building-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"team-building-300x192.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"team-building-768x492.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:492;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"team-building-1024x656.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:656;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("640","198","_thumbnail_id","200");
INSERT INTO `otot_postmeta` VALUES("641","198","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("642","16","_edit_lock","1479426154:1");
INSERT INTO `otot_postmeta` VALUES("643","203","_edit_lock","1479769720:1");
INSERT INTO `otot_postmeta` VALUES("644","203","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("645","204","_wp_attached_file","2016/11/luigi.jpg");
INSERT INTO `otot_postmeta` VALUES("646","204","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:17:\"2016/11/luigi.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"luigi-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"luigi-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("647","203","_thumbnail_id","204");
INSERT INTO `otot_postmeta` VALUES("649","206","_edit_lock","1479769791:1");
INSERT INTO `otot_postmeta` VALUES("650","206","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("651","207","_wp_attached_file","2016/11/alessandro.jpg");
INSERT INTO `otot_postmeta` VALUES("652","207","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:22:\"2016/11/alessandro.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"alessandro-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"alessandro-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("653","206","_thumbnail_id","207");
INSERT INTO `otot_postmeta` VALUES("655","209","_edit_lock","1479769838:1");
INSERT INTO `otot_postmeta` VALUES("656","209","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("657","210","_wp_attached_file","2016/11/valerio.jpg");
INSERT INTO `otot_postmeta` VALUES("658","210","_wp_attachment_metadata","a:5:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"file\";s:19:\"2016/11/valerio.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"valerio-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("659","209","_thumbnail_id","210");
INSERT INTO `otot_postmeta` VALUES("661","212","_edit_lock","1479769898:1");
INSERT INTO `otot_postmeta` VALUES("662","212","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("663","213","_wp_attached_file","2016/11/dario.jpg");
INSERT INTO `otot_postmeta` VALUES("664","213","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:17:\"2016/11/dario.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"dario-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"dario-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("665","212","_thumbnail_id","213");
INSERT INTO `otot_postmeta` VALUES("667","215","_edit_lock","1479769993:1");
INSERT INTO `otot_postmeta` VALUES("668","215","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("669","216","_wp_attached_file","2016/11/ivan.jpg");
INSERT INTO `otot_postmeta` VALUES("670","216","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:16:\"2016/11/ivan.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ivan-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ivan-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("671","215","_thumbnail_id","216");
INSERT INTO `otot_postmeta` VALUES("673","218","_edit_lock","1479770109:1");
INSERT INTO `otot_postmeta` VALUES("674","218","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("675","219","_wp_attached_file","2016/11/paolo.jpg");
INSERT INTO `otot_postmeta` VALUES("676","219","_wp_attachment_metadata","a:5:{s:5:\"width\";i:182;s:6:\"height\";i:235;s:4:\"file\";s:17:\"2016/11/paolo.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"paolo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("677","218","_thumbnail_id","219");
INSERT INTO `otot_postmeta` VALUES("679","221","_edit_lock","1479770155:1");
INSERT INTO `otot_postmeta` VALUES("680","221","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("681","222","_wp_attached_file","2016/11/stefano.jpg");
INSERT INTO `otot_postmeta` VALUES("682","222","_wp_attachment_metadata","a:5:{s:5:\"width\";i:380;s:6:\"height\";i:380;s:4:\"file\";s:19:\"2016/11/stefano.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"stefano-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"stefano-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("683","221","_thumbnail_id","222");
INSERT INTO `otot_postmeta` VALUES("685","224","_edit_lock","1479945671:1");
INSERT INTO `otot_postmeta` VALUES("686","224","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("687","224","_thumbnail_id","200");
INSERT INTO `otot_postmeta` VALUES("688","224","_wp_page_template","default");
INSERT INTO `otot_postmeta` VALUES("689","228","_edit_lock","1480112290:1");
INSERT INTO `otot_postmeta` VALUES("690","228","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("691","229","_wp_attached_file","2016/11/claudio.jpg");
INSERT INTO `otot_postmeta` VALUES("692","229","_wp_attachment_metadata","a:5:{s:5:\"width\";i:185;s:6:\"height\";i:123;s:4:\"file\";s:19:\"2016/11/claudio.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"claudio-150x123.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:123;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `otot_postmeta` VALUES("693","228","_thumbnail_id","229");
INSERT INTO `otot_postmeta` VALUES("696","233","url-associato","http://milano.bakeca.it/dettaglio/informatica-telecomunicazioni/sistemisti-di-rete-e-8fpd124591226");
INSERT INTO `otot_postmeta` VALUES("697","233","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("698","233","_edit_lock","1480113686:1");
INSERT INTO `otot_postmeta` VALUES("699","234","url-associato","http://www.radio24.ilsole24ore.com/");
INSERT INTO `otot_postmeta` VALUES("700","234","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("701","234","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("702","234","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("703","234","_wp_desired_post_slug","radio24-il-sole-24-ore");
INSERT INTO `otot_postmeta` VALUES("704","233","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("705","233","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("706","233","_wp_desired_post_slug","sistemisti-di-rete-e-sicurezza-mi");
INSERT INTO `otot_postmeta` VALUES("707","82","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("708","82","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("709","82","_wp_desired_post_slug","programmatore-phpfrontend");
INSERT INTO `otot_postmeta` VALUES("710","64","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("711","64","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("712","64","_wp_desired_post_slug","candidatura-da-onyx-technology-s-r-l-per-project-manager-mi-monster-it");
INSERT INTO `otot_postmeta` VALUES("713","18","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("714","18","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("715","18","_wp_desired_post_slug","candidatura-per-operatori-security-mi");
INSERT INTO `otot_postmeta` VALUES("716","16","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("717","16","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("718","16","_wp_desired_post_slug","sacramento-auto-accidents-lawyers-john-m-obrien-associates");
INSERT INTO `otot_postmeta` VALUES("719","15","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("720","15","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("721","15","_wp_desired_post_slug","candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it-2");
INSERT INTO `otot_postmeta` VALUES("722","14","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("723","14","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("724","14","_wp_desired_post_slug","net-web-developer-rm");
INSERT INTO `otot_postmeta` VALUES("725","13","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("726","13","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("727","13","_wp_desired_post_slug","candidatura-per-net-web-developer");
INSERT INTO `otot_postmeta` VALUES("728","12","_wp_trash_meta_status","publish");
INSERT INTO `otot_postmeta` VALUES("729","12","_wp_trash_meta_time","1480203282");
INSERT INTO `otot_postmeta` VALUES("730","12","_wp_desired_post_slug","candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it");
INSERT INTO `otot_postmeta` VALUES("731","236","url-associato","http://offerte-lavoro.monster.it/v2/job/View?JobID=175870118&MESCOID=1500136001001&jobPosition=11");
INSERT INTO `otot_postmeta` VALUES("732","236","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("733","237","url-associato","http://offerte-lavoro.monster.it/v2/job/View?JobID=173545736&MESCOID=1500127001001&jobPosition=10");
INSERT INTO `otot_postmeta` VALUES("734","237","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("735","238","url-associato","http://offerte-lavoro.monster.it/v2/job/View?JobID=173545938&MESCOID=1500127001001&jobPosition=9");
INSERT INTO `otot_postmeta` VALUES("736","238","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("737","239","_edit_lock","1480203578:1");
INSERT INTO `otot_postmeta` VALUES("738","240","url-associato","http://offerte-lavoro.monster.it/v2/job/View?JobID=174597850&MESCOID=1300093001001&jobPosition=8");
INSERT INTO `otot_postmeta` VALUES("739","240","img-selezionata","");
INSERT INTO `otot_postmeta` VALUES("740","236","_edit_lock","1480203594:1");
INSERT INTO `otot_postmeta` VALUES("741","237","_edit_lock","1480203678:1");
INSERT INTO `otot_postmeta` VALUES("742","237","_edit_last","1");
INSERT INTO `otot_postmeta` VALUES("743","238","_edit_lock","1480204009:1");
INSERT INTO `otot_postmeta` VALUES("744","238","_edit_last","1");


DROP TABLE IF EXISTS `otot_posts`;

CREATE TABLE `otot_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_posts` VALUES("1","1","2016-10-03 15:37:30","2016-10-03 13:37:30","Benvenuto in WordPress. Questo è il tuo primo articolo. Modificalo o cancellalo e inizia a creare il tuo blog!","Ciao mondo!","","publish","open","open","","ciao-mondo","","","2016-10-03 15:37:30","2016-10-03 13:37:30","","0","http://www.onyxsistemi.it/restyling/?p=1","0","post","","1");
INSERT INTO `otot_posts` VALUES("2","1","2016-10-03 15:37:30","2016-10-03 13:37:30","Questa è una pagina di esempio. Differisce da un articolo di blog perchè rimane in un solo posto ed appare nel menu di navigazione del sito (questo nella maggior parte dei temi). Molte persone iniziano con una pagina di Info che li introduce ai potenziali visitatori del sito. Tale pagina potrebbe contenere un testo del tipo:

<blockquote>Ciao! Sono un pony express di giorno, un aspirante attore di notte e questo è il mio blog. Vivo a Los Angeles, ho un gran bel cane di nome Jack e mi piace la pi&#241;a coladas. (E infradiciarmi sotto la pioggia.)</blockquote>

…o cose di questo genere:

<blockquote>La XYZ Doohickey Company è stata fondata nel 1971, e ha fornito doohickeys di qualità al pubblico fin d\'allora. Si trova a Gotham City, XYZ impiega oltre 2,000 persone e produce ogni genere di cose impressionanti per la comunità di Gotham.</blockquote>

Da nuovo utente WordPress puoi andare sulla <a href=\"http://www.onyxsistemi.it/restyling/wp-admin/\">tua bacheca</a> per cancellare questa pagina e creare nuove pagine per i tuoi contenuti. Buon divertimento!","Pagina di esempio.","","publish","closed","open","","pagina-di-esempio","","","2016-10-03 15:37:30","2016-10-03 13:37:30","","0","http://www.onyxsistemi.it/restyling/?page_id=2","0","page","","0");
INSERT INTO `otot_posts` VALUES("24","1","2016-10-21 13:01:52","2016-10-21 11:01:52","CEO &amp; FOUNDER","Stefania","","publish","open","open","","stefania-romano","","","2016-10-21 16:43:53","2016-10-21 14:43:53","","0","http://www.onyxsistemi.it/restyling/?p=24","0","post","","0");
INSERT INTO `otot_posts` VALUES("22","1","2016-10-21 12:54:11","2016-10-21 10:54:11","","Chi siamo","","publish","closed","closed","","chi-siamo","","","2016-10-21 12:54:11","2016-10-21 10:54:11","","0","http://www.onyxsistemi.it/restyling/?page_id=22","0","page","","0");
INSERT INTO `otot_posts` VALUES("85","1","2016-11-12 21:31:38","2016-11-12 20:31:38","L’infrastruttura informatica ed i servizi da essa erogati sono diventati una risorsa di primaria importanza all’interno delle aziende, soprattutto da quando dall’ Information Technology dipendono in buona parte il livello e la qualità dei prodotti e dei servizi erogati sul mercato.

In ogni azienda ed organizzazione, il buon funzionamento delle infrastruttura informatica, è garanzia di un corretto sviluppo delle attività lavorative e dei processi ad esse collegati così come la soddisfazione di quanti utilizzano tali servizi e tali prodotti.

Le attività di consulenza sistemistica proposte da Onyx Technology interessano tutti i servizi di progettazione, implementazione, installazione, monitoraggio e manutenzione di infrastrutture informatiche necessarie a rendere la tua attività più competitiva e al passo con i tempi.

Tramite le nostre risorse possiamo garantire interventi mirati relativi alle seguenti tecnologie:

UNIX (SUN Solaris, HP UX, IBM AIX)
LINUX (RedHat AS/ES/WS, FedoraCore, SuSe, Debian)
RETI (cisco)
Microsoft
Suite HP OpenView
AIX","Assistenza sistemistica","","inherit","closed","closed","","84-revision-v1","","","2016-11-12 21:31:38","2016-11-12 20:31:38","","84","http://www.onyxsistemi.it/restyling/84-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("84","1","2016-11-12 21:31:38","2016-11-12 20:31:38","L’infrastruttura informatica ed i servizi da essa erogati sono diventati una risorsa di primaria importanza all’interno delle aziende, soprattutto da quando dall’ Information Technology dipendono in buona parte il livello e la qualità dei prodotti e dei servizi erogati sul mercato.

In ogni azienda ed organizzazione, il buon funzionamento delle infrastruttura informatica, è garanzia di un corretto sviluppo delle attività lavorative e dei processi ad esse collegati così come la soddisfazione di quanti utilizzano tali servizi e tali prodotti.

Le attività di consulenza sistemistica proposte da Onyx Technology interessano tutti i servizi di progettazione, implementazione, installazione, monitoraggio e manutenzione di infrastrutture informatiche necessarie a rendere la tua attività più competitiva e al passo con i tempi.

Tramite le nostre risorse possiamo garantire interventi mirati relativi alle seguenti tecnologie:

UNIX (SUN Solaris, HP UX, IBM AIX)
LINUX (RedHat AS/ES/WS, FedoraCore, SuSe, Debian)
RETI (cisco)
Microsoft
Suite HP OpenView
AIX","Assistenza sistemistica","","publish","closed","closed","","assistenza-sistemistica","","","2016-11-12 21:36:02","2016-11-12 20:36:02","","0","http://www.onyxsistemi.it/restyling/?page_id=84","0","page","","0");
INSERT INTO `otot_posts` VALUES("12","1","2016-10-12 14:41:14","2016-10-12 12:41:14","Candidatura da Onyx technology S.r.l. per .NET WEB DEVELOPER (RM) | Monster.it","Candidatura da Onyx technology S.r.l. per .NET WEB DEVELOPER (RM) | Monster.it","","trash","closed","closed","","candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("13","1","2016-10-12 14:52:56","2016-10-12 12:52:56","<img src=\"\">Candidatura per .NET WEB DEVELOPER","Candidatura per .NET WEB DEVELOPER","","trash","closed","closed","","candidatura-per-net-web-developer__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/candidatura-per-net-web-developer/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("14","1","2016-10-12 15:19:30","2016-10-12 13:19:30","<img src=\"\">.NET WEB DEVELOPER (RM)",".NET WEB DEVELOPER (RM)","","trash","closed","closed","","net-web-developer-rm__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/net-web-developer-rm/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("15","1","2016-10-12 15:29:49","2016-10-12 13:29:49","<img src=\"\">Completa la candidatura per .NET WEB DEVELOPER (RM) a Roma 00146, Lazio Italia o cerca altri annunci per Onyx technology S.r.l. su Monster.","Candidatura da Onyx technology S.r.l. per .NET WEB DEVELOPER (RM) | Monster.it","","trash","closed","closed","","candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it-2__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/candidatura-da-onyx-technology-s-r-l-per-net-web-developer-rm-monster-it-2/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("16","1","2016-10-12 15:30:49","2016-10-12 13:30:49","<img src=\"https://www.jobrienlaw.com/frontend/default/images/logo_jo.png\">Been in a car accident in Sacramento? Call 916.714.8200 for a Free Consultation with John O\'Brien - Sacramento Auto Accident Lawyer.","Sacramento Auto Accidents Lawyers |  John M. O\'Brien &amp; Associates","","trash","closed","closed","","sacramento-auto-accidents-lawyers-john-m-obrien-associates__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/sacramento-auto-accidents-lawyers-john-m-obrien-associates/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("23","1","2016-10-21 12:54:11","2016-10-21 10:54:11","","Chi siamo","","inherit","closed","closed","","22-revision-v1","","","2016-10-21 12:54:11","2016-10-21 10:54:11","","22","http://www.onyxsistemi.it/restyling/22-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("18","1","2016-10-12 18:15:24","2016-10-12 16:15:24","<img src=\"\">Completa la candidatura per Operatori Security (MI) a Milano 20100, Lombardia Italia o cerca altri annunci per Onyx technology S.r.l. su Monster.","Candidatura per Operatori Security (MI)","","trash","closed","closed","","candidatura-per-operatori-security-mi__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/candidatura-per-operatori-security-mi/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("19","1","2016-10-12 18:17:18","2016-10-12 16:17:18","bla vkjdrhfgkasjdfoiasrghkb òs&lt;gfnlaekrjngpiusegnlakjrbg","Candidatura per Operatori Security (MI)","","inherit","closed","closed","","18-autosave-v1","","","2016-10-12 18:17:18","2016-10-12 16:17:18","","18","http://www.onyxsistemi.it/restyling/18-autosave-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("25","1","2016-10-21 13:01:34","2016-10-21 11:01:34","","stefania-romano-resize","","inherit","open","closed","","stefania-romano-resize","","","2016-10-21 13:01:34","2016-10-21 11:01:34","","24","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/stefania-romano-resize.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("26","1","2016-10-21 13:01:52","2016-10-21 11:01:52","CEO &amp; FOUNDER","Stefania Romano","","inherit","closed","closed","","24-revision-v1","","","2016-10-21 13:01:52","2016-10-21 11:01:52","","24","http://www.onyxsistemi.it/restyling/24-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("27","1","2016-10-21 15:21:46","2016-10-21 13:21:46","CEO &amp; FOUNDER","Stefania","","inherit","closed","closed","","24-revision-v1","","","2016-10-21 15:21:46","2016-10-21 13:21:46","","24","http://www.onyxsistemi.it/restyling/24-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("28","1","2016-10-21 16:18:35","2016-10-21 14:18:35","HR Specialist","Flavia","","publish","open","open","","flavia","","","2016-10-21 16:18:35","2016-10-21 14:18:35","","0","http://www.onyxsistemi.it/restyling/?p=28","0","post","","0");
INSERT INTO `otot_posts` VALUES("29","1","2016-10-21 16:18:26","2016-10-21 14:18:26","","flavia-anzalone","","inherit","open","closed","","flavia-anzalone","","","2016-10-21 16:18:26","2016-10-21 14:18:26","","28","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/flavia-anzalone.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("30","1","2016-10-21 16:18:35","2016-10-21 14:18:35","HR Specialist","Flavia","","inherit","closed","closed","","28-revision-v1","","","2016-10-21 16:18:35","2016-10-21 14:18:35","","28","http://www.onyxsistemi.it/restyling/28-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("31","1","2016-10-21 16:41:19","2016-10-21 14:41:19","HR Specialist","Alessandra","","publish","open","open","","alessandra","","","2016-10-21 16:49:19","2016-10-21 14:49:19","","0","http://www.onyxsistemi.it/restyling/?p=31","0","post","","0");
INSERT INTO `otot_posts` VALUES("32","1","2016-10-21 16:41:01","2016-10-21 14:41:01","","flammia","","inherit","open","closed","","flammia","","","2016-10-21 16:41:01","2016-10-21 14:41:01","","31","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/Flammia.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("33","1","2016-10-21 16:41:19","2016-10-21 14:41:19","HR Specialist","Alessandra","","inherit","closed","closed","","31-revision-v1","","","2016-10-21 16:41:19","2016-10-21 14:41:19","","31","http://www.onyxsistemi.it/restyling/31-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("34","1","2016-10-21 16:43:19","2016-10-21 14:43:19","","stefania-romano","","inherit","open","closed","","stefania-romano-2","","","2016-10-21 16:43:19","2016-10-21 14:43:19","","24","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/stefania-romano.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("35","1","2016-10-21 16:45:41","2016-10-21 14:45:41","HR Specialist","Marialba","","publish","open","open","","marialba","","","2016-10-21 16:45:41","2016-10-21 14:45:41","","0","http://www.onyxsistemi.it/restyling/?p=35","0","post","","0");
INSERT INTO `otot_posts` VALUES("36","1","2016-10-21 16:45:33","2016-10-21 14:45:33","","17","","inherit","open","closed","","17","","","2016-10-21 16:45:33","2016-10-21 14:45:33","","35","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/17.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("37","1","2016-10-21 16:45:41","2016-10-21 14:45:41","HR Specialist","Marialba","","inherit","closed","closed","","35-revision-v1","","","2016-10-21 16:45:41","2016-10-21 14:45:41","","35","http://www.onyxsistemi.it/restyling/35-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("38","1","2016-10-21 16:54:44","2016-10-21 14:54:44","Amministrazione","Ilaria","","publish","open","open","","ilaria","","","2016-10-21 16:54:44","2016-10-21 14:54:44","","0","http://www.onyxsistemi.it/restyling/?p=38","0","post","","0");
INSERT INTO `otot_posts` VALUES("39","1","2016-10-21 16:54:27","2016-10-21 14:54:27","","ilaria-alborghetti","","inherit","open","closed","","ilaria-alborghetti","","","2016-10-21 16:54:27","2016-10-21 14:54:27","","38","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/ilaria-alborghetti.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("40","1","2016-10-21 16:54:44","2016-10-21 14:54:44","Amministrazione","Ilaria","","inherit","closed","closed","","38-revision-v1","","","2016-10-21 16:54:44","2016-10-21 14:54:44","","38","http://www.onyxsistemi.it/restyling/38-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("76","1","2016-11-07 21:19:59","2016-11-07 20:19:59","Onyx Technology ha un nuovo sito","Un nuovo sito per Onyx Technology","","publish","open","open","","un-nuovo-sito-per-onyx-technology","","","2016-11-07 21:19:59","2016-11-07 20:19:59","","0","http://www.onyxsistemi.it/restyling/?p=76","0","post","","0");
INSERT INTO `otot_posts` VALUES("42","1","2016-10-28 23:54:39","2016-10-28 21:54:39","Amministrazione","Vittoria","","publish","open","open","","vittoria","","","2016-10-28 23:54:39","2016-10-28 21:54:39","","0","http://www.onyxsistemi.it/restyling/?p=42","0","post","","0");
INSERT INTO `otot_posts` VALUES("43","1","2016-10-28 23:54:20","2016-10-28 21:54:20","","vittoria","","inherit","open","closed","","vittoria","","","2016-10-28 23:54:20","2016-10-28 21:54:20","","42","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/vittoria.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("44","1","2016-10-28 23:54:39","2016-10-28 21:54:39","Amministrazione","Vittoria","","inherit","closed","closed","","42-revision-v1","","","2016-10-28 23:54:39","2016-10-28 21:54:39","","42","http://www.onyxsistemi.it/restyling/42-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("45","1","2016-10-28 23:56:53","2016-10-28 21:56:53","Sviluppatore SalesForce","Carlo","","publish","open","open","","carlo","","","2016-10-28 23:56:53","2016-10-28 21:56:53","","0","http://www.onyxsistemi.it/restyling/?p=45","0","post","","0");
INSERT INTO `otot_posts` VALUES("46","1","2016-10-28 23:56:45","2016-10-28 21:56:45","","aniello","","inherit","open","closed","","aniello","","","2016-10-28 23:56:45","2016-10-28 21:56:45","","45","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/Aniello.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("47","1","2016-10-28 23:56:53","2016-10-28 21:56:53","Sviluppatore SalesForce","Carlo","","inherit","closed","closed","","45-revision-v1","","","2016-10-28 23:56:53","2016-10-28 21:56:53","","45","http://www.onyxsistemi.it/restyling/45-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("48","1","2016-10-28 23:58:47","2016-10-28 21:58:47","Project Manager","Daniele","","publish","open","open","","daniele","","","2016-10-28 23:58:47","2016-10-28 21:58:47","","0","http://www.onyxsistemi.it/restyling/?p=48","0","post","","0");
INSERT INTO `otot_posts` VALUES("49","1","2016-10-28 23:58:43","2016-10-28 21:58:43","","camilletti","","inherit","open","closed","","camilletti","","","2016-10-28 23:58:43","2016-10-28 21:58:43","","48","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/Camilletti.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("50","1","2016-10-28 23:58:47","2016-10-28 21:58:47","Project Manager","Daniele","","inherit","closed","closed","","48-revision-v1","","","2016-10-28 23:58:47","2016-10-28 21:58:47","","48","http://www.onyxsistemi.it/restyling/48-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("51","1","2016-10-29 00:01:35","2016-10-28 22:01:35","Analista Funzionale","Giovanna","","publish","open","open","","giovanna","","","2016-10-29 00:01:35","2016-10-28 22:01:35","","0","http://www.onyxsistemi.it/restyling/?p=51","0","post","","0");
INSERT INTO `otot_posts` VALUES("52","1","2016-10-29 00:01:30","2016-10-28 22:01:30","","giovanna-la-gatta","","inherit","open","closed","","giovanna-la-gatta","","","2016-10-29 00:01:30","2016-10-28 22:01:30","","51","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/giovanna-la-gatta.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("53","1","2016-10-29 00:01:35","2016-10-28 22:01:35","Analista Funzionale","Giovanna","","inherit","closed","closed","","51-revision-v1","","","2016-10-29 00:01:35","2016-10-28 22:01:35","","51","http://www.onyxsistemi.it/restyling/51-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("54","1","2016-10-29 00:02:55","2016-10-28 22:02:55","Project Manager","Carlo Eugenio","","publish","open","open","","carlo-eugenio","","","2016-10-29 00:02:55","2016-10-28 22:02:55","","0","http://www.onyxsistemi.it/restyling/?p=54","0","post","","0");
INSERT INTO `otot_posts` VALUES("55","1","2016-10-29 00:02:50","2016-10-28 22:02:50","","carlo-eugenio-romano","","inherit","open","closed","","carlo-eugenio-romano","","","2016-10-29 00:02:50","2016-10-28 22:02:50","","54","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/carlo-eugenio-romano.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("56","1","2016-10-29 00:02:55","2016-10-28 22:02:55","Project Manager","Carlo Eugenio","","inherit","closed","closed","","54-revision-v1","","","2016-10-29 00:02:55","2016-10-28 22:02:55","","54","http://www.onyxsistemi.it/restyling/54-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("57","1","2016-10-29 00:04:36","2016-10-28 22:04:36","Sviluppatore Java","Andrea","","publish","open","open","","andrea","","","2016-10-29 00:05:41","2016-10-28 22:05:41","","0","http://www.onyxsistemi.it/restyling/?p=57","0","post","","0");
INSERT INTO `otot_posts` VALUES("58","1","2016-10-29 00:04:30","2016-10-28 22:04:30","","andrea-nobili","","inherit","open","closed","","andrea-nobili","","","2016-10-29 00:04:30","2016-10-28 22:04:30","","57","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/andrea-nobili.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("59","1","2016-10-29 00:04:36","2016-10-28 22:04:36","Sviluppatore Java","Andrea","","inherit","closed","closed","","57-revision-v1","","","2016-10-29 00:04:36","2016-10-28 22:04:36","","57","http://www.onyxsistemi.it/restyling/57-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("60","1","2016-10-29 00:07:01","2016-10-28 22:07:01","Analista DBA e sviluppatore","Tony","","publish","open","open","","tony","","","2016-10-29 00:07:01","2016-10-28 22:07:01","","0","http://www.onyxsistemi.it/restyling/?p=60","0","post","","0");
INSERT INTO `otot_posts` VALUES("61","1","2016-10-29 00:06:55","2016-10-28 22:06:55","","tony-rossi","","inherit","open","closed","","tony-rossi","","","2016-10-29 00:06:55","2016-10-28 22:06:55","","60","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/10/tony-rossi.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("62","1","2016-10-29 00:07:01","2016-10-28 22:07:01","Analista DBA e sviluppatore","Tony","","inherit","closed","closed","","60-revision-v1","","","2016-10-29 00:07:01","2016-10-28 22:07:01","","60","http://www.onyxsistemi.it/restyling/60-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("77","1","2016-11-07 21:19:26","2016-11-07 20:19:26","","usa-computer-rg","","inherit","open","closed","","usa-computer-rg","","","2016-11-07 21:19:26","2016-11-07 20:19:26","","76","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/usa-computer-rg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("64","1","2016-10-30 08:18:07","2016-10-30 07:18:07","Completa la candidatura per Project Manager (Mi) a Milano 20100, Lombardia Italia o cerca altri annunci per Onyx technology S.r.l. su Monster.","Project Manager (Mi)","","trash","closed","closed","","candidatura-da-onyx-technology-s-r-l-per-project-manager-mi-monster-it__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/candidatura-da-onyx-technology-s-r-l-per-project-manager-mi-monster-it/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("65","1","2016-10-30 21:24:47","2016-10-30 20:24:47","<label> Il tuo nome (richiesto)
    [text* your-name] </label>

<label> La tua email (richiesto)
    [email* your-email] </label>

<label> Oggetto
    [text your-subject] </label>

<label> Il tuo messaggio
    [textarea your-message] </label>

[submit \"Invia\"]
Onyx Technology \"[your-subject]\"
[your-name] <wordpress@onyxsistemi.it>
Da: [your-name] <[your-email]>
Oggetto: [your-subject]

Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
c.alberti@onyxtechnology.it
Reply-To: [your-email]

0
0

Onyx Technology \"[your-subject]\"
Onyx Technology <wordpress@onyxsistemi.it>
Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
[your-email]
Reply-To: c.alberti@onyxtechnology.it

0
0
Grazie per il tuo messaggio. È stato inviato.
Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.
Uno o più campi hanno errori. Per favore controlla e prova di nuovo.
Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.
Devi accettare termini e condizioni prima di inviare il tuo messaggio.
Il campo è richiesto.
Il campo è troppo lungo.
Il campo è troppo corto.","Modulo di contatto 1","","publish","closed","closed","","modulo-di-contatto-1","","","2016-10-30 21:24:47","2016-10-30 20:24:47","","0","http://www.onyxsistemi.it/restyling/?post_type=wpcf7_contact_form&p=65","0","wpcf7_contact_form","","0");
INSERT INTO `otot_posts` VALUES("66","1","2016-10-30 21:49:07","2016-10-30 20:49:07","<label> Il tuo nome *
    [text* your-name] </label>

<label> La tua email *
    [email* your-email] </label>

<label> Incolla qui il titolo dell\'annuncio * 
[text* titolo-annuncio]</label>

<label> Curriculum vitae [file* curriculum filetypes:doc|docx|pdf]</label>

Autorizzo Onyx Technology al trattamento dei dati [acceptance accetto-condizioni]
[submit \"Invia\"]
E\' arrivata una nuova candidatura per un annuncio
[your-name] <wordpress@onyxsistemi.it>
Da: [your-name] <[your-email]>
Oggetto: E\' arrivata una nuova candidatura per un annuncio

Ciao HR,
è arrivata una nuova candidatura per l\'annuncio \"[titolo-annuncio]\" pubblicato sul sito di Onyx Technology. Il nome del candidato è [your-name].

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
c.alberti@onyxtechnology.it
Reply-To: [your-email]
[curriculum]
1


Onyx Technology \"[your-subject]\"
Onyx Technology <wordpress@onyxsistemi.it>
Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
[your-email]
Reply-To: c.alberti@onyxtechnology.it



La tua candidatura è stata inviata.
Si è verificato un errore durante l\'invio della tua candidatura. Per favore prova di nuovo.
Uno o più campi hanno errori. Per favore controlla e prova di nuovo.
Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.
Devi accettare termini e condizioni prima di inviare il tuo messaggio.
Il campo è richiesto.
Il campo è troppo lungo.
Il campo è troppo corto.
Il formato della data non è corretto.
La data è antecedente alla prima data consentita.
La data è successiva all\'ultima data consentita.
Si è verificato un errore sconosciuto durante il caricamento del file.
Non sei abilitato al caricamenti di file di questo tipo.
Il file è troppo grande.
Si è verificato un errore nel caricare il file.
Il formato numerico non è valido.
Il numero è inferiore al minimo consentito.
Il numero è superiore al massimo consentito.
La risposta al quiz non è corretta.
Il codice che hai inserito non è valido.
L\'indirizzo e-mail inserito non è valido.
L\'URL non è valido.
Il numero di telefono non è valido.","Candidati subito","","publish","closed","closed","","candidati-subito","","","2016-10-30 22:22:10","2016-10-30 21:22:10","","0","http://www.onyxsistemi.it/restyling/?post_type=wpcf7_contact_form&#038;p=66","0","wpcf7_contact_form","","0");
INSERT INTO `otot_posts` VALUES("232","1","2016-11-25 22:02:35","0000-00-00 00:00:00","","Bozza automatica","","auto-draft","open","open","","","","","2016-11-25 22:02:35","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=232","0","post","","0");
INSERT INTO `otot_posts` VALUES("68","1","2016-10-30 22:51:46","2016-10-30 21:51:46","The WordPress function is used for submitting data programatically. Standard fields to submit to incude the content, excerpt, title, date and many more.

What there is no documentation for is how to","WP insert post PHP function and Custom Fields - WordPress Development Stack Exchange","","trash","closed","closed","","wp-insert-post-php-function-and-custom-fields-wordpress-development-stack-exchange__trashed","","","2016-11-07 23:26:25","2016-11-07 22:26:25","","0","http://www.onyxsistemi.it/restyling/annunci/wp-insert-post-php-function-and-custom-fields-wordpress-development-stack-exchange/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("69","1","2016-11-01 18:03:01","2016-11-01 17:03:01","Ciao mondo

dsssjdklfhlkjfhlaskjdhlkjsdhflkajsdhflkjsadhflkjs","Articolo di prova","","publish","open","open","","articolo-di-prova","","","2016-11-07 22:11:17","2016-11-07 21:11:17","","0","http://www.onyxsistemi.it/restyling/?p=69","0","post","","0");
INSERT INTO `otot_posts` VALUES("70","1","2016-11-01 18:03:01","2016-11-01 17:03:01","Ciao mondo

<iframe height=\'400\' src=\'http://wordpress.stackexchange.com/questions/8569/wp-insert-post-php-function-and-custom-fields\'></iframe>	","Articolo di prova","","inherit","closed","closed","","69-revision-v1","","","2016-11-01 18:03:01","2016-11-01 17:03:01","","69","http://www.onyxsistemi.it/restyling/69-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("81","1","2016-11-07 22:11:17","2016-11-07 21:11:17","Ciao mondo

dsssjdklfhlkjfhlaskjdhlkjsdhflkajsdhflkjsadhflkjs","Articolo di prova","","inherit","closed","closed","","69-revision-v1","","","2016-11-07 22:11:17","2016-11-07 21:11:17","","69","http://www.onyxsistemi.it/restyling/69-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("71","1","2016-11-01 18:13:28","2016-11-01 17:13:28","Ciao mondo

<iframe src=\"http://wordpress.stackexchange.com/questions/8569/wp-insert-post-php-function-and-custom-fields\" width=\"300\" height=\"400\"></iframe>dsssjdklfhlkjfhlaskjdhlkjsdhflkajsdhflkjsadhflkjs","Articolo di prova","","inherit","closed","closed","","69-revision-v1","","","2016-11-01 18:13:28","2016-11-01 17:13:28","","69","http://www.onyxsistemi.it/restyling/69-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("72","1","2016-11-02 00:04:02","2016-11-01 23:04:02","<label> Il tuo nome *
    [text* your-name] </label>

<label> La tua email *
    [email* your-email] </label>

<label> Oggetto *
    [text* your-subject] </label>

<label> Il tuo messaggio *
    [textarea* your-message] </label>

Allega CV [file curriculum-contatti filetypes:pdf|doc|docx]

Acconsento al trattamento dei dati [checkbox* checkbox-507]
[submit \"Invia\"]
Onyx Technology \"[your-subject]\"
[your-name] <wordpress@onyxsistemi.it>
Da: [your-name] <[your-email]>
Oggetto: [your-subject]

Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
c.alberti@onyxtechnology.it
Reply-To: [your-email]
[curriculum-contatti]



Onyx Technology \"[your-subject]\"
Onyx Technology <wordpress@onyxsistemi.it>
Corpo del messaggio:
[your-message]

--
Questa e-mail è stata inviata da un modulo di contatto su Onyx Technology (http://www.onyxsistemi.it/restyling)
[your-email]
Reply-To: c.alberti@onyxtechnology.it



Grazie per il tuo messaggio. È stato inviato.
Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.
Uno o più campi hanno errori. Per favore controlla e prova di nuovo.
Si è verificato un errore durante l\'invio del tuo messaggio. Per favore prova di nuovo.
Devi accettare termini e condizioni prima di inviare il tuo messaggio.
Il campo è richiesto.
Il campo è troppo lungo.
Il campo è troppo corto.
Il formato della data non è corretto.
La data è antecedente alla prima data consentita.
La data è successiva all\'ultima data consentita.
Si è verificato un errore sconosciuto durante il caricamento del file.
Non sei abilitato al caricamenti di file di questo tipo.
Il file è troppo grande.
Si è verificato un errore nel caricare il file.
Il formato numerico non è valido.
Il numero è inferiore al minimo consentito.
Il numero è superiore al massimo consentito.
La risposta al quiz non è corretta.
Il codice che hai inserito non è valido.
L\'indirizzo e-mail inserito non è valido.
L\'URL non è valido.
Il numero di telefono non è valido.","Pagina Contatti","","publish","closed","closed","","senza-titolo","","","2016-11-02 00:05:05","2016-11-01 23:05:05","","0","http://www.onyxsistemi.it/restyling/?post_type=wpcf7_contact_form&#038;p=72","0","wpcf7_contact_form","","0");
INSERT INTO `otot_posts` VALUES("73","1","2016-11-02 00:06:06","2016-11-01 23:06:06","[contact-form-7 id=\"72\" title=\"Pagina Contatti\"]","Contatti","","publish","closed","closed","","contatti","","","2016-11-02 00:06:06","2016-11-01 23:06:06","","0","http://www.onyxsistemi.it/restyling/?page_id=73","0","page","","0");
INSERT INTO `otot_posts` VALUES("74","1","2016-11-02 00:06:06","2016-11-01 23:06:06","[contact-form-7 id=\"72\" title=\"Pagina Contatti\"]","Contatti","","inherit","closed","closed","","73-revision-v1","","","2016-11-02 00:06:06","2016-11-01 23:06:06","","73","http://www.onyxsistemi.it/restyling/73-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("78","1","2016-11-07 21:19:59","2016-11-07 20:19:59","Onyx Technology ha un nuovo sito","Un nuovo sito per Onyx Technology","","inherit","closed","closed","","76-revision-v1","","","2016-11-07 21:19:59","2016-11-07 20:19:59","","76","http://www.onyxsistemi.it/restyling/76-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("79","1","2016-11-07 21:36:48","2016-11-07 20:36:48","","News","","publish","closed","closed","","news","","","2016-11-07 21:36:48","2016-11-07 20:36:48","","0","http://www.onyxsistemi.it/restyling/?page_id=79","0","page","","0");
INSERT INTO `otot_posts` VALUES("80","1","2016-11-07 21:36:48","2016-11-07 20:36:48","","News","","inherit","closed","closed","","79-revision-v1","","","2016-11-07 21:36:48","2016-11-07 20:36:48","","79","http://www.onyxsistemi.it/restyling/79-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("82","1","2016-11-07 23:23:53","2016-11-07 22:23:53","ONYX TECHNOLOGY, dinamica società di consulenza in forte crescita sul mercato dell’ Information Technology, opera dal 2008 nel mercato IT fornendo servizi specialistici e mettendo a disposizione della propria clientela competenze e professionalità altamente specializzate nella consulenza manageriale, nello sviluppo software, nella system integration e nell’ IT Security .

Attualmente ricerchiamo 3 PROGRAMMATORI PHP / Frontend (varie seniority)

la risorsa ha maturato esperienza in ambito web, in particolari su PHP Javascript, Jqwery, CSS3

Richiediamo la conoscenza anche base di Angular Js

Richiediamo disponibilità per attività su Roma

Inserimento a tempo determinato, indeterminato o partita IVA

Durata da definire","PROGRAMMATORE PHP/Frontend","","trash","closed","closed","","programmatore-phpfrontend__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/programmatore-phpfrontend/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("86","1","2016-11-12 21:35:57","2016-11-12 20:35:57","","assistenza-sistemistica","","inherit","open","closed","","assistenza-sistemistica-2","","","2016-11-12 21:35:57","2016-11-12 20:35:57","","84","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/assistenza-sistemistica.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("87","1","2016-11-12 21:39:50","2016-11-12 20:39:50","Il mondo della comunicazione è sempre più influenzato dalle tecnologie di tipo mobile.
Grazie all’utilizzo di smartphone e tablet gli utenti possono infatti oggi accedere ad informazioni e comunicare da qualunque luogo. Onyx Technology si occupa della realizzazione di applicazioni per Smartphone e Tablet (iPhone, iPad e Android) per consolidare il brand dei propri partner in modo tale che possano offrire servizi anche in mobilità. Onyx Technology progetta e sviluppa anche soluzioni mobile di classe enterprise, sia native che ibride, per aiutare i suoi partner a condurre il proprio business ovunque e con qualsiasi dispositivo.
<ul>
 	<li>Progettazione e sviluppo di applicazioni iOS</li>
 	<li>Progettazione e sviluppo di applicazioni Android</li>
 	<li>Progettazione e sviluppo di applicazioni cross plattform mediante PhoneGap</li>
 	<li>Progettazione e sviluppo di applicazioni mobile di classe enterprise</li>
</ul>","Mobile Development","","publish","closed","closed","","mobile-development","","","2016-11-12 21:39:50","2016-11-12 20:39:50","","0","http://www.onyxsistemi.it/restyling/?page_id=87","0","page","","0");
INSERT INTO `otot_posts` VALUES("88","1","2016-11-12 21:39:45","2016-11-12 20:39:45","","mobile-development","","inherit","open","closed","","mobile-development","","","2016-11-12 21:39:45","2016-11-12 20:39:45","","87","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/mobile-development.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("89","1","2016-11-12 21:39:50","2016-11-12 20:39:50","Il mondo della comunicazione è sempre più influenzato dalle tecnologie di tipo mobile.
Grazie all’utilizzo di smartphone e tablet gli utenti possono infatti oggi accedere ad informazioni e comunicare da qualunque luogo. Onyx Technology si occupa della realizzazione di applicazioni per Smartphone e Tablet (iPhone, iPad e Android) per consolidare il brand dei propri partner in modo tale che possano offrire servizi anche in mobilità. Onyx Technology progetta e sviluppa anche soluzioni mobile di classe enterprise, sia native che ibride, per aiutare i suoi partner a condurre il proprio business ovunque e con qualsiasi dispositivo.
<ul>
 	<li>Progettazione e sviluppo di applicazioni iOS</li>
 	<li>Progettazione e sviluppo di applicazioni Android</li>
 	<li>Progettazione e sviluppo di applicazioni cross plattform mediante PhoneGap</li>
 	<li>Progettazione e sviluppo di applicazioni mobile di classe enterprise</li>
</ul>","Mobile Development","","inherit","closed","closed","","87-revision-v1","","","2016-11-12 21:39:50","2016-11-12 20:39:50","","87","http://www.onyxsistemi.it/restyling/87-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("90","1","2016-11-12 21:41:45","2016-11-12 20:41:45","Qualsiasi sia il progetto di frontend che si intende intraprendere: da un sito web ad un’applicazione mobile, da un sistema gestionale ad un’ applicazione sociale, Onyx Technology mette a disposizione le sue conoscenze e la professionalità delle proprie risorse per ottenere il raggiungimento degli obiettivi stabiliti. Grazie all’adozione delle ultime tecnologie in gioco, è in grado di progettare e sviluppare applicativi web e mobile secondo precisi criteri di usabilità, scalabilità e qualità. Il risultato è un prodotto innovativo, ragionato, sicuro e fruibile, realizzato secondo le specifiche del cliente.
<ul>
 	<li>Sviluppo di layout responsive mediante l’adozione di HTML5 e CSS3</li>
 	<li>Adozione dei più moderni framework JavaScript tra cui JQuery ed AngularJS</li>
 	<li>Adozione di framework CSS come BootStrap al fine di rendere il processo di sviluppo snello e aderente ai più moderni standard di qualità</li>
</ul>","Frontend Development","","publish","closed","closed","","frontend-development","","","2016-11-12 21:41:45","2016-11-12 20:41:45","","0","http://www.onyxsistemi.it/restyling/?page_id=90","0","page","","0");
INSERT INTO `otot_posts` VALUES("91","1","2016-11-12 21:41:24","2016-11-12 20:41:24","","frontend","","inherit","open","closed","","frontend","","","2016-11-12 21:41:24","2016-11-12 20:41:24","","90","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/frontend.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("92","1","2016-11-12 21:41:45","2016-11-12 20:41:45","Qualsiasi sia il progetto di frontend che si intende intraprendere: da un sito web ad un’applicazione mobile, da un sistema gestionale ad un’ applicazione sociale, Onyx Technology mette a disposizione le sue conoscenze e la professionalità delle proprie risorse per ottenere il raggiungimento degli obiettivi stabiliti. Grazie all’adozione delle ultime tecnologie in gioco, è in grado di progettare e sviluppare applicativi web e mobile secondo precisi criteri di usabilità, scalabilità e qualità. Il risultato è un prodotto innovativo, ragionato, sicuro e fruibile, realizzato secondo le specifiche del cliente.
<ul>
 	<li>Sviluppo di layout responsive mediante l’adozione di HTML5 e CSS3</li>
 	<li>Adozione dei più moderni framework JavaScript tra cui JQuery ed AngularJS</li>
 	<li>Adozione di framework CSS come BootStrap al fine di rendere il processo di sviluppo snello e aderente ai più moderni standard di qualità</li>
</ul>","Frontend Development","","inherit","closed","closed","","90-revision-v1","","","2016-11-12 21:41:45","2016-11-12 20:41:45","","90","http://www.onyxsistemi.it/restyling/90-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("93","1","2016-11-12 21:44:14","2016-11-12 20:44:14","Conosciamo l’importanza del valore dei dati sensibili e dei servizi ad essi legati pertanto reputiamo che lo sviluppo di un’applicazione di backend debba puntare alla realizzazione di un prodotto sicuro e scalabile, in grado di adattarsi ad ogni esigenza di carico e ad ogni evoluzione futura.

Onyx Technology è grado di proporre soluzioni di backend basate sulle esigenze del business dei suoi partner e aderenti alle più moderne soluzioni tecnologiche.Grazie ad un team di professionisti con una pluriennale esperienza nei principali linguaggi di programmazione realizza applicativi customizzati sulla base delle necessità del cliente.

Onyx Technology è inoltre in grado di fornire figure professionali di sviluppo in modalità Time &amp; Material, che vanno ad integrasi nei team presenti presso il cliente fornendo in questo modo l’effort mancante o il valore aggiunto che serve al completamento del progetto
<ul>
 	<li>Sviluppo in ambiente Java: Java SE, Java EE, Spring</li>
 	<li>Sviluppo in ambiente Microsoft: C#, VB, .NET</li>
 	<li>Sviluppo di soluzioni in ambito PHP e Python</li>
 	<li>Progettazione e sviluppo di database SQL e NOSQL</li>
 	<li>Soluzioni PL/SQL</li>
</ul>","Backend Development","","publish","closed","closed","","backend-development","","","2016-11-12 21:44:14","2016-11-12 20:44:14","","0","http://www.onyxsistemi.it/restyling/?page_id=93","0","page","","0");
INSERT INTO `otot_posts` VALUES("94","1","2016-11-12 21:44:09","2016-11-12 20:44:09","","backend","","inherit","open","closed","","backend","","","2016-11-12 21:44:09","2016-11-12 20:44:09","","93","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/backend.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("95","1","2016-11-12 21:44:14","2016-11-12 20:44:14","Conosciamo l’importanza del valore dei dati sensibili e dei servizi ad essi legati pertanto reputiamo che lo sviluppo di un’applicazione di backend debba puntare alla realizzazione di un prodotto sicuro e scalabile, in grado di adattarsi ad ogni esigenza di carico e ad ogni evoluzione futura.

Onyx Technology è grado di proporre soluzioni di backend basate sulle esigenze del business dei suoi partner e aderenti alle più moderne soluzioni tecnologiche.Grazie ad un team di professionisti con una pluriennale esperienza nei principali linguaggi di programmazione realizza applicativi customizzati sulla base delle necessità del cliente.

Onyx Technology è inoltre in grado di fornire figure professionali di sviluppo in modalità Time &amp; Material, che vanno ad integrasi nei team presenti presso il cliente fornendo in questo modo l’effort mancante o il valore aggiunto che serve al completamento del progetto
<ul>
 	<li>Sviluppo in ambiente Java: Java SE, Java EE, Spring</li>
 	<li>Sviluppo in ambiente Microsoft: C#, VB, .NET</li>
 	<li>Sviluppo di soluzioni in ambito PHP e Python</li>
 	<li>Progettazione e sviluppo di database SQL e NOSQL</li>
 	<li>Soluzioni PL/SQL</li>
</ul>","Backend Development","","inherit","closed","closed","","93-revision-v1","","","2016-11-12 21:44:14","2016-11-12 20:44:14","","93","http://www.onyxsistemi.it/restyling/93-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("96","1","2016-11-12 22:54:54","2016-11-12 21:54:54","Nell’ambito del networking, Onyx Technology è in grado di offrire una gestione completa delle problematiche del settore, a partire dalla raccolta e dall’analisi dei requisiti fino alla progettazione e successiva implementazione, ottimizzazione, collaudo e manutenzione/amministrazione durante la fase operativa degli impianti.

Grazie alla nostra esperienza possiamo garantire requisiti di affidabilità e performance nonché di scalabilità e sicurezza, per affrontare facilmente modifiche ed ampliamenti a cui le reti odierne sono naturalmente soggette indicando al cliente la soluzione tecnologica più adatta alle proprie esigenze.
<ul>
 	<li>Progettazione e realizzazione di reti complesse</li>
 	<li>Architetture WAN, MAN e LAN su circuiti privati e/o pubblici</li>
 	<li>Web Farm services (Unix &amp; Windows based)</li>
 	<li>Architetture e servizi di “rete intelligente”</li>
 	<li>Progettazione, realizzazione e gestione di Network Operation Center (NOC)</li>
 	<li>Servizi di Posta elettronica</li>
 	<li>Tele e Web Conferencing</li>
 	<li>Sistemi per il Virtual Learning</li>
 	<li>Infrastrutture di convergenza dati-voce</li>
 	<li>Soluzioni Centralizzate di Policy Connection</li>
 	<li>Gestione e filtraggio del traffico Web</li>
 	<li>Sicurezza fisica dell’azienda</li>
 	<li>Sicurezza perimetrale (hardware e software)</li>
 	<li>Sicurezza della rete interna (HW e SW)</li>
 	<li>Sicurezza wireless</li>
 	<li>Business continuity</li>
</ul>","Network","","publish","closed","closed","","network","","","2016-11-12 22:54:54","2016-11-12 21:54:54","","0","http://www.onyxsistemi.it/restyling/?page_id=96","0","page","","0");
INSERT INTO `otot_posts` VALUES("97","1","2016-11-12 22:54:50","2016-11-12 21:54:50","","network","","inherit","open","closed","","network","","","2016-11-12 22:54:50","2016-11-12 21:54:50","","96","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/network.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("98","1","2016-11-12 22:54:54","2016-11-12 21:54:54","Nell’ambito del networking, Onyx Technology è in grado di offrire una gestione completa delle problematiche del settore, a partire dalla raccolta e dall’analisi dei requisiti fino alla progettazione e successiva implementazione, ottimizzazione, collaudo e manutenzione/amministrazione durante la fase operativa degli impianti.

Grazie alla nostra esperienza possiamo garantire requisiti di affidabilità e performance nonché di scalabilità e sicurezza, per affrontare facilmente modifiche ed ampliamenti a cui le reti odierne sono naturalmente soggette indicando al cliente la soluzione tecnologica più adatta alle proprie esigenze.
<ul>
 	<li>Progettazione e realizzazione di reti complesse</li>
 	<li>Architetture WAN, MAN e LAN su circuiti privati e/o pubblici</li>
 	<li>Web Farm services (Unix &amp; Windows based)</li>
 	<li>Architetture e servizi di “rete intelligente”</li>
 	<li>Progettazione, realizzazione e gestione di Network Operation Center (NOC)</li>
 	<li>Servizi di Posta elettronica</li>
 	<li>Tele e Web Conferencing</li>
 	<li>Sistemi per il Virtual Learning</li>
 	<li>Infrastrutture di convergenza dati-voce</li>
 	<li>Soluzioni Centralizzate di Policy Connection</li>
 	<li>Gestione e filtraggio del traffico Web</li>
 	<li>Sicurezza fisica dell’azienda</li>
 	<li>Sicurezza perimetrale (hardware e software)</li>
 	<li>Sicurezza della rete interna (HW e SW)</li>
 	<li>Sicurezza wireless</li>
 	<li>Business continuity</li>
</ul>","Network","","inherit","closed","closed","","96-revision-v1","","","2016-11-12 22:54:54","2016-11-12 21:54:54","","96","http://www.onyxsistemi.it/restyling/96-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("204","1","2016-11-22 00:10:36","2016-11-21 23:10:36","","luigi","","inherit","open","closed","","luigi","","","2016-11-22 00:10:36","2016-11-21 23:10:36","","203","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/luigi.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("100","1","2016-11-12 22:57:56","0000-00-00 00:00:00","<ul>
 	<li>iOS base (5 giorni)</li>
 	<li>iOS avanzato (5 giorni)</li>
 	<li>Linux\\UNIX base (3 giorni)</li>
 	<li>Linux\\UNIX amministrazione (5 giorni)</li>
 	<li>Red Hat System Administration I (RH124) (20/30 ore)</li>
 	<li>Solaris 10 System Administration (30 ore)</li>
 	<li>Solaris 10 Advanced Administration (30 ore)</li>
 	<li>Solaris 10 Network  (20 ore)</li>
 	<li>Solaris 10 Security (40 ore)</li>
 	<li>Unix Foundamentals For Solaris 10 OS (20 ore)</li>
 	<li>Linux LPI Essential (20 ore)</li>
</ul>
<strong>CORSI MACCHINE VIRTUALI:</strong>
<ul>
 	<li>Vmware vSphere Esxi 4.1 e 5.0 (30/40 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.
","Sistemi operativi","","draft","open","open","","","","","2016-11-12 22:57:56","2016-11-12 21:57:56","","0","http://www.onyxsistemi.it/restyling/?p=100","0","post","","0");
INSERT INTO `otot_posts` VALUES("101","1","2016-11-12 23:00:57","2016-11-12 22:00:57","<ul>
 	<li>iOS base (5 giorni)</li>
 	<li>iOS avanzato (5 giorni)</li>
 	<li>Linux\\UNIX base (3 giorni)</li>
 	<li>Linux\\UNIX amministrazione (5 giorni)</li>
 	<li>Red Hat System Administration I (RH124) (20/30 ore)</li>
 	<li>Solaris 10 System Administration (30 ore)</li>
 	<li>Solaris 10 Advanced Administration (30 ore)</li>
 	<li>Solaris 10 Network  (20 ore)</li>
 	<li>Solaris 10 Security (40 ore)</li>
 	<li>Unix Foundamentals For Solaris 10 OS (20 ore)</li>
 	<li>Linux LPI Essential (20 ore)</li>
</ul>
<strong>CORSI MACCHINE VIRTUALI:</strong>
<ul>
 	<li>Vmware vSphere Esxi 4.1 e 5.0 (30/40 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Sistemi operativi","","publish","closed","closed","","sistemi-operativi","","","2016-11-12 23:01:39","2016-11-12 22:01:39","","104","http://www.onyxsistemi.it/restyling/?page_id=101","0","page","","0");
INSERT INTO `otot_posts` VALUES("102","1","2016-11-12 22:59:00","2016-11-12 21:59:00","","sistemi_operativi","","inherit","open","closed","","sistemi_operativi","","","2016-11-12 22:59:00","2016-11-12 21:59:00","","101","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/sistemi_operativi.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("103","1","2016-11-12 23:00:57","2016-11-12 22:00:57","<ul>
 	<li>iOS base (5 giorni)</li>
 	<li>iOS avanzato (5 giorni)</li>
 	<li>Linux\\UNIX base (3 giorni)</li>
 	<li>Linux\\UNIX amministrazione (5 giorni)</li>
 	<li>Red Hat System Administration I (RH124) (20/30 ore)</li>
 	<li>Solaris 10 System Administration (30 ore)</li>
 	<li>Solaris 10 Advanced Administration (30 ore)</li>
 	<li>Solaris 10 Network  (20 ore)</li>
 	<li>Solaris 10 Security (40 ore)</li>
 	<li>Unix Foundamentals For Solaris 10 OS (20 ore)</li>
 	<li>Linux LPI Essential (20 ore)</li>
</ul>
<strong>CORSI MACCHINE VIRTUALI:</strong>
<ul>
 	<li>Vmware vSphere Esxi 4.1 e 5.0 (30/40 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Sistemi operativi","","inherit","closed","closed","","101-revision-v1","","","2016-11-12 23:00:57","2016-11-12 22:00:57","","101","http://www.onyxsistemi.it/restyling/101-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("104","1","2016-11-12 23:01:16","2016-11-12 22:01:16","","Corsi di formazione","","publish","closed","closed","","corsi-di-formazione","","","2016-11-12 23:01:16","2016-11-12 22:01:16","","0","http://www.onyxsistemi.it/restyling/?page_id=104","0","page","","0");
INSERT INTO `otot_posts` VALUES("105","1","2016-11-12 23:01:16","2016-11-12 22:01:16","","Corsi di formazione","","inherit","closed","closed","","104-revision-v1","","","2016-11-12 23:01:16","2016-11-12 22:01:16","","104","http://www.onyxsistemi.it/restyling/104-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("106","1","2016-11-12 23:12:01","2016-11-12 22:12:01","<ul>
 	<li>Reti Base (3 giorni)</li>
 	<li>Cisco CCNA (4 moduli, ognuno da almeno 20 ore)</li>
 	<li>Cisco Voice CCNA (20 ore)</li>
 	<li>Tecnologie VoIP (protocolli SIP , SCCP , H323, SCCP) (20 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Reti","","publish","closed","closed","","reti","","","2016-11-12 23:12:01","2016-11-12 22:12:01","","104","http://www.onyxsistemi.it/restyling/?page_id=106","0","page","","0");
INSERT INTO `otot_posts` VALUES("107","1","2016-11-12 23:11:50","2016-11-12 22:11:50","","reti-informatiche","","inherit","open","closed","","reti-informatiche","","","2016-11-12 23:11:50","2016-11-12 22:11:50","","106","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/reti-informatiche.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("108","1","2016-11-12 23:12:01","2016-11-12 22:12:01","<ul>
 	<li>Reti Base (3 giorni)</li>
 	<li>Cisco CCNA (4 moduli, ognuno da almeno 20 ore)</li>
 	<li>Cisco Voice CCNA (20 ore)</li>
 	<li>Tecnologie VoIP (protocolli SIP , SCCP , H323, SCCP) (20 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Reti","","inherit","closed","closed","","106-revision-v1","","","2016-11-12 23:12:01","2016-11-12 22:12:01","","106","http://www.onyxsistemi.it/restyling/106-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("109","1","2016-11-13 15:18:57","2016-11-13 14:18:57","Lo sviluppo software","Sviluppo software","","publish","closed","closed","","sviluppo-software","","","2016-11-13 15:18:57","2016-11-13 14:18:57","","104","http://www.onyxsistemi.it/restyling/?page_id=109","0","page","","0");
INSERT INTO `otot_posts` VALUES("110","1","2016-11-13 15:18:38","2016-11-13 14:18:38","","software-engineer","","inherit","open","closed","","software-engineer","","","2016-11-13 15:18:38","2016-11-13 14:18:38","","109","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/software-engineer.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("111","1","2016-11-13 15:18:57","2016-11-13 14:18:57","Lo sviluppo software","Sviluppo software","","inherit","closed","closed","","109-revision-v1","","","2016-11-13 15:18:57","2016-11-13 14:18:57","","109","http://www.onyxsistemi.it/restyling/109-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("112","1","2016-11-13 15:20:27","2016-11-13 14:20:27","<ul>
 	<li>Oracle Administrator ( 5 giorni)</li>
 	<li>Oracle PL/SQL (3 giorni)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Database","","publish","closed","closed","","database","","","2016-11-13 15:21:05","2016-11-13 14:21:05","","104","http://www.onyxsistemi.it/restyling/?page_id=112","0","page","","0");
INSERT INTO `otot_posts` VALUES("113","1","2016-11-13 15:20:27","2016-11-13 14:20:27","<ul>
 	<li>Oracle Administrator ( 5 giorni)</li>
 	<li>Oracle PL/SQL (3 giorni)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Database","","inherit","closed","closed","","112-revision-v1","","","2016-11-13 15:20:27","2016-11-13 14:20:27","","112","http://www.onyxsistemi.it/restyling/112-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("114","1","2016-11-13 15:20:57","2016-11-13 14:20:57","","db","","inherit","open","closed","","db","","","2016-11-13 15:20:57","2016-11-13 14:20:57","","112","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/db.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("115","1","2016-11-13 15:23:14","2016-11-13 14:23:14","<ul>
 	<li>Corso Oracle WebLogic Server 11g base/avanzato (21/45 ore)</li>
 	<li>Corso Apache Tomcat completo (3 giorni)</li>
 	<li>Corso Glassfish server open source edition v3 (21 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Amministrazione Application-Server","","publish","closed","closed","","amministrazione-application-server","","","2016-11-13 15:23:14","2016-11-13 14:23:14","","104","http://www.onyxsistemi.it/restyling/?page_id=115","0","page","","0");
INSERT INTO `otot_posts` VALUES("116","1","2016-11-13 15:23:03","2016-11-13 14:23:03","","applicaiton-server","","inherit","open","closed","","applicaiton-server","","","2016-11-13 15:23:03","2016-11-13 14:23:03","","115","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/applicaiton-server.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("117","1","2016-11-13 15:23:14","2016-11-13 14:23:14","<ul>
 	<li>Corso Oracle WebLogic Server 11g base/avanzato (21/45 ore)</li>
 	<li>Corso Apache Tomcat completo (3 giorni)</li>
 	<li>Corso Glassfish server open source edition v3 (21 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Amministrazione Application-Server","","inherit","closed","closed","","115-revision-v1","","","2016-11-13 15:23:14","2016-11-13 14:23:14","","115","http://www.onyxsistemi.it/restyling/115-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("118","1","2016-11-13 15:29:08","2016-11-13 14:29:08","<ul>
 	<li>Liferay Administration (6 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Amministrazione Portali","","publish","closed","closed","","amministrazione-portali","","","2016-11-13 15:29:08","2016-11-13 14:29:08","","104","http://www.onyxsistemi.it/restyling/?page_id=118","0","page","","0");
INSERT INTO `otot_posts` VALUES("119","1","2016-11-13 15:29:00","2016-11-13 14:29:00","","amministrazione-portale","","inherit","open","closed","","amministrazione-portale","","","2016-11-13 15:29:00","2016-11-13 14:29:00","","118","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/amministrazione-portale.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("120","1","2016-11-13 15:29:08","2016-11-13 14:29:08","<ul>
 	<li>Liferay Administration (6 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Amministrazione Portali","","inherit","closed","closed","","118-revision-v1","","","2016-11-13 15:29:08","2016-11-13 14:29:08","","118","http://www.onyxsistemi.it/restyling/118-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("121","1","2016-11-13 15:31:14","2016-11-13 14:31:14","<ul>
 	<li>Corso HTML5 e CSS3 (8 ore)</li>
 	<li>JQuery Mobile (6 ore)</li>
 	<li>Phonegap (6 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Sviluppo Web","","publish","closed","closed","","sviluppo-web","","","2016-11-13 15:31:14","2016-11-13 14:31:14","","104","http://www.onyxsistemi.it/restyling/?page_id=121","0","page","","0");
INSERT INTO `otot_posts` VALUES("122","1","2016-11-13 15:31:01","2016-11-13 14:31:01","","sviluppo-web","","inherit","open","closed","","sviluppo-web","","","2016-11-13 15:31:01","2016-11-13 14:31:01","","121","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/sviluppo-web.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("123","1","2016-11-13 15:31:14","2016-11-13 14:31:14","<ul>
 	<li>Corso HTML5 e CSS3 (8 ore)</li>
 	<li>JQuery Mobile (6 ore)</li>
 	<li>Phonegap (6 ore)</li>
</ul>
I corsi possono eventualmente essere personalizzabili su richiesta dello studente, non esitate a contattarci per richiedere maggiori informazioni.","Sviluppo Web","","inherit","closed","closed","","121-revision-v1","","","2016-11-13 15:31:14","2016-11-13 14:31:14","","121","http://www.onyxsistemi.it/restyling/121-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("124","1","2016-11-13 15:54:11","2016-11-13 14:54:11","Analista programmatore Java e project manager","Marco","","publish","open","open","","marco","","","2016-11-13 15:54:11","2016-11-13 14:54:11","","0","http://www.onyxsistemi.it/restyling/?p=124","0","post","","0");
INSERT INTO `otot_posts` VALUES("125","1","2016-11-13 15:54:01","2016-11-13 14:54:01","","marcoferretti-380x380","","inherit","open","closed","","marcoferretti-380x380","","","2016-11-13 15:54:01","2016-11-13 14:54:01","","124","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/marcoferretti-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("126","1","2016-11-13 15:54:11","2016-11-13 14:54:11","Analista programmatore Java e project manager","Marco","","inherit","closed","closed","","124-revision-v1","","","2016-11-13 15:54:11","2016-11-13 14:54:11","","124","http://www.onyxsistemi.it/restyling/124-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("127","1","2016-11-13 15:55:58","2016-11-13 14:55:58","Sviluppatore Java","Francesco","","publish","open","open","","francesco","","","2016-11-13 15:55:58","2016-11-13 14:55:58","","0","http://www.onyxsistemi.it/restyling/?p=127","0","post","","0");
INSERT INTO `otot_posts` VALUES("128","1","2016-11-13 15:55:48","2016-11-13 14:55:48","","francesco-panebianco-380x380","","inherit","open","closed","","francesco-panebianco-380x380","","","2016-11-13 15:55:48","2016-11-13 14:55:48","","127","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/francesco-panebianco-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("129","1","2016-11-13 15:55:58","2016-11-13 14:55:58","Sviluppatore Java","Francesco","","inherit","closed","closed","","127-revision-v1","","","2016-11-13 15:55:58","2016-11-13 14:55:58","","127","http://www.onyxsistemi.it/restyling/127-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("130","1","2016-11-13 15:57:37","2016-11-13 14:57:37","Analista programmatore senior Java","Domenico","","publish","open","open","","domenico","","","2016-11-13 15:57:37","2016-11-13 14:57:37","","0","http://www.onyxsistemi.it/restyling/?p=130","0","post","","0");
INSERT INTO `otot_posts` VALUES("131","1","2016-11-13 15:57:27","2016-11-13 14:57:27","","domenico-380x380","","inherit","open","closed","","domenico-380x380","","","2016-11-13 15:57:27","2016-11-13 14:57:27","","130","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/domenico-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("132","1","2016-11-13 15:57:37","2016-11-13 14:57:37","Analista programmatore senior Java","Domenico","","inherit","closed","closed","","130-revision-v1","","","2016-11-13 15:57:37","2016-11-13 14:57:37","","130","http://www.onyxsistemi.it/restyling/130-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("133","1","2016-11-13 15:58:55","2016-11-13 14:58:55","Sistemista","Luca","","publish","open","open","","luca","","","2016-11-13 15:58:55","2016-11-13 14:58:55","","0","http://www.onyxsistemi.it/restyling/?p=133","0","post","","0");
INSERT INTO `otot_posts` VALUES("134","1","2016-11-13 15:58:49","2016-11-13 14:58:49","","luca-sistemista","","inherit","open","closed","","luca-sistemista","","","2016-11-13 15:58:49","2016-11-13 14:58:49","","133","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/luca-sistemista.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("135","1","2016-11-13 15:58:55","2016-11-13 14:58:55","Sistemista","Luca","","inherit","closed","closed","","133-revision-v1","","","2016-11-13 15:58:55","2016-11-13 14:58:55","","133","http://www.onyxsistemi.it/restyling/133-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("136","1","2016-11-13 15:59:57","2016-11-13 14:59:57","Analista sicurezza","Andrea","","publish","open","open","","andrea-2","","","2016-11-13 15:59:57","2016-11-13 14:59:57","","0","http://www.onyxsistemi.it/restyling/?p=136","0","post","","0");
INSERT INTO `otot_posts` VALUES("137","1","2016-11-13 15:59:47","2016-11-13 14:59:47","","pigliacelli","","inherit","open","closed","","pigliacelli","","","2016-11-13 15:59:47","2016-11-13 14:59:47","","136","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/Pigliacelli.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("138","1","2016-11-13 15:59:57","2016-11-13 14:59:57","Analista sicurezza","Andrea","","inherit","closed","closed","","136-revision-v1","","","2016-11-13 15:59:57","2016-11-13 14:59:57","","136","http://www.onyxsistemi.it/restyling/136-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("139","1","2016-11-13 16:01:08","2016-11-13 15:01:08","Sviluppatore Java","Leonardo","","publish","open","open","","leonardo","","","2016-11-13 16:01:08","2016-11-13 15:01:08","","0","http://www.onyxsistemi.it/restyling/?p=139","0","post","","0");
INSERT INTO `otot_posts` VALUES("140","1","2016-11-13 16:01:00","2016-11-13 15:01:00","","briganti","","inherit","open","closed","","briganti","","","2016-11-13 16:01:00","2016-11-13 15:01:00","","139","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/briganti.png","0","attachment","image/png","0");
INSERT INTO `otot_posts` VALUES("141","1","2016-11-13 16:01:08","2016-11-13 15:01:08","Sviluppatore Java","Leonardo","","inherit","closed","closed","","139-revision-v1","","","2016-11-13 16:01:08","2016-11-13 15:01:08","","139","http://www.onyxsistemi.it/restyling/139-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("142","1","2016-11-13 16:03:00","2016-11-13 15:03:00","Sviluppatore Web","Federico","","publish","open","open","","federico","","","2016-11-13 16:03:00","2016-11-13 15:03:00","","0","http://www.onyxsistemi.it/restyling/?p=142","0","post","","0");
INSERT INTO `otot_posts` VALUES("143","1","2016-11-13 16:02:53","2016-11-13 15:02:53","","laurenzi-foto-380x380","","inherit","open","closed","","laurenzi-foto-380x380","","","2016-11-13 16:02:53","2016-11-13 15:02:53","","142","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/Laurenzi-foto-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("144","1","2016-11-13 16:03:00","2016-11-13 15:03:00","Sviluppatore Web","Federico","","inherit","closed","closed","","142-revision-v1","","","2016-11-13 16:03:00","2016-11-13 15:03:00","","142","http://www.onyxsistemi.it/restyling/142-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("145","1","2016-11-13 16:03:58","2016-11-13 15:03:58","Analista programmatore .NET","Marco","","publish","open","open","","marco-2","","","2016-11-13 16:03:58","2016-11-13 15:03:58","","0","http://www.onyxsistemi.it/restyling/?p=145","0","post","","0");
INSERT INTO `otot_posts` VALUES("146","1","2016-11-13 16:03:51","2016-11-13 15:03:51","","de-dominicis-380x380","","inherit","open","closed","","de-dominicis-380x380","","","2016-11-13 16:03:51","2016-11-13 15:03:51","","145","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/De-Dominicis-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("147","1","2016-11-13 16:03:58","2016-11-13 15:03:58","Analista programmatore .NET","Marco","","inherit","closed","closed","","145-revision-v1","","","2016-11-13 16:03:58","2016-11-13 15:03:58","","145","http://www.onyxsistemi.it/restyling/145-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("148","1","2016-11-13 16:05:40","2016-11-13 15:05:40","Sistemista Help Desk","Luca","","publish","open","open","","luca-2","","","2016-11-13 16:05:40","2016-11-13 15:05:40","","0","http://www.onyxsistemi.it/restyling/?p=148","0","post","","0");
INSERT INTO `otot_posts` VALUES("149","1","2016-11-13 16:05:32","2016-11-13 15:05:32","","luca-help-desk","","inherit","open","closed","","luca-help-desk","","","2016-11-13 16:05:32","2016-11-13 15:05:32","","148","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/luca-help-desk.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("150","1","2016-11-13 16:05:40","2016-11-13 15:05:40","Sistemista Help Desk","Luca","","inherit","closed","closed","","148-revision-v1","","","2016-11-13 16:05:40","2016-11-13 15:05:40","","148","http://www.onyxsistemi.it/restyling/148-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("151","1","2016-11-13 16:06:43","2016-11-13 15:06:43","Analista programmatore Java","Francesco","","publish","open","open","","francesco-2","","","2016-11-13 16:06:43","2016-11-13 15:06:43","","0","http://www.onyxsistemi.it/restyling/?p=151","0","post","","0");
INSERT INTO `otot_posts` VALUES("152","1","2016-11-13 16:06:36","2016-11-13 15:06:36","","scricco-380x380","","inherit","open","closed","","scricco-380x380","","","2016-11-13 16:06:36","2016-11-13 15:06:36","","151","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/Scricco-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("153","1","2016-11-13 16:06:43","2016-11-13 15:06:43","Analista programmatore Java","Francesco","","inherit","closed","closed","","151-revision-v1","","","2016-11-13 16:06:43","2016-11-13 15:06:43","","151","http://www.onyxsistemi.it/restyling/151-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("154","1","2016-11-13 16:07:42","2016-11-13 15:07:42","Analyst","Eleonora","","publish","open","open","","eleonora","","","2016-11-13 16:07:42","2016-11-13 15:07:42","","0","http://www.onyxsistemi.it/restyling/?p=154","0","post","","0");
INSERT INTO `otot_posts` VALUES("155","1","2016-11-13 16:07:36","2016-11-13 15:07:36","","zugaro-380x380","","inherit","open","closed","","zugaro-380x380","","","2016-11-13 16:07:36","2016-11-13 15:07:36","","154","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/Zugaro-380x380.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("156","1","2016-11-13 16:07:42","2016-11-13 15:07:42","Analyst","Eleonora","","inherit","closed","closed","","154-revision-v1","","","2016-11-13 16:07:42","2016-11-13 15:07:42","","154","http://www.onyxsistemi.it/restyling/154-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("157","1","2016-11-13 16:09:01","2016-11-13 15:09:01","Analista programmatore Java","Stanislao","","publish","open","open","","stanislao","","","2016-11-13 16:09:01","2016-11-13 15:09:01","","0","http://www.onyxsistemi.it/restyling/?p=157","0","post","","0");
INSERT INTO `otot_posts` VALUES("158","1","2016-11-13 16:08:51","2016-11-13 15:08:51","","stanislao","","inherit","open","closed","","stanislao","","","2016-11-13 16:08:51","2016-11-13 15:08:51","","157","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/stanislao.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("159","1","2016-11-13 16:09:01","2016-11-13 15:09:01","Analista programmatore Java","Stanislao","","inherit","closed","closed","","157-revision-v1","","","2016-11-13 16:09:01","2016-11-13 15:09:01","","157","http://www.onyxsistemi.it/restyling/157-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("160","3","2016-11-14 14:13:14","0000-00-00 00:00:00","","Home","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=160","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("161","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=161","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("162","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=162","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("163","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=163","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("164","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=164","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("165","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=165","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("166","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=166","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("167","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=167","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("168","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=168","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("169","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=169","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("170","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=170","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("171","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=171","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("172","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=172","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("173","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=173","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("174","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=174","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("175","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=175","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("176","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=176","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("177","3","2016-11-14 14:13:14","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:14","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=177","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("178","3","2016-11-14 14:13:57","0000-00-00 00:00:00","","Home","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=178","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("179","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=179","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("180","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=180","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("181","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=181","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("182","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=182","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("183","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=183","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("184","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=184","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("185","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=185","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("186","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=186","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("187","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=187","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("188","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=188","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("189","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=189","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("190","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","104","http://www.onyxsistemi.it/restyling/?p=190","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("191","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=191","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("192","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=192","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("193","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=193","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("194","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=194","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("195","3","2016-11-14 14:13:57","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2016-11-14 14:13:57","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?p=195","1","nav_menu_item","","0");
INSERT INTO `otot_posts` VALUES("203","1","2016-11-22 00:10:45","2016-11-21 23:10:45","Sviluppatore Datastage","Luigi","","publish","open","open","","luigi","","","2016-11-22 00:10:45","2016-11-21 23:10:45","","0","http://www.onyxsistemi.it/restyling/?p=203","0","post","","0");
INSERT INTO `otot_posts` VALUES("198","1","2016-11-16 23:52:01","2016-11-16 22:52:01","Le immagini e i video presenti su questo sito sono autoprodotti, ovvero sono stati utilizzati a seguito di un acquisto, o in ultimo sfruttano licenze apposite per l\'utilizzo gratuito, essendo di pubblico dominio. Qualora si volesse rivendicare l\'attribuzione di tali supporti, si prega di inviare un messaggio nella sezione <em>Contatti</em> di questo sito. Il video in homepage è stato realizzato da Claudio Alberti.

&nbsp;","Credits","","publish","closed","closed","","credits","","","2016-11-16 23:52:01","2016-11-16 22:52:01","","0","http://www.onyxsistemi.it/restyling/?page_id=198","0","page","","0");
INSERT INTO `otot_posts` VALUES("199","1","2016-11-16 23:40:46","2016-11-16 22:40:46","","squadra-rg","","inherit","open","closed","","squadra-rg","","","2016-11-16 23:40:46","2016-11-16 22:40:46","","198","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/squadra-rg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("200","1","2016-11-16 23:42:27","2016-11-16 22:42:27","","team-building","","inherit","open","closed","","team-building","","","2016-11-16 23:42:27","2016-11-16 22:42:27","","198","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/team-building.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("201","1","2016-11-16 23:52:01","2016-11-16 22:52:01","Le immagini e i video presenti su questo sito sono autoprodotti, ovvero sono stati utilizzati a seguito di un acquisto, o in ultimo sfruttano licenze apposite per l\'utilizzo gratuito, essendo di pubblico dominio. Qualora si volesse rivendicare l\'attribuzione di tali supporti, si prega di inviare un messaggio nella sezione <em>Contatti</em> di questo sito. Il video in homepage è stato realizzato da Claudio Alberti.

&nbsp;","Credits","","inherit","closed","closed","","198-revision-v1","","","2016-11-16 23:52:01","2016-11-16 22:52:01","","198","http://www.onyxsistemi.it/restyling/198-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("233","1","2016-11-25 23:08:35","2016-11-25 22:08:35","Cerchiamo 5 risorse per la nostra sede di Milano","Sistemisti di Rete e Sicurezza (MI)","","trash","closed","closed","","sistemisti-di-rete-e-sicurezza-mi__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/sistemisti-di-rete-e-sicurezza-mi/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("205","1","2016-11-22 00:10:45","2016-11-21 23:10:45","Sviluppatore Datastage","Luigi","","inherit","closed","closed","","203-revision-v1","","","2016-11-22 00:10:45","2016-11-21 23:10:45","","203","http://www.onyxsistemi.it/restyling/203-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("206","1","2016-11-22 00:11:34","2016-11-21 23:11:34","Programmatore Java","Alessandro","","publish","open","open","","alessandro","","","2016-11-22 00:11:34","2016-11-21 23:11:34","","0","http://www.onyxsistemi.it/restyling/?p=206","0","post","","0");
INSERT INTO `otot_posts` VALUES("207","1","2016-11-22 00:11:29","2016-11-21 23:11:29","","alessandro","","inherit","open","closed","","alessandro","","","2016-11-22 00:11:29","2016-11-21 23:11:29","","206","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/alessandro.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("208","1","2016-11-22 00:11:34","2016-11-21 23:11:34","Programmatore Java","Alessandro","","inherit","closed","closed","","206-revision-v1","","","2016-11-22 00:11:34","2016-11-21 23:11:34","","206","http://www.onyxsistemi.it/restyling/206-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("209","1","2016-11-22 00:12:43","2016-11-21 23:12:43","Sviluppatore PHP","Valerio","","publish","open","open","","valerio","","","2016-11-22 00:12:43","2016-11-21 23:12:43","","0","http://www.onyxsistemi.it/restyling/?p=209","0","post","","0");
INSERT INTO `otot_posts` VALUES("210","1","2016-11-22 00:12:37","2016-11-21 23:12:37","","valerio","","inherit","open","closed","","valerio","","","2016-11-22 00:12:37","2016-11-21 23:12:37","","209","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/valerio.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("211","1","2016-11-22 00:12:43","2016-11-21 23:12:43","Sviluppatore PHP","Valerio","","inherit","closed","closed","","209-revision-v1","","","2016-11-22 00:12:43","2016-11-21 23:12:43","","209","http://www.onyxsistemi.it/restyling/209-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("212","1","2016-11-22 00:13:35","2016-11-21 23:13:35","Sviluppatore Java Junior","Dario","","publish","open","open","","dario","","","2016-11-22 00:13:35","2016-11-21 23:13:35","","0","http://www.onyxsistemi.it/restyling/?p=212","0","post","","0");
INSERT INTO `otot_posts` VALUES("213","1","2016-11-22 00:13:30","2016-11-21 23:13:30","","dario","","inherit","open","closed","","dario","","","2016-11-22 00:13:30","2016-11-21 23:13:30","","212","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/dario.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("214","1","2016-11-22 00:13:35","2016-11-21 23:13:35","Sviluppatore Java Junior","Dario","","inherit","closed","closed","","212-revision-v1","","","2016-11-22 00:13:35","2016-11-21 23:13:35","","212","http://www.onyxsistemi.it/restyling/212-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("215","1","2016-11-22 00:14:38","2016-11-21 23:14:38","Specialista Sicurezza","Ivan","","publish","open","open","","ivan","","","2016-11-22 00:14:38","2016-11-21 23:14:38","","0","http://www.onyxsistemi.it/restyling/?p=215","0","post","","0");
INSERT INTO `otot_posts` VALUES("216","1","2016-11-22 00:14:32","2016-11-21 23:14:32","","ivan","","inherit","open","closed","","ivan","","","2016-11-22 00:14:32","2016-11-21 23:14:32","","215","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/ivan.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("217","1","2016-11-22 00:14:38","2016-11-21 23:14:38","Specialista Sicurezza","Ivan","","inherit","closed","closed","","215-revision-v1","","","2016-11-22 00:14:38","2016-11-21 23:14:38","","215","http://www.onyxsistemi.it/restyling/215-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("218","1","2016-11-22 00:16:16","2016-11-21 23:16:16","Security Manager","Paolo","","publish","open","open","","paolo","","","2016-11-22 00:16:16","2016-11-21 23:16:16","","0","http://www.onyxsistemi.it/restyling/?p=218","0","post","","0");
INSERT INTO `otot_posts` VALUES("219","1","2016-11-22 00:16:10","2016-11-21 23:16:10","","paolo","","inherit","open","closed","","paolo","","","2016-11-22 00:16:10","2016-11-21 23:16:10","","218","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/paolo.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("220","1","2016-11-22 00:16:16","2016-11-21 23:16:16","Security Manager","Paolo","","inherit","closed","closed","","218-revision-v1","","","2016-11-22 00:16:16","2016-11-21 23:16:16","","218","http://www.onyxsistemi.it/restyling/218-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("221","1","2016-11-22 00:18:02","2016-11-21 23:18:02","Sviluppatore Java","Stefano","","publish","open","open","","stefano","","","2016-11-22 00:18:02","2016-11-21 23:18:02","","0","http://www.onyxsistemi.it/restyling/?p=221","0","post","","0");
INSERT INTO `otot_posts` VALUES("222","1","2016-11-22 00:17:56","2016-11-21 23:17:56","","stefano","","inherit","open","closed","","stefano","","","2016-11-22 00:17:56","2016-11-21 23:17:56","","221","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/stefano.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("223","1","2016-11-22 00:18:02","2016-11-21 23:18:02","Sviluppatore Java","Stefano","","inherit","closed","closed","","221-revision-v1","","","2016-11-22 00:18:02","2016-11-21 23:18:02","","221","http://www.onyxsistemi.it/restyling/221-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("224","1","2016-11-23 00:23:30","2016-11-22 23:23:30","<div id=\"block-general\" class=\"ui-container row white c-left c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

&nbsp;

Onyx Technology intende prendere tutte le misure che garantiscano la riservatezza dei dati degli utenti. Tali misure rispecchiano gli standard contenuti nelle leggi europee in materia di privacy dei dati e sono state approvate dai garanti europei per la protezione dei dati personali (Area Economica Europea e Svizzera).

Ony Technology raccoglie i dati personali di dipendenti, candidati, fornitori, contatti professionali e utenti del sito web.

Cerchiamo sempre di informare in modo adeguato tali soggetti in merito ai dati che saranno raccolti e al modo in cui gli stessi saranno utilizzati. In ogni caso tratteremo quei dati solo se reputeremo giusto e lecito farlo. Non vendiamo i dati personali a soggetti terzi. Possiamo trasferire dati personali ai nostri fornitori di servizi e ai consulenti che si trovano in altri paesi. Prima di farlo, adottiamo misure atte a garantire che i dati personali siano adeguatamente protetti, come richiesto dalle leggi in materia e dalle policy interne.

Si possono tuttavia verificare altre circostanze in cui è necessario condividere o divulgare i dati personali da voi forniti per uno scopo specifico.

Decidendo di fornire spontaneamente ad Onyx Technology dati personali sensibili non richiesti, acconsentite al loro uso da parte nostra, nel rispetto della legge applicabile, come spiegato nel presente documento. L\'espressione \"dati personali sensibili\" si riferisce alle varie categorie di dati personali identificate da leggi europee e da altre leggi sulla riservatezza delle informazioni che ne impongono un trattamento speciale e, in alcune circostanze, la necessità di ottenere un esplicito consenso. Queste categorie possono includere i numeri di identificazione personali, le informazioni sui conti finanziari, l\'origine razziale o etnica, le opinioni politiche, religiose, filosofiche o di altro genere, l\'adesione a un sindacato, un\'associazione professionale o commerciale, la salute fisica o mentale, i dati biometrici o genetici, gli orientamenti sessuali o i precedenti penali (incluse informazioni su attività criminali sospette).

Onyx Technology adotta misure appropriate per garantire la sicurezza dei dati personali raccolti. Per quanto riguarda l\'uso dei nostri siti web, va sottolineato che la natura di Internet è tale per cui le informazioni e i dati personali possono essere liberamente presenti su reti che si collegano ai nostri sistemi senza misure di sicurezza, e possono essere accessibili e utilizzabili da persone diverse da quelle cui i dati sono destinati.

Il sito di Onyx Technology può, di volta in volta, contenere link da e verso i siti delle reti di partner, inserzionisti e<a name=\"CookieID6\"></a>affiliati. Se si segue un link a uno di questi siti, si prega di notare che questi siti hanno le proprie policy sulla privacy e che non accettiamo alcuna responsabilità per tali policy o siti. Si raccomanda di controllare le policy di questi siti prima di inviare dati personali.

Conserveremo i vostri dati personali solo per il tempo necessario. È vostro diritto sapere se conserviamo i vostri dati personali e, in caso affermativo, accedere ad essi e richiedere che vengano corretti qualora contengano imprecisioni. Il miglior modo di farlo è accedere alla nostra pagina dei Contatti.

Scopo principale del sito web è quello di essere una risorsa e uno strumento di business dinamico per aiutarvi ad avere più informazioni su di noi. Vogliamo che vi sentiate sicuri, per questo ci impegniamo a tutelare la vostra privacy quando visitate il nostro sito web.

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-websites\" class=\"ui-container color-container row periwinkle-blue c-right c-ui-edge\" data-shape=\"edge\" data-shape-color=\"periwinkle-blue\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

Onyx Technology raccoglie informazioni sui propri siti web in due modi: (1) direttamente (ad esempio, quando fornite informazioni per iscrivervi a una newsletter o registrarvi su un forum) e (2) indirettamente (ad esempio, attraverso la tecnologia utilizzata sul sito).

Possiamo raccogliere ed elaborare le seguenti informazioni che vi riguardano:
<ul>
 	<li>Informazioni fornite compilando moduli sul nostro sito.</li>
 	<li>Se ci contattate, potremmo conservare una registrazione di tale corrispondenza.</li>
 	<li>Potremmo chiedervi di compilare dei sondaggi che utilizzeremo per scopi di ricerca, ma non siete obbligati a rispondere.</li>
 	<li>Ogni post, commento o altro contenuto che viene caricato o pubblicato.</li>
 	<li>Il nostro sito raccoglie informazioni sul vostro computer, inclusi (ove disponibili) l\'indirizzo IP, il sistema operativo e il tipo di browser, che servono per la gestione del sistema, per filtrare il traffico, per cercare i domini degli utenti e per riferire statistiche.</li>
 	<li>I dettagli delle vostre visite sul nostro sito, le pagine visualizzate e le risorse a cui avete accesso o che scaricate, inclusi, tra l\'altro, dati sul traffico, dati sulla posizione, registri web e altri dati di comunicazione.</li>
</ul>
Quando le informazioni si riferiscono a voi o vi identificano, le trattiamo come \"dati personali\".

Utilizziamo i vostri dati personali per fornirvi le informazioni richieste, elaborare candidature online e per altri scopi che saranno descritti nel momento in cui verranno raccolti i dati o che diverranno evidenti per voi. Ad esempio per:
<ul>
 	<li>Soddisfare le vostre richieste di contenuti.</li>
 	<li>Personalizzare la vostra esperienza sul nostro sito.</li>
 	<li>Contattarvi per scopi di marketing dopo che avrete dato il vostro consenso.</li>
</ul>
&nbsp;

COOKIE

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-cookie\" class=\"ui-container row white c-right c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"block-title iscrisscrossed\"></div>
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"><strong>Cosa sono i cookie?</strong></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

I cookie sono file di testo che contengono piccole quantità di informazioni scaricate sul vostro computer o dispositivo mobile quando visitate un sito web. I cookie vengono poi rimandati al sito di origine ad ogni visita successiva, o a un altro sito web che li riconosce. I cookie sono utili perché consentono a un sito web di riconoscere il dispositivo dell\'utente. Potete trovare maggiori informazioni sui cookie ai seguenti indirizzi: <a title=\"All About Cookies. Questo link apre una nuova finestra.\" href=\"http://www.allaboutcookies.org/\" target=\"_blank\">www.allaboutcookies.org</a> e <a title=\"Your Online Choices. Questo link apre una nuova finestra.\" href=\"http://www.youronlinechoices.eu/\" target=\"_blank\">www.youronlinechoices.eu</a>. For a video about cookies visit www.google.co.uk/goodtoknow/data-on-the-web/cookies.

I cookie svolgono molti compiti diversi, ad esempio vi fanno spostare tra le pagine in modo efficiente, ricordando le vostre preferenze, e in generale migliorano la user experience. Possono anche contribuire a rendere più rilevanti per voi e i vostri interessi specifici i messaggi pubblicitari e gli altri contenuti visualizzati online. Possono essere impostati dal sito web che state visitando (cookie proprietari) o da un altro soggetto, ad esempio una rete pubblicitaria (cookie di terze parti). I cookie utilizzati in questo sito sono stati classificati sulla base delle quattro categorie presenti nella <a title=\"Click here to download the full article. ICC UK Cookie Guide. Questo link apre una nuova finestra.\" href=\"https://www.accenture.com/t00010101T000000__w__/it-it/_acnmedia/Accenture/Conversion-Assets/DotCom/Documents/Global/PDF/Technology_8/Accenture-ICC-UK-Cookie-Guide.pdf#zoom=50\" target=\"_blank\">ICC UK Cookie guide</a>. Di seguito è riportato un elenco di tutti i cookie utilizzati in questo sito divisi per categorie. All\'interno delle quattro categorie, i cookie possono essere associati alla sessione o essere persistenti. I cookie di sessione sono temporanei e una volta che si chiude la finestra del browser vengono cancellati dal dispositivo. I cookie persistenti rimangono sul dispositivo per un periodo più lungo e vengono utilizzati dal sito web per riconoscere il dispositivo quando si ritorna su un sito.

<strong>Cosa devo fare se non voglio i cookie?</strong>
Con l\'utilizzo del nostro sito web l\'utente accetta la presenza dei cookie e di altre tecnologie simili sul proprio dispositivo, come spiegato di seguito. Se si desidera rimuovere i cookie esistenti dal dispositivo, è possibile farlo utilizzando le opzioni del browser. Se in futuro si desidera bloccare i cookie in modo che non vengano installati sul dispositivo, è possibile farlo modificando le impostazioni del browser.

Si prega di tenere presente che la cancellazione e il blocco dei cookie avrà un impatto sulla user experience, in quanto alcune parti del sito potrebbero non funzionare più. A meno non abbiate impostato il browser per bloccare i cookie, il nostro sistema li inserirà non appena visiterete il nostro sito web o farete clic su un collegamento in un messaggio mirato che vi abbiamo inviato, anche se in precedenza i nostri cookie sono stati eliminati.

Quali sono i tipi di cookie e quali possono essere utilizzati su questo sito?

<strong>Cookie strettamente necessari</strong> - Questi cookie sono essenziali per spostarsi nel sito e utilizzarne le funzioni, come ad esempio accedere ad aree protette del sito stesso. Senza questi cookie, i servizi richiesti non possono essere forniti.

Cookie di visitatori registrati - Identificatore univoco assegnato a ciascun utente registrato, utilizzato per riconoscerne la visita e il ritorno sul sito. (vedere anche i cookie tecnici, più avanti).

<strong>Performance Cookie</strong> - Cookie che raccolgono informazioni su come gli utenti utilizzano un sito web, ad esempio, quali pagine visitano più frequentemente, e se ricevono messaggi di errore da pagine web. Questi cookie non raccolgono informazioni che identificano il visitatore. Tutte le informazioni raccolte da questi cookie sono anonime e vengono utilizzate solo per migliorare il funzionamento del sito web.

<strong>Cookie tecnici</strong> – Permettono a un sito web di ricordare le scelte fatte dall\'utente (il nome utente, la lingua o la regione in cui si trova) e di fornire funzionalità avanzate, più personali. Ad esempio un sito web può essere in grado di fornire informazioni o notizie locali memorizzando in un cookie la regione geografica in cui si trova l\'utente. Questi cookie possono essere utilizzati anche per ricordare le modifiche apportate alle dimensioni del testo, il carattere e le altre parti delle pagine web che è possibile personalizzare.

Possono essere utilizzati anche per fornire servizi richiesti dall\'utente, come la possibilità di guardare un video o di inserire commenti su un blog. Questi cookie non sono in grado tenere traccia dell\'attività di navigazione su altri siti web. Non raccolgono informazioni su di voi che potrebbero essere utilizzate per la pubblicità o per registrare dove siete stati su Internet al di fuori del sito Accenture.

<strong>Cookie di targeting</strong> – Questi cookie vengono utilizzati per: (1) fornire messaggi pubblicitari considerati rilevanti per l\'utente, (2) limitare il numero di volte in cui l\'utente vede una pubblicità, (3) misurare l\'efficacia della campagna pubblicitaria, e (4) comprendere il comportamento degli utenti dopo la visualizzazione di un annuncio pubblicitario. In genere questi cookie vengono installati dalle reti di pubblicità con l\'autorizzazione del gestore del sito. Registrano la visita dell\'utente a un sito web e condividono questa informazione con altre organizzazioni, come gli inserzionisti. Molto spesso i cookie saranno collegati alla funzionalità del sito web fornito dall\'altra organizzazione.

Onyx Technology non ospita sul proprio sito pubblicità di terzi, ma questi cookie possono essere presenti su siti esterni e altri soggetti possono utilizzarli sul nostro sito.
<ol>
 	<li>Siti di social media di terze parti possono registrare le informazioni sull\'utente, ad esempio, quando si fa clic sul pulsante \"Aggiungi\" oppure \"Mi piace\" per un sito di social media, durante la navigazione sul sito di Accenture. Noi non controlliamo questi siti, né le loro attività. L\'utente ha la possibilità di trovare informazioni in proposito sui siti in questione. Si consiglia di leggere i termini e le condizioni di utilizzo e la policy sulla privacy di tali siti prima di utilizzarli.</li>
 	<li>Se l\'utente fa clic su un annuncio Accenture presente su un sito diverso dal nostro, può essere utilizzato un cookie per registrare il sito in cui si trova l\'utente al fine di garantire che i nostri annunci siano presentati in modo efficace e stabilire se vengono visualizzati. A questo scopo Accenture può utilizzare fornitori di servizi come Doubleclick, MediaMind, www.DidIt.com e altri.</li>
 	<li>Siamo partner di ShareThis sul nostro sito web. ShareThis è un widget che consente agli utenti di condividere con altri i contenuti del sito attraverso social media come Facebook e Twitter. ShareThis inserisce sul sito dei cookie che raccolgono informazioni sull\'uso del sito stesso da parte degli utenti e associano questi ultimi ad argomenti di interesse, in base ai contenuti da loro condivisi. Questi dati saranno utilizzati per gli analytics relativi al sito web (creazione di statistiche in merito a ciò che è più popolare e a quante persone condividono un contenuto specifico) e per definire un target pubblicitario su altri siti esterni. ShareThis può condividere i propri dati di analisi con Accenture. Per questi scopi ShareThis non utilizza gli identificatori personali degli utenti (come i nomi e gli indirizzi e-mail) e l\'identificazione avviene solo in modo anonimo. Per maggiori informazioni su ShareThis, i cookie che utilizza e su come rinunciarvi, consultare il sito web ShareThis [<a title=\"Share This Privacy. Questo link apre una nuova finestra.\" href=\"http://www.sharethis.com/privacy\" target=\"_blank\">www.sharethis.com/privacy</a>].</li>
 	<li>Accenture si avvale di società affidabili per raccogliere e ricevere informazioni sugli utenti del nostro sito web e della pubblicità e per fornire annunci mirati su siti di terze parti. Questi soggetti utilizzano solo identificatori anonimi e non hanno modo di associarli a utenti identificabili. Organizzazioni come Quantcast e Retargeter svolgono queste attività per conto di Accenture ed è possibile avere maggiori informazioni a riguardo visitando il loro siti o facendo clic sull\'icona AdChoices negli annunci di Accenture.</li>
 	<li>Collaboriamo anche con alcuni social media come Facebook e Twitter per aggiungere pixel di conversione ad alcune pagine del nostro sito che ci consentono di coinvolgere nuovamente i visitatori. I pixel di conversione sono piccoli codici inseriti in una specifica pagina web e vengono attivati quando l\'utente vi accede, con un conseguente aumento del numero di conversioni. Questi pixel consentono di rivolgere la pubblicità ai visitatori da Facebook e Twitter in modo che continuino la loro esperienza con Accenture.</li>
</ol>
<strong>Uso dei cookie per il marketing e gli analytics</strong> Accenture può utilizzare le informazioni raccolte dai nostri cookie per identificare il comportamento degli utenti e fornire contenuti e offerte in base al loro profilo e per altre finalità descritte di seguito. Si tenga presente che alcune di queste attività potrebbero essere svolte soltanto in alcuni Paesi.

Alcuni dei cookie utilizzati da Accenture non raccolgono informazioni che identificano il visitatore. Ad esempio:
<ul>
 	<li>Cookie di performance (vedere sopra)</li>
 	<li>Cookie di targeting (vedere sopra) in cui l\'utente non è registrato</li>
</ul>
In altri casi possiamo associare a una persona identificabile le informazioni dei cookie, incluse quelle provenienti da cookie inseriti sui siti di terze parti tramite le nostre pubblicità.

</div>
</div>
</div>
</section></div>
</div>","Privacy","","publish","closed","closed","","privacy","","","2016-11-24 01:00:59","2016-11-24 00:00:59","","0","http://www.onyxsistemi.it/restyling/?page_id=224","0","page","","0");
INSERT INTO `otot_posts` VALUES("227","1","2016-11-24 01:00:59","2016-11-24 00:00:59","<div id=\"block-general\" class=\"ui-container row white c-left c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

&nbsp;

Onyx Technology intende prendere tutte le misure che garantiscano la riservatezza dei dati degli utenti. Tali misure rispecchiano gli standard contenuti nelle leggi europee in materia di privacy dei dati e sono state approvate dai garanti europei per la protezione dei dati personali (Area Economica Europea e Svizzera).

Ony Technology raccoglie i dati personali di dipendenti, candidati, fornitori, contatti professionali e utenti del sito web.

Cerchiamo sempre di informare in modo adeguato tali soggetti in merito ai dati che saranno raccolti e al modo in cui gli stessi saranno utilizzati. In ogni caso tratteremo quei dati solo se reputeremo giusto e lecito farlo. Non vendiamo i dati personali a soggetti terzi. Possiamo trasferire dati personali ai nostri fornitori di servizi e ai consulenti che si trovano in altri paesi. Prima di farlo, adottiamo misure atte a garantire che i dati personali siano adeguatamente protetti, come richiesto dalle leggi in materia e dalle policy interne.

Si possono tuttavia verificare altre circostanze in cui è necessario condividere o divulgare i dati personali da voi forniti per uno scopo specifico.

Decidendo di fornire spontaneamente ad Onyx Technology dati personali sensibili non richiesti, acconsentite al loro uso da parte nostra, nel rispetto della legge applicabile, come spiegato nel presente documento. L\'espressione \"dati personali sensibili\" si riferisce alle varie categorie di dati personali identificate da leggi europee e da altre leggi sulla riservatezza delle informazioni che ne impongono un trattamento speciale e, in alcune circostanze, la necessità di ottenere un esplicito consenso. Queste categorie possono includere i numeri di identificazione personali, le informazioni sui conti finanziari, l\'origine razziale o etnica, le opinioni politiche, religiose, filosofiche o di altro genere, l\'adesione a un sindacato, un\'associazione professionale o commerciale, la salute fisica o mentale, i dati biometrici o genetici, gli orientamenti sessuali o i precedenti penali (incluse informazioni su attività criminali sospette).

Onyx Technology adotta misure appropriate per garantire la sicurezza dei dati personali raccolti. Per quanto riguarda l\'uso dei nostri siti web, va sottolineato che la natura di Internet è tale per cui le informazioni e i dati personali possono essere liberamente presenti su reti che si collegano ai nostri sistemi senza misure di sicurezza, e possono essere accessibili e utilizzabili da persone diverse da quelle cui i dati sono destinati.

Il sito di Onyx Technology può, di volta in volta, contenere link da e verso i siti delle reti di partner, inserzionisti e<a name=\"CookieID6\"></a>affiliati. Se si segue un link a uno di questi siti, si prega di notare che questi siti hanno le proprie policy sulla privacy e che non accettiamo alcuna responsabilità per tali policy o siti. Si raccomanda di controllare le policy di questi siti prima di inviare dati personali.

Conserveremo i vostri dati personali solo per il tempo necessario. È vostro diritto sapere se conserviamo i vostri dati personali e, in caso affermativo, accedere ad essi e richiedere che vengano corretti qualora contengano imprecisioni. Il miglior modo di farlo è accedere alla nostra pagina dei Contatti.

Scopo principale del sito web è quello di essere una risorsa e uno strumento di business dinamico per aiutarvi ad avere più informazioni su di noi. Vogliamo che vi sentiate sicuri, per questo ci impegniamo a tutelare la vostra privacy quando visitate il nostro sito web.

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-websites\" class=\"ui-container color-container row periwinkle-blue c-right c-ui-edge\" data-shape=\"edge\" data-shape-color=\"periwinkle-blue\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

Onyx Technology raccoglie informazioni sui propri siti web in due modi: (1) direttamente (ad esempio, quando fornite informazioni per iscrivervi a una newsletter o registrarvi su un forum) e (2) indirettamente (ad esempio, attraverso la tecnologia utilizzata sul sito).

Possiamo raccogliere ed elaborare le seguenti informazioni che vi riguardano:
<ul>
 	<li>Informazioni fornite compilando moduli sul nostro sito.</li>
 	<li>Se ci contattate, potremmo conservare una registrazione di tale corrispondenza.</li>
 	<li>Potremmo chiedervi di compilare dei sondaggi che utilizzeremo per scopi di ricerca, ma non siete obbligati a rispondere.</li>
 	<li>Ogni post, commento o altro contenuto che viene caricato o pubblicato.</li>
 	<li>Il nostro sito raccoglie informazioni sul vostro computer, inclusi (ove disponibili) l\'indirizzo IP, il sistema operativo e il tipo di browser, che servono per la gestione del sistema, per filtrare il traffico, per cercare i domini degli utenti e per riferire statistiche.</li>
 	<li>I dettagli delle vostre visite sul nostro sito, le pagine visualizzate e le risorse a cui avete accesso o che scaricate, inclusi, tra l\'altro, dati sul traffico, dati sulla posizione, registri web e altri dati di comunicazione.</li>
</ul>
Quando le informazioni si riferiscono a voi o vi identificano, le trattiamo come \"dati personali\".

Utilizziamo i vostri dati personali per fornirvi le informazioni richieste, elaborare candidature online e per altri scopi che saranno descritti nel momento in cui verranno raccolti i dati o che diverranno evidenti per voi. Ad esempio per:
<ul>
 	<li>Soddisfare le vostre richieste di contenuti.</li>
 	<li>Personalizzare la vostra esperienza sul nostro sito.</li>
 	<li>Contattarvi per scopi di marketing dopo che avrete dato il vostro consenso.</li>
</ul>
&nbsp;

COOKIE

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-cookie\" class=\"ui-container row white c-right c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"block-title iscrisscrossed\"></div>
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"><strong>Cosa sono i cookie?</strong></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

I cookie sono file di testo che contengono piccole quantità di informazioni scaricate sul vostro computer o dispositivo mobile quando visitate un sito web. I cookie vengono poi rimandati al sito di origine ad ogni visita successiva, o a un altro sito web che li riconosce. I cookie sono utili perché consentono a un sito web di riconoscere il dispositivo dell\'utente. Potete trovare maggiori informazioni sui cookie ai seguenti indirizzi: <a title=\"All About Cookies. Questo link apre una nuova finestra.\" href=\"http://www.allaboutcookies.org/\" target=\"_blank\">www.allaboutcookies.org</a> e <a title=\"Your Online Choices. Questo link apre una nuova finestra.\" href=\"http://www.youronlinechoices.eu/\" target=\"_blank\">www.youronlinechoices.eu</a>. For a video about cookies visit www.google.co.uk/goodtoknow/data-on-the-web/cookies.

I cookie svolgono molti compiti diversi, ad esempio vi fanno spostare tra le pagine in modo efficiente, ricordando le vostre preferenze, e in generale migliorano la user experience. Possono anche contribuire a rendere più rilevanti per voi e i vostri interessi specifici i messaggi pubblicitari e gli altri contenuti visualizzati online. Possono essere impostati dal sito web che state visitando (cookie proprietari) o da un altro soggetto, ad esempio una rete pubblicitaria (cookie di terze parti). I cookie utilizzati in questo sito sono stati classificati sulla base delle quattro categorie presenti nella <a title=\"Click here to download the full article. ICC UK Cookie Guide. Questo link apre una nuova finestra.\" href=\"https://www.accenture.com/t00010101T000000__w__/it-it/_acnmedia/Accenture/Conversion-Assets/DotCom/Documents/Global/PDF/Technology_8/Accenture-ICC-UK-Cookie-Guide.pdf#zoom=50\" target=\"_blank\">ICC UK Cookie guide</a>. Di seguito è riportato un elenco di tutti i cookie utilizzati in questo sito divisi per categorie. All\'interno delle quattro categorie, i cookie possono essere associati alla sessione o essere persistenti. I cookie di sessione sono temporanei e una volta che si chiude la finestra del browser vengono cancellati dal dispositivo. I cookie persistenti rimangono sul dispositivo per un periodo più lungo e vengono utilizzati dal sito web per riconoscere il dispositivo quando si ritorna su un sito.

<strong>Cosa devo fare se non voglio i cookie?</strong>
Con l\'utilizzo del nostro sito web l\'utente accetta la presenza dei cookie e di altre tecnologie simili sul proprio dispositivo, come spiegato di seguito. Se si desidera rimuovere i cookie esistenti dal dispositivo, è possibile farlo utilizzando le opzioni del browser. Se in futuro si desidera bloccare i cookie in modo che non vengano installati sul dispositivo, è possibile farlo modificando le impostazioni del browser.

Si prega di tenere presente che la cancellazione e il blocco dei cookie avrà un impatto sulla user experience, in quanto alcune parti del sito potrebbero non funzionare più. A meno non abbiate impostato il browser per bloccare i cookie, il nostro sistema li inserirà non appena visiterete il nostro sito web o farete clic su un collegamento in un messaggio mirato che vi abbiamo inviato, anche se in precedenza i nostri cookie sono stati eliminati.

Quali sono i tipi di cookie e quali possono essere utilizzati su questo sito?

<strong>Cookie strettamente necessari</strong> - Questi cookie sono essenziali per spostarsi nel sito e utilizzarne le funzioni, come ad esempio accedere ad aree protette del sito stesso. Senza questi cookie, i servizi richiesti non possono essere forniti.

Cookie di visitatori registrati - Identificatore univoco assegnato a ciascun utente registrato, utilizzato per riconoscerne la visita e il ritorno sul sito. (vedere anche i cookie tecnici, più avanti).

<strong>Performance Cookie</strong> - Cookie che raccolgono informazioni su come gli utenti utilizzano un sito web, ad esempio, quali pagine visitano più frequentemente, e se ricevono messaggi di errore da pagine web. Questi cookie non raccolgono informazioni che identificano il visitatore. Tutte le informazioni raccolte da questi cookie sono anonime e vengono utilizzate solo per migliorare il funzionamento del sito web.

<strong>Cookie tecnici</strong> – Permettono a un sito web di ricordare le scelte fatte dall\'utente (il nome utente, la lingua o la regione in cui si trova) e di fornire funzionalità avanzate, più personali. Ad esempio un sito web può essere in grado di fornire informazioni o notizie locali memorizzando in un cookie la regione geografica in cui si trova l\'utente. Questi cookie possono essere utilizzati anche per ricordare le modifiche apportate alle dimensioni del testo, il carattere e le altre parti delle pagine web che è possibile personalizzare.

Possono essere utilizzati anche per fornire servizi richiesti dall\'utente, come la possibilità di guardare un video o di inserire commenti su un blog. Questi cookie non sono in grado tenere traccia dell\'attività di navigazione su altri siti web. Non raccolgono informazioni su di voi che potrebbero essere utilizzate per la pubblicità o per registrare dove siete stati su Internet al di fuori del sito Accenture.

<strong>Cookie di targeting</strong> – Questi cookie vengono utilizzati per: (1) fornire messaggi pubblicitari considerati rilevanti per l\'utente, (2) limitare il numero di volte in cui l\'utente vede una pubblicità, (3) misurare l\'efficacia della campagna pubblicitaria, e (4) comprendere il comportamento degli utenti dopo la visualizzazione di un annuncio pubblicitario. In genere questi cookie vengono installati dalle reti di pubblicità con l\'autorizzazione del gestore del sito. Registrano la visita dell\'utente a un sito web e condividono questa informazione con altre organizzazioni, come gli inserzionisti. Molto spesso i cookie saranno collegati alla funzionalità del sito web fornito dall\'altra organizzazione.

Onyx Technology non ospita sul proprio sito pubblicità di terzi, ma questi cookie possono essere presenti su siti esterni e altri soggetti possono utilizzarli sul nostro sito.
<ol>
 	<li>Siti di social media di terze parti possono registrare le informazioni sull\'utente, ad esempio, quando si fa clic sul pulsante \"Aggiungi\" oppure \"Mi piace\" per un sito di social media, durante la navigazione sul sito di Accenture. Noi non controlliamo questi siti, né le loro attività. L\'utente ha la possibilità di trovare informazioni in proposito sui siti in questione. Si consiglia di leggere i termini e le condizioni di utilizzo e la policy sulla privacy di tali siti prima di utilizzarli.</li>
 	<li>Se l\'utente fa clic su un annuncio Accenture presente su un sito diverso dal nostro, può essere utilizzato un cookie per registrare il sito in cui si trova l\'utente al fine di garantire che i nostri annunci siano presentati in modo efficace e stabilire se vengono visualizzati. A questo scopo Accenture può utilizzare fornitori di servizi come Doubleclick, MediaMind, www.DidIt.com e altri.</li>
 	<li>Siamo partner di ShareThis sul nostro sito web. ShareThis è un widget che consente agli utenti di condividere con altri i contenuti del sito attraverso social media come Facebook e Twitter. ShareThis inserisce sul sito dei cookie che raccolgono informazioni sull\'uso del sito stesso da parte degli utenti e associano questi ultimi ad argomenti di interesse, in base ai contenuti da loro condivisi. Questi dati saranno utilizzati per gli analytics relativi al sito web (creazione di statistiche in merito a ciò che è più popolare e a quante persone condividono un contenuto specifico) e per definire un target pubblicitario su altri siti esterni. ShareThis può condividere i propri dati di analisi con Accenture. Per questi scopi ShareThis non utilizza gli identificatori personali degli utenti (come i nomi e gli indirizzi e-mail) e l\'identificazione avviene solo in modo anonimo. Per maggiori informazioni su ShareThis, i cookie che utilizza e su come rinunciarvi, consultare il sito web ShareThis [<a title=\"Share This Privacy. Questo link apre una nuova finestra.\" href=\"http://www.sharethis.com/privacy\" target=\"_blank\">www.sharethis.com/privacy</a>].</li>
 	<li>Accenture si avvale di società affidabili per raccogliere e ricevere informazioni sugli utenti del nostro sito web e della pubblicità e per fornire annunci mirati su siti di terze parti. Questi soggetti utilizzano solo identificatori anonimi e non hanno modo di associarli a utenti identificabili. Organizzazioni come Quantcast e Retargeter svolgono queste attività per conto di Accenture ed è possibile avere maggiori informazioni a riguardo visitando il loro siti o facendo clic sull\'icona AdChoices negli annunci di Accenture.</li>
 	<li>Collaboriamo anche con alcuni social media come Facebook e Twitter per aggiungere pixel di conversione ad alcune pagine del nostro sito che ci consentono di coinvolgere nuovamente i visitatori. I pixel di conversione sono piccoli codici inseriti in una specifica pagina web e vengono attivati quando l\'utente vi accede, con un conseguente aumento del numero di conversioni. Questi pixel consentono di rivolgere la pubblicità ai visitatori da Facebook e Twitter in modo che continuino la loro esperienza con Accenture.</li>
</ol>
<strong>Uso dei cookie per il marketing e gli analytics</strong> Accenture può utilizzare le informazioni raccolte dai nostri cookie per identificare il comportamento degli utenti e fornire contenuti e offerte in base al loro profilo e per altre finalità descritte di seguito. Si tenga presente che alcune di queste attività potrebbero essere svolte soltanto in alcuni Paesi.

Alcuni dei cookie utilizzati da Accenture non raccolgono informazioni che identificano il visitatore. Ad esempio:
<ul>
 	<li>Cookie di performance (vedere sopra)</li>
 	<li>Cookie di targeting (vedere sopra) in cui l\'utente non è registrato</li>
</ul>
In altri casi possiamo associare a una persona identificabile le informazioni dei cookie, incluse quelle provenienti da cookie inseriti sui siti di terze parti tramite le nostre pubblicità.

</div>
</div>
</div>
</section></div>
</div>","Privacy","","inherit","closed","closed","","224-revision-v1","","","2016-11-24 01:00:59","2016-11-24 00:00:59","","224","http://www.onyxsistemi.it/restyling/224-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("225","1","2016-11-23 00:23:30","2016-11-22 23:23:30","<div id=\"block-general\" class=\"ui-container   row white c-left c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box  \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

Questa pagina fornisce tutte le informazioni necessarie sul modo in cui Onyx Technology protegge i dati personali degli utenti e quali sono i diritti dell\'utente in relazione ai propri dati personali:

&nbsp;

<strong>In che modo Accenture protegge i vostri dati personali</strong>

Accenture protegge i vostri dati personali con le sue \"Binding Corporate Rules\",di seguito \"BCR\", costituite da:
<ul>
 	<li><strong>Data Privacy Policy 90 -</strong> Policy globale sulla privacy dei dati che stabilisce le misure di salvaguardia applicate da Accenture, indipendentemente da dove vengono trattati i vostri dati</li>
 	<li><strong>Procedure per la privacy dei dati -</strong> Modalità di gestione delle richieste di accesso o dei reclami e</li>
 	<li><strong>Accordo Intercompany -</strong> Accordo che rende vincolanti le procedure della Data Privacy Policy 90 e delle Procedure per la privacy dei dati per tutte le entità che fanno parte del gruppo Accenture</li>
</ul>
Tutte queste misure assicurano che in tutta l\'organizzazione Accenture siano in vigore appropriate garanzie di riservatezza dei dati. Le norme BCR rispecchiano gli standard contenuti nelle leggi europee in materia di privacy dei dati e sono state approvate dai garanti europei per la protezione dei dati personali (Area Economica Europea e Svizzera).

L\'esistenza delle BCR significa che tutte le entità del gruppo Accenture che le recepiscono sono chiamate a rispettare le stesse regole interne. Significa anche che i diritti degli utenti rimangono invariati a prescindere dal luogo in cui i dati personali vengono trattati da Accenture (vedere la sezione \"I vostri diritti\", di seguito).

Se desiderate ricevere una copia completa delle nostre BCR, <a href=\"https://www.accenture.com/it-it/privacy-policy#block-contactus\" target=\"_self\">contattateci</a>.

<strong>Data Privacy Policy 90 di Accenture</strong>

La sezione seguente riassume i contenuti della Data Privacy Policy 90 di Accenture. Se desiderate ricevere una copia completa della policy, <a href=\"https://www.accenture.com/it-it/privacy-policy#block-contactus\" target=\"_self\">contattateci</a>.

<a name=\"CookieID1\"></a><a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID1\" target=\"_self\">Quali dati personali raccoglie Accenture?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID2\" target=\"_self\">Accenture condivide con altri i vostri dati personali?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID3\" target=\"_self\">Cosa sono i dati personali sensibili?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID4\" target=\"_self\">Cos\'è la sicurezza dei dati?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID5\" target=\"_self\">Dove saranno trattati i vostri dati personali?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID6\" target=\"_self\">Conservazione dei vostri dati</a><strong>
</strong><a name=\"CookieID2\"></a><a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID7\" target=\"_self\">I vostri diritti</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#CookieID8\" target=\"_self\">Domande e reclami</a>

<strong>Quali dati personali raccoglie Accenture?</strong>
Accenture raccoglie i dati personali di dipendenti, candidati, fornitori, contatti professionali e utenti del sito web.

Cerchiamo sempre di informare in modo adeguato tali soggetti in merito ai dati che saranno raccolti e al modo in cui gli stessi saranno utilizzati. In ogni caso tratteremo quei dati solo se reputeremo giusto e lecito farlo.

<strong>Accenture condivide con altri i vostri dati personali?</strong>
Accenture non vende i dati personali a soggetti terzi. Possiamo trasferire dati personali ai nostri fornitori di servizi e ai consulenti che si trovano in altri paesi. Prima di farlo, adottiamo misure atte a garantire che i dati personali siano adeguatamente protetti, come richiesto dalle leggi in materia e dalle policy interne di Accenture.

Si possono tuttavia verificare altre circostanze in cui è necessario condividere o divulgare i dati personali da voi forniti per uno scopo specifico, ad esempio:
<ul>
 	<li>In occasione di un evento in cui abbiamo la necessità di indicare al servizio di catering le preferenze alimentari oppure quando, partecipando a una manifestazione congiunta, vi informiamo che i vostri dati personali saranno condivisi con i nostri partner. Tuttavia,<a name=\"CookieID3\"></a>anche in questi casi vi informeremo del motivo per cui chiediamo informazioni specifiche e voi sarete assolutamente liberi di fornirle o meno;</li>
 	<li>Potremmo dover divulgare i vostri dati personali a terzi qualora decidessimo di cedere o liquidare una parte della nostra attività o dei nostri asset;</li>
 	<li>Accenture divulgherà i vostri dati personali per motivi di conformità a obblighi di legge ovvero per far rispettare o applicare le nostre Condizioni di utilizzo o per proteggere i diritti, la proprietà o la sicurezza di Accenture, dei suoi clienti o di terzi.</li>
</ul>
<strong>Cosa sono i dati personali sensibili?</strong>
In genere Accenture cerca di non raccogliere dati personali sensibili attraverso questo sito o in altro modo. Nei rari casi in cui cercheremo di farlo, ciò avverrà in conformità<a name=\"CookieID4\"></a>ai requisiti della legge locale sulla tutela della riservatezza dei dati. Decidendo di fornire ad Accenture dati personali sensibili non richiesti, acconsentite al loro uso da parte nostra, nel rispetto della legge applicabile, come spiegato nel presente documento. L\'espressione \"dati personali sensibili\" si riferisce alle varie categorie di dati personali identificate da leggi europee e da altre leggi sulla riservatezza delle informazioni che ne impongono un trattamento speciale e, in alcune circostanze, la necessità di ottenere un esplicito consenso. Queste categorie possono includere i numeri di identificazione personali, le informazioni sui conti finanziari, l\'origine razziale o etnica, le opinioni politiche, religiose, filosofiche o di altro genere, l\'adesione a un sindacato, un\'associazione professionale o commerciale, la salute fisica o mentale, i dati biometrici o genetici, gli orientamenti sessuali o i precedenti penali (incluse informazioni su attività criminali sospette).

<strong>Cos\'è la sicurezza dei dati?</strong>
Accenture adotta misure appropriate per garantire la sicurezza dei dati personali raccolti. Per quanto riguarda l\'uso dei nostri siti web,<a name=\"CookieID5\"></a>va sottolineato che la natura di Internet è tale per cui le informazioni e i dati personali possono essere liberamente presenti su reti che si collegano ai nostri sistemi senza misure di sicurezza, e possono essere accessibili e utilizzabili da persone diverse da quelle cui i dati sono destinati.

Il sito Accenture può, di volta in volta, contenere link da e verso i siti delle reti di partner, inserzionisti e<a name=\"CookieID6\"></a>affiliati. Se si segue un link a uno di questi siti, si prega di notare che questi siti hanno le proprie policy sulla privacy e che Accenture non accetta alcuna responsabilità per tali policy o siti. Si raccomanda di controllare le policy di questi siti prima di inviare dati personali.

<strong>Dove saranno trattati i vostri dati personali?</strong>
<a name=\"CookieID7\"></a>In quanto organizzazione a livello mondiale con sistemi IT globali, Accenture raccoglie dati personali che possono essere indirizzati, conservati o trasferiti a livello internazionale in tutta l\'organizzazione mondiale di Accenture in conformità con le nostre BCR.

<strong>Conservazione dei vostri dati</strong>
Accenture conserverà i vostri dati personali solo per il tempo necessario. Se disponete di un account Accenture, conserveremo i vostri dati finché l\'account rimarrà attivo o per tutto il tempo necessario a fornirvi servizi e fino a quando richiesto in virtù dei nostri obblighi legali e contrattuali a livello mondiale.

<strong>I vostri diritti</strong>
È vostro diritto sapere se Accenture conserva i vostri dati personali e, in caso affermativo, accedere ad essi e richiedere che vengano corretti qualora contengano imprecisioni. In genere Accenture non prende decisioni attraverso mezzi puramente automatici, tuttavia, se ciò accadesse, avete il diritto di opporvi.

Potete <a href=\"https://www.accenture.com/it-it/privacy-policy#block-contactus\" target=\"_self\">contattarci</a> per esercitare i vostri diritti o ricevere una copia delle BCR di Accenture.

Se i vostri dati sono stati originariamente raccolti in Europa (Area Economica Europea (EEA) e in Svizzera) e sono stati trasferiti da un\'entità Accenture in Europa a un\'entità Accenture fuori dell\'Europa, ai sensi delle BCR avete i seguenti ulteriori diritti:
<ul>
 	<li>avanzare reclami per ottenere un rimedio adeguato e, se del caso, ricevere un risarcimento dall\'entità Accenture in Europa che in origine ha ricevuto e trattato i vostri dati personali, in relazione a eventuali danni subiti a causa di una violazione della policy sulla privacy da parte qualsiasi altra entità Accenture a cui i dati personali possono essere stati trasferiti ai sensi delle BCR;</li>
 	<li>presentare una denuncia presso l\'autorità competente per la protezione dei dati e/o adire le vie legali per fare in modo che Accenture rispetti i termini e le condizioni della policy sulla privacy;</li>
 	<li>ricevere una copia delle BCR</li>
</ul>
<strong><a name=\"CookieID8\"></a>Domande o reclami</strong>
Se questo documento non fornisce le risposte che cercate o in caso di dubbi sull\'uso dei vostri dati personali da parte di Accenture, <a href=\"https://www.accenture.com/it-it/privacy-policy#block-contactus\" target=\"_self\">contattateci</a>.

</div>
</div>
<div class=\"col-sm-2\"></div>
</div>
</section></div>
</div>
<div id=\"block-websites\" class=\"ui-container color-container  row periwinkle-blue c-right c-ui-edge\" data-shape=\"edge\" data-shape-color=\"periwinkle-blue\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"block-title iscrisscrossed\">
<h2>SITI WEB</h2>
</div>
<div class=\"ui-content-box  \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

<strong>Questo sito è gestito da Accenture LLP a proprio nome e per conto di ciascuna società Accenture operativa a livello locale.</strong>

<a href=\"https://www.accenture.com/it-it/privacy-policy#ItemID1\">La vostra privacy sui siti web Accenture</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#ItemID2\">Quali informazioni vengono raccolte?</a>
<a href=\"https://www.accenture.com/it-it/privacy-policy#ItemID3\">Come vengono utilizzate le informazioni che raccogliamo dal sito?</a>

<strong><a name=\"ItemID1\"></a>La vostra privacy sui siti web Accenture</strong>
Scopo principale del sito web Accenture è quello di essere una risorsa e uno strumento di business dinamico per aiutarvi ad avere più informazioni su di noi. Vogliamo che vi sentiate sicuri, per questo ci impegniamo a tutelare la vostra privacy quando visitate il nostro sito web.

<strong><a name=\"ItemID2\"></a>Quali informazioni vengono raccolte?</strong>
Accenture raccoglie informazioni sui propri siti web in due modi: (1) direttamente (ad esempio, quando fornite informazioni per iscrivervi a una newsletter o registrarvi su un forum) e (2) indirettamente (ad esempio, attraverso la tecnologia utilizzata sul sito).

Possiamo raccogliere ed elaborare le seguenti informazioni che vi riguardano:
<ul>
 	<li>Informazioni fornite compilando moduli sul nostro sito. Ciò comprende la registrazione per utilizzare il sito, l\'abbonamento a servizi, newsletter e avvisi, la registrazione a una conferenza o la richiesta di un white paper o di maggiori informazioni. Pagine che raccolgono questo tipo di informazioni possono fornire ulteriori indicazioni sul motivo per cui i vostri dati sono necessari e su come verranno utilizzati. Sarete voi a decidere se fornire i dati o meno.</li>
 	<li>Se ci contattate, potremmo conservare una registrazione di tale corrispondenza.</li>
 	<li>Potremmo chiedervi di compilare dei sondaggi che utilizzeremo per scopi di ricerca, ma non siete obbligati a rispondere.</li>
 	<li>Ogni post, commento o altro contenuto che viene caricato o pubblicato su un sito web Accenture.</li>
 	<li>Il nostro sito raccoglie informazioni sul vostro computer, inclusi (ove disponibili) l\'indirizzo IP, il sistema operativo e il tipo di browser, che servono per la gestione del sistema, per filtrare il traffico, per cercare i domini degli utenti e per riferire statistiche.</li>
 	<li>I dettagli delle vostre visite sul nostro sito, le pagine visualizzate e le risorse a cui avete accesso o che scaricate, inclusi, tra l\'altro, dati sul traffico, dati sulla posizione, registri web e altri dati di comunicazione. Consultare la sezione sottostante sui <a href=\"https://www.accenture.com/it-it/privacy-policy#CookieIDB\">Cookie</a> per maggiori informazioni.</li>
</ul>
Quando le informazioni si riferiscono a voi o vi identificano, Accenture le tratta come \"dati personali\".

<strong><a name=\"ItemID3\"></a>Come vengono utilizzate le informazioni che raccogliamo dal sito?</strong>
Accenture utilizza i vostri dati personali per fornirvi le informazioni richieste, elaborare candidature online e per altri scopi che saranno descritti nel momento in cui verranno raccolti i dati o che diverranno evidenti per voi. Ad esempio per:
<ul>
 	<li>Soddisfare le vostre richieste di white paper, articoli, newsletter o altri contenuti.</li>
 	<li>Elaborare sondaggi o questionari di ricerca.</li>
 	<li>Personalizzare la vostra esperienza sul nostro sito.</li>
 	<li>Contattarvi per scopi di marketing dopo che avrete dato il vostro consenso.</li>
</ul>
Analizziamo le informazioni IP e relative al browser per stabilire cosa è più efficace sul nostro sito, per identificare modi per migliorarlo e renderlo più efficiente. Consultare la sezione sottostante su <a href=\"https://www.accenture.com/it-it/privacy-policy#CookieIDB\">Cookie</a> per maggiori informazioni.

</div>
</div>
<div class=\"col-sm-2\"></div>
</div>
</section></div>
</div>
<div id=\"block-cookie\" class=\"ui-container   row white c-right c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"block-title iscrisscrossed\">
<h2>COOKIE</h2>
</div>
<div class=\"ui-content-box  \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

<strong>Cosa sono i cookie?</strong>
I cookie sono file di testo che contengono piccole quantità di informazioni scaricate sul vostro computer o dispositivo mobile quando visitate un sito web. I cookie vengono poi rimandati al sito di origine ad ogni visita successiva, o a un altro sito web che li riconosce. I cookie sono utili perché consentono a un sito web di riconoscere il dispositivo dell\'utente. Potete trovare maggiori informazioni sui cookie ai seguenti indirizzi: <a title=\"All About Cookies. Questo link apre una nuova finestra.\" href=\"http://www.allaboutcookies.org/\" target=\"_blank\">www.allaboutcookies.org</a> e <a title=\"Your Online Choices. Questo link apre una nuova finestra.\" href=\"http://www.youronlinechoices.eu/\" target=\"_blank\">www.youronlinechoices.eu</a>. For a video about cookies visit www.google.co.uk/goodtoknow/data-on-the-web/cookies.

I cookie svolgono molti compiti diversi, ad esempio vi fanno spostare tra le pagine in modo efficiente, ricordando le vostre preferenze, e in generale migliorano la user experience. Possono anche contribuire a rendere più rilevanti per voi e i vostri interessi specifici i messaggi pubblicitari e gli altri contenuti visualizzati online. Possono essere impostati dal sito web che state visitando (cookie proprietari) o da un altro soggetto, ad esempio una rete pubblicitaria (cookie di terze parti). I cookie utilizzati in questo sito sono stati classificati sulla base delle quattro categorie presenti nella <a title=\"Click here to download the full article. ICC UK Cookie Guide. Questo link apre una nuova finestra.\" href=\"https://www.accenture.com/t00010101T000000__w__/it-it/_acnmedia/Accenture/Conversion-Assets/DotCom/Documents/Global/PDF/Technology_8/Accenture-ICC-UK-Cookie-Guide.pdf#zoom=50\" target=\"_blank\">ICC UK Cookie guide</a>. Di seguito è riportato un elenco di tutti i cookie utilizzati in questo sito divisi per categorie. All\'interno delle quattro categorie, i cookie possono essere associati alla sessione o essere persistenti. I cookie di sessione sono temporanei e una volta che si chiude la finestra del browser vengono cancellati dal dispositivo. I cookie persistenti rimangono sul dispositivo per un periodo più lungo e vengono utilizzati dal sito web per riconoscere il dispositivo quando si ritorna su un sito.

<strong>Quale altra tecnologia di tracking utilizza Accenture?</strong>
Accenture può utilizzare anche web beacon (compresi i pixel di conversione) o altre tecnologie per finalità simili e possiamo includerle sui nostri siti, nei messaggi e-mail di marketing o nelle nostre newsletter per sapere se i messaggi sono stati aperti e se i link sono stati cliccati. I web beacon non installano informazioni sul dispositivo, ma possono funzionare in combinazione con i cookie per monitorare l\'attività sui siti web e le informazioni sui cookie fornite di seguito si applicano anche ai web beacon e a tecnologie simili. I pixel di conversione sono piccoli codici inseriti in una specifica pagina web e vengono attivati quando l\'utente vi accede, con un conseguente aumento del numero di conversioni.

<strong>Cosa devo fare se non voglio i cookie?</strong>
Con l\'utilizzo del nostro sito web l\'utente accetta la presenza dei cookie e di altre tecnologie simili sul proprio dispositivo, come spiegato di seguito. Se si desidera rimuovere i cookie esistenti dal dispositivo, è possibile farlo utilizzando le opzioni del browser. Se in futuro si desidera bloccare i cookie in modo che non vengano installati sul dispositivo, è possibile farlo modificando le impostazioni del browser. Quando si esaminano le impostazioni o le opzioni del browser, è possibile identificare i cookie di Accenture per il fatto che includono \".accenture\" nel nome. Per maggiori informazioni sulla gestione dei cookie, vedere <a title=\"All About Cookies. Questo link apre una nuova finestra.\" href=\"http://www.allaboutcookies.org/manage-cookies/\" target=\"_blank\">www.allaboutcookies.org/manage-cookies</a>, Le attuali funzionalità \"Do Not Track\" non vengono riconosciute dal nostro sito web.

Si prega di tenere presente che la cancellazione e il blocco dei cookie avrà un impatto sulla user experience, in quanto alcune parti del sito potrebbero non funzionare più. A meno non abbiate impostato il browser per bloccare i cookie, il nostro sistema li inserirà non appena visiterete il nostro sito web o farete clic su un collegamento in un messaggio mirato che vi abbiamo inviato, anche se in precedenza i nostri cookie sono stati eliminati.

Non è possibile rimuovere o bloccare i web beacon o le URL personalizzate, in quanto fanno parte del contenuto di pagine web e e-mail, e non di informazioni installate sul dispositivo. Tuttavia, poiché interagiscono con i cookie, la disattivazione di questi ultimi impedirà anche ai web beacon di rintracciare l\'attività degli utenti sul nostro sito. Il web beacon continuerà a registrare una visita anonima, ma le informazioni univoche sull\'utente non saranno memorizzate.

Quali sono i tipi di cookie e quali possono essere utilizzati su questo sito?

<strong>Cookie strettamente necessari</strong> - Questi cookie sono essenziali per spostarsi nel sito e utilizzarne le funzioni, come ad esempio accedere ad aree protette del sito stesso. Senza questi cookie, i servizi richiesti non possono essere forniti.

Accenture classifica i seguenti cookie come strettamente necessari:
<ol>
 	<li>Cookie di visitatori registrati - Identificatore univoco assegnato a ciascun utente registrato, utilizzato per riconoscerne la visita e il ritorno sul sito. (vedere anche i cookie tecnici, più avanti).</li>
</ol>
<strong>Performance Cookie</strong> - Cookie che raccolgono informazioni su come gli utenti utilizzano un sito web, ad esempio, quali pagine visitano più frequentemente, e se ricevono messaggi di errore da pagine web. Questi cookie non raccolgono informazioni che identificano il visitatore. Tutte le informazioni raccolte da questi cookie sono anonime e vengono utilizzate solo per migliorare il funzionamento del sito web.

Accenture classifica i seguenti cookie come cookie di performance:
<ol>
 	<li>Referrer URL (pagina interna) – Utilizzato per memorizzare l\'URL della pagina precedente visitata. Ci permette di tenere traccia di come i visitatori navigano nel nostro sito.</li>
 	<li>Referrer URL (pagina esterna) – Utilizzato anche per rilevare se si fa clic sui link presenti nelle pagine Accenture sui social media). Utilizzati per memorizzare l\'URL che conduce un visitatore al nostro sito web in modo da permetterci di capire quali URL rimandano i visitatori al sito Accenture.</li>
 	<li>Cronologia URL – Consente di memorizzare la pagina visitata da un utente, prima che l\'utente invii un modulo. Viene utilizzata anche per mostrare gli articoli visualizzati di recente a ciascun visitatore.</li>
 	<li>Cookie per visitatori non registrati – Identificatore univoco assegnato ad ogni visitatore per analizzare il modo in cui gli utenti non registrati utilizzano il sito web Accenture.</li>
 	<li>Cookie di gestione delle sessioni – Permettono di seguire le azioni di un utente durante una sessione del browser. Una sessione inizia quando l\'utente apre la finestra del browser e finisce quando la finestra del browser viene chiusa. I cookie di gestione delle sessioni vengono creati temporaneamente. Una volta chiuso il browser, vengono eliminati.</li>
</ol>
<strong>Cookie tecnici</strong> – Permettono a un sito web di ricordare le scelte fatte dall\'utente (il nome utente, la lingua o la regione in cui si trova) e di fornire funzionalità avanzate, più personali. Ad esempio un sito web può essere in grado di fornire informazioni o notizie locali memorizzando in un cookie la regione geografica in cui si trova l\'utente. Questi cookie possono essere utilizzati anche per ricordare le modifiche apportate alle dimensioni del testo, il carattere e le altre parti delle pagine web che è possibile personalizzare.

Possono essere utilizzati anche per fornire servizi richiesti dall\'utente, come la possibilità di guardare un video o di inserire commenti su un blog. Questi cookie non sono in grado tenere traccia dell\'attività di navigazione su altri siti web. Non raccolgono informazioni su di voi che potrebbero essere utilizzate per la pubblicità o per registrare dove siete stati su Internet al di fuori del sito Accenture.

Accenture classifica i seguenti cookie come cookie tecnici:
<ol>
 	<li>Pagine visualizzate di recente – Le pagine visitate dall\'utente sul nostro sito vengono memorizzate e poi visualizzate sulla parte destra dello schermo per una facile consultazione.</li>
 	<li>Cronologia delle ricerche – Le ricerche condotte dall\'utente sul nostro sito vengono memorizzate e poi visualizzate sulla parte destra dello schermo per una facile consultazione.</li>
 	<li>Cookie dei visitatori registrati – Identificatore univoco assegnato a ogni utente registrato sul nostro sito, utilizzato per fornire contenuti e offerte il base al profilo. Utilizzati anche per scopi di analisi e marketing (vedere anche: cookie strettamente necessari, sopra, e uso dei cookie di marketing e analisi, di seguito).</li>
</ol>
<strong>Cookie di targeting</strong> – Questi cookie vengono utilizzati per: (1) fornire messaggi pubblicitari considerati rilevanti per l\'utente, (2) limitare il numero di volte in cui l\'utente vede una pubblicità, (3) misurare l\'efficacia della campagna pubblicitaria, e (4) comprendere il comportamento degli utenti dopo la visualizzazione di un annuncio pubblicitario. In genere questi cookie vengono installati dalle reti di pubblicità con l\'autorizzazione del gestore del sito. Registrano la visita dell\'utente a un sito web e condividono questa informazione con altre organizzazioni, come gli inserzionisti. Molto spesso i cookie saranno collegati alla funzionalità del sito web fornito dall\'altra organizzazione.

Accenture non ospita sul proprio sito pubblicità di terzi, ma questi cookie possono essere presenti su siti esterni e altri soggetti possono utilizzarli sul nostro sito nel modo seguente:
<ol>
 	<li>Siti di social media di terze parti possono registrare le informazioni sull\'utente, ad esempio, quando si fa clic sul pulsante \"Aggiungi\" oppure \"Mi piace\" per un sito di social media, durante la navigazione sul sito di Accenture. Noi non controlliamo questi siti, né le loro attività. L\'utente ha la possibilità di trovare informazioni in proposito sui siti in questione. Si consiglia di leggere i termini e le condizioni di utilizzo e la policy sulla privacy di tali siti prima di utilizzarli.</li>
 	<li>Se l\'utente fa clic su un annuncio Accenture presente su un sito diverso dal nostro, può essere utilizzato un cookie per registrare il sito in cui si trova l\'utente al fine di garantire che i nostri annunci siano presentati in modo efficace e stabilire se vengono visualizzati. A questo scopo Accenture può utilizzare fornitori di servizi come Doubleclick, MediaMind, www.DidIt.com e altri.</li>
 	<li>Siamo partner di ShareThis sul nostro sito web. ShareThis è un widget che consente agli utenti di condividere con altri i contenuti del sito attraverso social media come Facebook e Twitter. ShareThis inserisce sul sito dei cookie che raccolgono informazioni sull\'uso del sito stesso da parte degli utenti e associano questi ultimi ad argomenti di interesse, in base ai contenuti da loro condivisi. Questi dati saranno utilizzati per gli analytics relativi al sito web (creazione di statistiche in merito a ciò che è più popolare e a quante persone condividono un contenuto specifico) e per definire un target pubblicitario su altri siti esterni. ShareThis può condividere i propri dati di analisi con Accenture. Per questi scopi ShareThis non utilizza gli identificatori personali degli utenti (come i nomi e gli indirizzi e-mail) e l\'identificazione avviene solo in modo anonimo. Per maggiori informazioni su ShareThis, i cookie che utilizza e su come rinunciarvi, consultare il sito web ShareThis [<a title=\"Share This Privacy. Questo link apre una nuova finestra.\" href=\"http://www.sharethis.com/privacy\" target=\"_blank\">www.sharethis.com/privacy</a>].</li>
 	<li>Accenture si avvale di società affidabili per raccogliere e ricevere informazioni sugli utenti del nostro sito web e della pubblicità e per fornire annunci mirati su siti di terze parti. Questi soggetti utilizzano solo identificatori anonimi e non hanno modo di associarli a utenti identificabili. Organizzazioni come Quantcast e Retargeter svolgono queste attività per conto di Accenture ed è possibile avere maggiori informazioni a riguardo visitando il loro siti o facendo clic sull\'icona AdChoices negli annunci di Accenture.</li>
 	<li>Collaboriamo anche con alcuni social media come Facebook e Twitter per aggiungere pixel di conversione ad alcune pagine del nostro sito che ci consentono di coinvolgere nuovamente i visitatori. I pixel di conversione sono piccoli codici inseriti in una specifica pagina web e vengono attivati quando l\'utente vi accede, con un conseguente aumento del numero di conversioni. Questi pixel consentono di rivolgere la pubblicità ai visitatori da Facebook e Twitter in modo che continuino la loro esperienza con Accenture.</li>
</ol>
<strong>Uso dei cookie per il marketing e gli analytics</strong> Accenture può utilizzare le informazioni raccolte dai nostri cookie per identificare il comportamento degli utenti e fornire contenuti e offerte in base al loro profilo e per altre finalità descritte di seguito. Si tenga presente che alcune di queste attività potrebbero essere svolte soltanto in alcuni Paesi.

Alcuni dei cookie utilizzati da Accenture non raccolgono informazioni che identificano il visitatore. Ad esempio:
<ul>
 	<li>Cookie di performance (vedere sopra)</li>
 	<li>Cookie di targeting (vedere sopra) in cui l\'utente non è registrato</li>
</ul>
In altri casi possiamo associare a una persona identificabile le informazioni dei cookie, incluse quelle provenienti da cookie inseriti sui siti di terze parti tramite le nostre pubblicità. Ad esempio:
<ul>
 	<li>Se un utente è registrato (vedere Cookie per gli utenti registrati, sopra).</li>
 	<li>Se inviamo un\'e-mail mirata che comprende web beacon, cookie o tecnologie simili, sapremo se l\'utente apre, legge o elimina il messaggio.</li>
 	<li>Quando l\'utente fa clic su un link presente in una e-mail di marketing inviata da Accenture, utilizzeremo un cookie per registrare le pagine visualizzate e quali contenuti vengono scaricati dai nostri siti, anche se l\'utente non è registrato sul nostro sito.</li>
</ul>
<strong>Nota</strong> – Per alcuni cookie Accenture utilizza Omniture (parte di Adobe) per ospitare prodotti e servizi di ottimizzazione in grado di fornire analytics e intelligence in merito al nostro sito web. Per maggiori informazioni su come Omniture raccoglie e utilizza le informazioni per conto di Accenture, consultare l\'informativa sulla privacy di Omniture relativa a prodotti e servizi all\'indirizzo <a title=\"Omniture site. Questo link apre una nuova finestra.\" href=\"http://www.omniture.com/privacy/product\" target=\"_blank\">www.omniture.com/privacy/product</a>.

<strong>Tecnologie di tracciamento senza cookie</strong> – Accenture impiega anche tecnologie che svolgono funzioni simili ai cookie, ma che possono non rispondere alle impostazioni del browser destinate all\'uso con i cookie. Si tratta di URL personalizzate (PURL), web beacon e altre tecnologie analoghe.
<div class=\"block-title iscrisscrossed\">
<h2>CONTATTI</h2>
</div>
<div class=\"ui-content-box  \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

<strong>Domande/diritti/reclami in merito alla privacy dei dati</strong>

<a title=\"Domande/diritti/reclami. Questo link apre una nuova finestra.\" href=\"mailto:DataPrivacy@accenture.com\">Scriveteci una mail</a> se:
<ul>
 	<li>avete domande di carattere generale sul modo in cui Accenture protegge la riservatezza dei dati personali</li>
 	<li>desiderate esercitare i vostri diritti in materia di privacy dei dati (ad esempio ricevere una copia dei vostri dati personali in nostro possesso)</li>
 	<li>desiderate ricevere una copia della versione integrale della nostra policy sulla privacy o delle BCR</li>
 	<li>desiderate sporgere un reclamo in merito all\'uso dei vostri dati personali da parte di Accenture</li>
</ul>
<strong>Autorizzazioni relative a sito web/marketing e domande di carattere generale su Accenture</strong>

Utilizzate il form <a href=\"https://www.accenture.com/us-en/Home/BucketContent/CommonPages/contact-us.aspx\" target=\"_self\">Contattaci</a> se desiderate:
<ul>
 	<li>interrompere l\'invio di comunicazioni di marketing da parte nostra</li>
 	<li>far eliminare i vostri dati personali dal database CRM (Customer Relationship Management) Accenture oppure</li>
 	<li>sottoporre domande generiche relative ad Accenture.</li>
</ul>
Visualizzate un <a href=\"https://www.accenture.com/us-en/Home/BucketContent/Company-Content2/legal-countries-incorporation.aspx\" target=\"_self\">elenco dei paesi</a> in cui Accenture è presente.

</div>
</div>
</div>
</section></div>
</div>
</div>
</div>
</section></div>
</div>","Privacy","","inherit","closed","closed","","224-revision-v1","","","2016-11-23 00:23:30","2016-11-22 23:23:30","","224","http://www.onyxsistemi.it/restyling/224-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("226","1","2016-11-24 01:00:23","2016-11-24 00:00:23","<div id=\"block-general\" class=\"ui-container row white c-left c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

&nbsp;

Onyx Technology intende prendere tutte le misure che garantiscano la riservatezza dei dati degli utenti. Tali misure rispecchiano gli standard contenuti nelle leggi europee in materia di privacy dei dati e sono state approvate dai garanti europei per la protezione dei dati personali (Area Economica Europea e Svizzera).

Ony Technology raccoglie i dati personali di dipendenti, candidati, fornitori, contatti professionali e utenti del sito web.

Cerchiamo sempre di informare in modo adeguato tali soggetti in merito ai dati che saranno raccolti e al modo in cui gli stessi saranno utilizzati. In ogni caso tratteremo quei dati solo se reputeremo giusto e lecito farlo. Non vendiamo i dati personali a soggetti terzi. Possiamo trasferire dati personali ai nostri fornitori di servizi e ai consulenti che si trovano in altri paesi. Prima di farlo, adottiamo misure atte a garantire che i dati personali siano adeguatamente protetti, come richiesto dalle leggi in materia e dalle policy interne.

Si possono tuttavia verificare altre circostanze in cui è necessario condividere o divulgare i dati personali da voi forniti per uno scopo specifico.

Decidendo di fornire spontaneamente ad Onyx Technology dati personali sensibili non richiesti, acconsentite al loro uso da parte nostra, nel rispetto della legge applicabile, come spiegato nel presente documento. L\'espressione \"dati personali sensibili\" si riferisce alle varie categorie di dati personali identificate da leggi europee e da altre leggi sulla riservatezza delle informazioni che ne impongono un trattamento speciale e, in alcune circostanze, la necessità di ottenere un esplicito consenso. Queste categorie possono includere i numeri di identificazione personali, le informazioni sui conti finanziari, l\'origine razziale o etnica, le opinioni politiche, religiose, filosofiche o di altro genere, l\'adesione a un sindacato, un\'associazione professionale o commerciale, la salute fisica o mentale, i dati biometrici o genetici, gli orientamenti sessuali o i precedenti penali (incluse informazioni su attività criminali sospette).

Onyx Technology adotta misure appropriate per garantire la sicurezza dei dati personali raccolti. Per quanto riguarda l\'uso dei nostri siti web, va sottolineato che la natura di Internet è tale per cui le informazioni e i dati personali possono essere liberamente presenti su reti che si collegano ai nostri sistemi senza misure di sicurezza, e possono essere accessibili e utilizzabili da persone diverse da quelle cui i dati sono destinati.

Il sito di Onyx Technology può, di volta in volta, contenere link da e verso i siti delle reti di partner, inserzionisti e<a name=\"CookieID6\"></a>affiliati. Se si segue un link a uno di questi siti, si prega di notare che questi siti hanno le proprie policy sulla privacy e che non accettiamo alcuna responsabilità per tali policy o siti. Si raccomanda di controllare le policy di questi siti prima di inviare dati personali.

Conserveremo i vostri dati personali solo per il tempo necessario. È vostro diritto sapere se conserviamo i vostri dati personali e, in caso affermativo, accedere ad essi e richiedere che vengano corretti qualora contengano imprecisioni. Il miglior modo di farlo è accedere alla nostra pagina dei Contatti.

Scopo principale del sito web è quello di essere una risorsa e uno strumento di business dinamico per aiutarvi ad avere più informazioni su di noi. Vogliamo che vi sentiate sicuri, per questo ci impegniamo a tutelare la vostra privacy quando visitate il nostro sito web.

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-websites\" class=\"ui-container color-container row periwinkle-blue c-right c-ui-edge\" data-shape=\"edge\" data-shape-color=\"periwinkle-blue\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-8\">
<div class=\"component richtext\">

Onyx Technology raccoglie informazioni sui propri siti web in due modi: (1) direttamente (ad esempio, quando fornite informazioni per iscrivervi a una newsletter o registrarvi su un forum) e (2) indirettamente (ad esempio, attraverso la tecnologia utilizzata sul sito).

Possiamo raccogliere ed elaborare le seguenti informazioni che vi riguardano:
<ul>
 	<li>Informazioni fornite compilando moduli sul nostro sito.</li>
 	<li>Se ci contattate, potremmo conservare una registrazione di tale corrispondenza.</li>
 	<li>Potremmo chiedervi di compilare dei sondaggi che utilizzeremo per scopi di ricerca, ma non siete obbligati a rispondere.</li>
 	<li>Ogni post, commento o altro contenuto che viene caricato o pubblicato.</li>
 	<li>Il nostro sito raccoglie informazioni sul vostro computer, inclusi (ove disponibili) l\'indirizzo IP, il sistema operativo e il tipo di browser, che servono per la gestione del sistema, per filtrare il traffico, per cercare i domini degli utenti e per riferire statistiche.</li>
 	<li>I dettagli delle vostre visite sul nostro sito, le pagine visualizzate e le risorse a cui avete accesso o che scaricate, inclusi, tra l\'altro, dati sul traffico, dati sulla posizione, registri web e altri dati di comunicazione.</li>
</ul>
Quando le informazioni si riferiscono a voi o vi identificano, le trattiamo come \"dati personali\".

Utilizziamo i vostri dati personali per fornirvi le informazioni richieste, elaborare candidature online e per altri scopi che saranno descritti nel momento in cui verranno raccolti i dati o che diverranno evidenti per voi. Ad esempio per:
<ul>
 	<li>Soddisfare le vostre richieste di contenuti.</li>
 	<li>Personalizzare la vostra esperienza sul nostro sito.</li>
 	<li>Contattarvi per scopi di marketing dopo che avrete dato il vostro consenso.</li>
</ul>
&nbsp;

COOKIE

</div>
</div>
</div>
</section></div>
</div>
<div id=\"block-cookie\" class=\"ui-container row white c-right c-ui-delta\" data-shape=\"delta\" data-shape-color=\"white\" data-show-top-line=\"False\" data-scroll-speed=\"1\" data-background-align=\"\" data-background-cover=\"False\" data-background-playerid=\"\" data-background-mediaid=\"\" data-background-playerform=\"\" data-background-autoplay=\"False\" data-background-autoloop=\"False\" data-media-gallery-block=\"False\">
<div class=\"block-title iscrisscrossed\"></div>
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"><strong>Cosa sono i cookie?</strong></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

I cookie sono file di testo che contengono piccole quantità di informazioni scaricate sul vostro computer o dispositivo mobile quando visitate un sito web. I cookie vengono poi rimandati al sito di origine ad ogni visita successiva, o a un altro sito web che li riconosce. I cookie sono utili perché consentono a un sito web di riconoscere il dispositivo dell\'utente. Potete trovare maggiori informazioni sui cookie ai seguenti indirizzi: <a title=\"All About Cookies. Questo link apre una nuova finestra.\" href=\"http://www.allaboutcookies.org/\" target=\"_blank\">www.allaboutcookies.org</a> e <a title=\"Your Online Choices. Questo link apre una nuova finestra.\" href=\"http://www.youronlinechoices.eu/\" target=\"_blank\">www.youronlinechoices.eu</a>. For a video about cookies visit www.google.co.uk/goodtoknow/data-on-the-web/cookies.

I cookie svolgono molti compiti diversi, ad esempio vi fanno spostare tra le pagine in modo efficiente, ricordando le vostre preferenze, e in generale migliorano la user experience. Possono anche contribuire a rendere più rilevanti per voi e i vostri interessi specifici i messaggi pubblicitari e gli altri contenuti visualizzati online. Possono essere impostati dal sito web che state visitando (cookie proprietari) o da un altro soggetto, ad esempio una rete pubblicitaria (cookie di terze parti). I cookie utilizzati in questo sito sono stati classificati sulla base delle quattro categorie presenti nella <a title=\"Click here to download the full article. ICC UK Cookie Guide. Questo link apre una nuova finestra.\" href=\"https://www.accenture.com/t00010101T000000__w__/it-it/_acnmedia/Accenture/Conversion-Assets/DotCom/Documents/Global/PDF/Technology_8/Accenture-ICC-UK-Cookie-Guide.pdf#zoom=50\" target=\"_blank\">ICC UK Cookie guide</a>. Di seguito è riportato un elenco di tutti i cookie utilizzati in questo sito divisi per categorie. All\'interno delle quattro categorie, i cookie possono essere associati alla sessione o essere persistenti. I cookie di sessione sono temporanei e una volta che si chiude la finestra del browser vengono cancellati dal dispositivo. I cookie persistenti rimangono sul dispositivo per un periodo più lungo e vengono utilizzati dal sito web per riconoscere il dispositivo quando si ritorna su un sito.

<strong>Cosa devo fare se non voglio i cookie?</strong>
Con l\'utilizzo del nostro sito web l\'utente accetta la presenza dei cookie e di altre tecnologie simili sul proprio dispositivo, come spiegato di seguito. Se si desidera rimuovere i cookie esistenti dal dispositivo, è possibile farlo utilizzando le opzioni del browser. Se in futuro si desidera bloccare i cookie in modo che non vengano installati sul dispositivo, è possibile farlo modificando le impostazioni del browser.

Si prega di tenere presente che la cancellazione e il blocco dei cookie avrà un impatto sulla user experience, in quanto alcune parti del sito potrebbero non funzionare più. A meno non abbiate impostato il browser per bloccare i cookie, il nostro sistema li inserirà non appena visiterete il nostro sito web o farete clic su un collegamento in un messaggio mirato che vi abbiamo inviato, anche se in precedenza i nostri cookie sono stati eliminati.

Quali sono i tipi di cookie e quali possono essere utilizzati su questo sito?

<strong>Cookie strettamente necessari</strong> - Questi cookie sono essenziali per spostarsi nel sito e utilizzarne le funzioni, come ad esempio accedere ad aree protette del sito stesso. Senza questi cookie, i servizi richiesti non possono essere forniti.

Cookie di visitatori registrati - Identificatore univoco assegnato a ciascun utente registrato, utilizzato per riconoscerne la visita e il ritorno sul sito. (vedere anche i cookie tecnici, più avanti).

<strong>Performance Cookie</strong> - Cookie che raccolgono informazioni su come gli utenti utilizzano un sito web, ad esempio, quali pagine visitano più frequentemente, e se ricevono messaggi di errore da pagine web. Questi cookie non raccolgono informazioni che identificano il visitatore. Tutte le informazioni raccolte da questi cookie sono anonime e vengono utilizzate solo per migliorare il funzionamento del sito web.

<strong>Cookie tecnici</strong> – Permettono a un sito web di ricordare le scelte fatte dall\'utente (il nome utente, la lingua o la regione in cui si trova) e di fornire funzionalità avanzate, più personali. Ad esempio un sito web può essere in grado di fornire informazioni o notizie locali memorizzando in un cookie la regione geografica in cui si trova l\'utente. Questi cookie possono essere utilizzati anche per ricordare le modifiche apportate alle dimensioni del testo, il carattere e le altre parti delle pagine web che è possibile personalizzare.

Possono essere utilizzati anche per fornire servizi richiesti dall\'utente, come la possibilità di guardare un video o di inserire commenti su un blog. Questi cookie non sono in grado tenere traccia dell\'attività di navigazione su altri siti web. Non raccolgono informazioni su di voi che potrebbero essere utilizzate per la pubblicità o per registrare dove siete stati su Internet al di fuori del sito Accenture.

<strong>Cookie di targeting</strong> – Questi cookie vengono utilizzati per: (1) fornire messaggi pubblicitari considerati rilevanti per l\'utente, (2) limitare il numero di volte in cui l\'utente vede una pubblicità, (3) misurare l\'efficacia della campagna pubblicitaria, e (4) comprendere il comportamento degli utenti dopo la visualizzazione di un annuncio pubblicitario. In genere questi cookie vengono installati dalle reti di pubblicità con l\'autorizzazione del gestore del sito. Registrano la visita dell\'utente a un sito web e condividono questa informazione con altre organizzazioni, come gli inserzionisti. Molto spesso i cookie saranno collegati alla funzionalità del sito web fornito dall\'altra organizzazione.

Onyx Technology non ospita sul proprio sito pubblicità di terzi, ma questi cookie possono essere presenti su siti esterni e altri soggetti possono utilizzarli sul nostro sito.
<ol>
 	<li>Siti di social media di terze parti possono registrare le informazioni sull\'utente, ad esempio, quando si fa clic sul pulsante \"Aggiungi\" oppure \"Mi piace\" per un sito di social media, durante la navigazione sul sito di Accenture. Noi non controlliamo questi siti, né le loro attività. L\'utente ha la possibilità di trovare informazioni in proposito sui siti in questione. Si consiglia di leggere i termini e le condizioni di utilizzo e la policy sulla privacy di tali siti prima di utilizzarli.</li>
 	<li>Se l\'utente fa clic su un annuncio Accenture presente su un sito diverso dal nostro, può essere utilizzato un cookie per registrare il sito in cui si trova l\'utente al fine di garantire che i nostri annunci siano presentati in modo efficace e stabilire se vengono visualizzati. A questo scopo Accenture può utilizzare fornitori di servizi come Doubleclick, MediaMind, www.DidIt.com e altri.</li>
 	<li>Siamo partner di ShareThis sul nostro sito web. ShareThis è un widget che consente agli utenti di condividere con altri i contenuti del sito attraverso social media come Facebook e Twitter. ShareThis inserisce sul sito dei cookie che raccolgono informazioni sull\'uso del sito stesso da parte degli utenti e associano questi ultimi ad argomenti di interesse, in base ai contenuti da loro condivisi. Questi dati saranno utilizzati per gli analytics relativi al sito web (creazione di statistiche in merito a ciò che è più popolare e a quante persone condividono un contenuto specifico) e per definire un target pubblicitario su altri siti esterni. ShareThis può condividere i propri dati di analisi con Accenture. Per questi scopi ShareThis non utilizza gli identificatori personali degli utenti (come i nomi e gli indirizzi e-mail) e l\'identificazione avviene solo in modo anonimo. Per maggiori informazioni su ShareThis, i cookie che utilizza e su come rinunciarvi, consultare il sito web ShareThis [<a title=\"Share This Privacy. Questo link apre una nuova finestra.\" href=\"http://www.sharethis.com/privacy\" target=\"_blank\">www.sharethis.com/privacy</a>].</li>
 	<li>Accenture si avvale di società affidabili per raccogliere e ricevere informazioni sugli utenti del nostro sito web e della pubblicità e per fornire annunci mirati su siti di terze parti. Questi soggetti utilizzano solo identificatori anonimi e non hanno modo di associarli a utenti identificabili. Organizzazioni come Quantcast e Retargeter svolgono queste attività per conto di Accenture ed è possibile avere maggiori informazioni a riguardo visitando il loro siti o facendo clic sull\'icona AdChoices negli annunci di Accenture.</li>
 	<li>Collaboriamo anche con alcuni social media come Facebook e Twitter per aggiungere pixel di conversione ad alcune pagine del nostro sito che ci consentono di coinvolgere nuovamente i visitatori. I pixel di conversione sono piccoli codici inseriti in una specifica pagina web e vengono attivati quando l\'utente vi accede, con un conseguente aumento del numero di conversioni. Questi pixel consentono di rivolgere la pubblicità ai visitatori da Facebook e Twitter in modo che continuino la loro esperienza con Accenture.</li>
</ol>
<strong>Uso dei cookie per il marketing e gli analytics</strong> Accenture può utilizzare le informazioni raccolte dai nostri cookie per identificare il comportamento degli utenti e fornire contenuti e offerte in base al loro profilo e per altre finalità descritte di seguito. Si tenga presente che alcune di queste attività potrebbero essere svolte soltanto in alcuni Paesi.

Alcuni dei cookie utilizzati da Accenture non raccolgono informazioni che identificano il visitatore. Ad esempio:
<ul>
 	<li>Cookie di performance (vedere sopra)</li>
 	<li>Cookie di targeting (vedere sopra) in cui l\'utente non è registrato</li>
</ul>
In altri casi possiamo associare a una persona identificabile le informazioni dei cookie, incluse quelle provenienti da cookie inseriti sui siti di terze parti tramite le nostre pubblicità. Ad esempio:
<ul>
 	<li>Se un utente è registrato (vedere Cookie per gli utenti registrati, sopra).</li>
 	<li>Se inviamo un\'e-mail mirata che comprende web beacon, cookie o tecnologie simili, sapremo se l\'utente apre, legge o elimina il messaggio.</li>
 	<li>Quando l\'utente fa clic su un link presente in una e-mail di marketing inviata da Accenture, utilizzeremo un cookie per registrare le pagine visualizzate e quali contenuti vengono scaricati dai nostri siti, anche se l\'utente non è registrato sul nostro sito.</li>
</ul>
<strong>Nota</strong> – Per alcuni cookie Accenture utilizza Omniture (parte di Adobe) per ospitare prodotti e servizi di ottimizzazione in grado di fornire analytics e intelligence in merito al nostro sito web. Per maggiori informazioni su come Omniture raccoglie e utilizza le informazioni per conto di Accenture, consultare l\'informativa sulla privacy di Omniture relativa a prodotti e servizi all\'indirizzo <a title=\"Omniture site. Questo link apre una nuova finestra.\" href=\"http://www.omniture.com/privacy/product\" target=\"_blank\">www.omniture.com/privacy/product</a>.

<strong>Tecnologie di tracciamento senza cookie</strong> – Accenture impiega anche tecnologie che svolgono funzioni simili ai cookie, ma che possono non rispondere alle impostazioni del browser destinate all\'uso con i cookie. Si tratta di URL personalizzate (PURL), web beacon e altre tecnologie analoghe.
<div class=\"block-title iscrisscrossed\">
<h2>CONTATTI</h2>
</div>
<div class=\"ui-content-box \"><section class=\"container-block\">
<div class=\"col-sm-12\">
<div class=\"col-sm-2\"></div>
<div class=\"col-sm-8\">
<div class=\"component richtext\">

<strong>Domande/diritti/reclami in merito alla privacy dei dati</strong>

<a title=\"Domande/diritti/reclami. Questo link apre una nuova finestra.\" href=\"mailto:DataPrivacy@accenture.com\">Scriveteci una mail</a> se:
<ul>
 	<li>avete domande di carattere generale sul modo in cui Accenture protegge la riservatezza dei dati personali</li>
 	<li>desiderate esercitare i vostri diritti in materia di privacy dei dati (ad esempio ricevere una copia dei vostri dati personali in nostro possesso)</li>
 	<li>desiderate ricevere una copia della versione integrale della nostra policy sulla privacy o delle BCR</li>
 	<li>desiderate sporgere un reclamo in merito all\'uso dei vostri dati personali da parte di Accenture</li>
</ul>
<strong>Autorizzazioni relative a sito web/marketing e domande di carattere generale su Accenture</strong>

Utilizzate il form <a href=\"https://www.accenture.com/us-en/Home/BucketContent/CommonPages/contact-us.aspx\" target=\"_self\">Contattaci</a> se desiderate:
<ul>
 	<li>interrompere l\'invio di comunicazioni di marketing da parte nostra</li>
 	<li>far eliminare i vostri dati personali dal database CRM (Customer Relationship Management) Accenture oppure</li>
 	<li>sottoporre domande generiche relative ad Accenture.</li>
</ul>
Visualizzate un <a href=\"https://www.accenture.com/us-en/Home/BucketContent/Company-Content2/legal-countries-incorporation.aspx\" target=\"_self\">elenco dei paesi</a> in cui Accenture è presente.

</div>
</div>
</div>
</section></div>
</div>
</div>
</div>
</section></div>
</div>","Privacy","","inherit","closed","closed","","224-autosave-v1","","","2016-11-24 01:00:23","2016-11-24 00:00:23","","224","http://www.onyxsistemi.it/restyling/224-autosave-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("228","1","2016-11-24 01:04:10","2016-11-24 00:04:10","Sviluppatore Web","Claudio","","publish","open","open","","claudio","","","2016-11-24 01:04:56","2016-11-24 00:04:56","","0","http://www.onyxsistemi.it/restyling/?p=228","0","post","","0");
INSERT INTO `otot_posts` VALUES("229","1","2016-11-24 01:03:58","2016-11-24 00:03:58","","claudio","","inherit","open","closed","","claudio","","","2016-11-24 01:03:58","2016-11-24 00:03:58","","228","http://www.onyxsistemi.it/restyling/wp-content/uploads/2016/11/claudio.jpg","0","attachment","image/jpeg","0");
INSERT INTO `otot_posts` VALUES("230","1","2016-11-24 01:04:10","2016-11-24 00:04:10","Programmatore PHP","Claudio","","inherit","closed","closed","","228-revision-v1","","","2016-11-24 01:04:10","2016-11-24 00:04:10","","228","http://www.onyxsistemi.it/restyling/228-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("231","1","2016-11-24 01:04:56","2016-11-24 00:04:56","Sviluppatore Web","Claudio","","inherit","closed","closed","","228-revision-v1","","","2016-11-24 01:04:56","2016-11-24 00:04:56","","228","http://www.onyxsistemi.it/restyling/228-revision-v1/","0","revision","","0");
INSERT INTO `otot_posts` VALUES("234","1","2016-11-25 23:44:14","2016-11-25 22:44:14","Ascolta Radio 24, la radio de Il Sole 24 ORE: news, notiziari, borsa e guide in tempo reale. La radio online in formato mp3 e podcast scaricabili","Radio24 | Il Sole 24 ORE","","trash","closed","closed","","radio24-il-sole-24-ore__trashed","","","2016-11-27 00:34:42","2016-11-26 23:34:42","","0","http://www.onyxsistemi.it/restyling/annunci/radio24-il-sole-24-ore/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("235","1","2016-11-27 00:35:41","0000-00-00 00:00:00","","Bozza automatica","","auto-draft","closed","closed","","","","","2016-11-27 00:35:41","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?post_type=annunci&p=235","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("236","1","2016-11-27 00:36:42","2016-11-26 23:36:42","Ricerchiamo NEOLAUREATI IN INFORMATICA(n° 10 risorse)

Requisiti richiesti:

Laurea breve/specialistica in Ingegneria/Matematica/ Fisica
 

Costituisce elemento preferenziale la conoscenza della lingua inglese

Completano il profilo motivazione, determinazione e propensione al team working","NEOLAUREATI IN INFORMATICA (MI)","","publish","closed","closed","","neolaureati-in-informatica-mi","","","2016-11-27 00:36:42","2016-11-26 23:36:42","","0","http://www.onyxsistemi.it/restyling/annunci/neolaureati-in-informatica-mi/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("237","1","2016-11-27 00:37:45","2016-11-26 23:37:45","Ricerca Sviluppatori Java

Requisiti richiesti:

Formazione ad indirizzo informatico / tecnico;
Pregressa esperienza nel ruolo, almeno 1 anno di programmazione in ambito Java;
Buona conoscenza e capacità di utilizzo dei principali framework Java (Spring, Struts e Hibernate);
Costituisce elemento preferenziale il possesso di laurea;

Richiesta disponibilità per attività su Milano","Sviluppatori Java (Mi)","","publish","closed","closed","","sviluppatori-java-mi","","","2016-11-27 00:43:20","2016-11-26 23:43:20","","0","http://www.onyxsistemi.it/restyling/annunci/sviluppatori-java-mi/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("238","1","2016-11-27 00:39:14","2016-11-26 23:39:14","Ricerca Sviluppatori Java

Requisiti richiesti:

Formazione ad indirizzo informatico / tecnico;
Pregressa esperienza nel ruolo, almeno 1 anno di programmazione in ambito Java;
Buona conoscenza e capacità di utilizzo dei principali framework Java (Spring, Struts e Hibernate);
Costituisce elemento preferenziale il possesso di laurea;","Sviluppatori Java (RM)","","publish","closed","closed","","sviluppatori-java-rm","","","2016-11-27 00:44:13","2016-11-26 23:44:13","","0","http://www.onyxsistemi.it/restyling/annunci/sviluppatori-java-rm/","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("239","1","2016-11-27 00:39:19","0000-00-00 00:00:00","","Bozza automatica","","auto-draft","closed","closed","","","","","2016-11-27 00:39:19","0000-00-00 00:00:00","","0","http://www.onyxsistemi.it/restyling/?post_type=annunci&p=239","0","annunci","","0");
INSERT INTO `otot_posts` VALUES("240","1","2016-11-27 00:40:56","2016-11-26 23:40:56","Ricerca Project Manager con background tecnico di tipo sistemistico ed esperienza nel ruolo di almeno due anni. 

Costituisce elemento preferenziale l’esperienza in ambito telco/media.","Project Manager (Mi)","","publish","closed","closed","","project-manager-mi","","","2016-11-27 00:40:56","2016-11-26 23:40:56","","0","http://www.onyxsistemi.it/restyling/annunci/project-manager-mi/","0","annunci","","0");


DROP TABLE IF EXISTS `otot_term_relationships`;

CREATE TABLE `otot_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_term_relationships` VALUES("1","1","0");
INSERT INTO `otot_term_relationships` VALUES("100","9","0");
INSERT INTO `otot_term_relationships` VALUES("24","2","0");
INSERT INTO `otot_term_relationships` VALUES("28","2","0");
INSERT INTO `otot_term_relationships` VALUES("35","2","0");
INSERT INTO `otot_term_relationships` VALUES("31","2","0");
INSERT INTO `otot_term_relationships` VALUES("42","2","0");
INSERT INTO `otot_term_relationships` VALUES("38","2","0");
INSERT INTO `otot_term_relationships` VALUES("45","2","0");
INSERT INTO `otot_term_relationships` VALUES("51","2","0");
INSERT INTO `otot_term_relationships` VALUES("48","2","0");
INSERT INTO `otot_term_relationships` VALUES("82","4","0");
INSERT INTO `otot_term_relationships` VALUES("54","2","0");
INSERT INTO `otot_term_relationships` VALUES("57","2","0");
INSERT INTO `otot_term_relationships` VALUES("60","2","0");
INSERT INTO `otot_term_relationships` VALUES("69","3","0");
INSERT INTO `otot_term_relationships` VALUES("76","3","0");
INSERT INTO `otot_term_relationships` VALUES("82","5","0");
INSERT INTO `otot_term_relationships` VALUES("82","6","0");
INSERT INTO `otot_term_relationships` VALUES("82","7","0");
INSERT INTO `otot_term_relationships` VALUES("82","8","0");
INSERT INTO `otot_term_relationships` VALUES("130","2","0");
INSERT INTO `otot_term_relationships` VALUES("124","2","0");
INSERT INTO `otot_term_relationships` VALUES("127","2","0");
INSERT INTO `otot_term_relationships` VALUES("136","2","0");
INSERT INTO `otot_term_relationships` VALUES("133","2","0");
INSERT INTO `otot_term_relationships` VALUES("203","2","0");
INSERT INTO `otot_term_relationships` VALUES("139","2","0");
INSERT INTO `otot_term_relationships` VALUES("142","2","0");
INSERT INTO `otot_term_relationships` VALUES("145","2","0");
INSERT INTO `otot_term_relationships` VALUES("148","2","0");
INSERT INTO `otot_term_relationships` VALUES("151","2","0");
INSERT INTO `otot_term_relationships` VALUES("154","2","0");
INSERT INTO `otot_term_relationships` VALUES("157","2","0");
INSERT INTO `otot_term_relationships` VALUES("215","2","0");
INSERT INTO `otot_term_relationships` VALUES("206","2","0");
INSERT INTO `otot_term_relationships` VALUES("209","2","0");
INSERT INTO `otot_term_relationships` VALUES("212","2","0");
INSERT INTO `otot_term_relationships` VALUES("228","2","0");
INSERT INTO `otot_term_relationships` VALUES("218","2","0");
INSERT INTO `otot_term_relationships` VALUES("221","2","0");
INSERT INTO `otot_term_relationships` VALUES("237","10","0");
INSERT INTO `otot_term_relationships` VALUES("237","11","0");
INSERT INTO `otot_term_relationships` VALUES("237","12","0");
INSERT INTO `otot_term_relationships` VALUES("237","13","0");
INSERT INTO `otot_term_relationships` VALUES("237","14","0");
INSERT INTO `otot_term_relationships` VALUES("238","14","0");
INSERT INTO `otot_term_relationships` VALUES("238","10","0");
INSERT INTO `otot_term_relationships` VALUES("238","12","0");
INSERT INTO `otot_term_relationships` VALUES("238","13","0");
INSERT INTO `otot_term_relationships` VALUES("238","15","0");


DROP TABLE IF EXISTS `otot_term_taxonomy`;

CREATE TABLE `otot_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `otot_term_taxonomy` VALUES("2","2","category","Ogni singola voce relativa ai dipendenti di Onyx. Le foto inserite qui andranno nella pagina del Chi Siamo","0","32");
INSERT INTO `otot_term_taxonomy` VALUES("3","3","category","","0","2");
INSERT INTO `otot_term_taxonomy` VALUES("4","4","parole_chiave","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("5","5","parole_chiave","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("6","6","parole_chiave","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("7","7","parole_chiave","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("8","8","parole_chiave","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("11","11","parole_chiave","","0","1");
INSERT INTO `otot_term_taxonomy` VALUES("10","10","parole_chiave","","0","2");
INSERT INTO `otot_term_taxonomy` VALUES("9","9","category","","0","0");
INSERT INTO `otot_term_taxonomy` VALUES("12","12","parole_chiave","","0","2");
INSERT INTO `otot_term_taxonomy` VALUES("13","13","parole_chiave","","0","2");
INSERT INTO `otot_term_taxonomy` VALUES("14","14","parole_chiave","","0","2");
INSERT INTO `otot_term_taxonomy` VALUES("15","15","parole_chiave","","0","1");


DROP TABLE IF EXISTS `otot_termmeta`;

CREATE TABLE `otot_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `otot_terms`;

CREATE TABLE `otot_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_terms` VALUES("1","Senza categoria","senza-categoria","0");
INSERT INTO `otot_terms` VALUES("2","Dipendenti","dipendenti","0");
INSERT INTO `otot_terms` VALUES("3","Notizie","notizie","0");
INSERT INTO `otot_terms` VALUES("4","PHP","php","0");
INSERT INTO `otot_terms` VALUES("5","AngularJS","angularjs","0");
INSERT INTO `otot_terms` VALUES("6","jQuery","jquery","0");
INSERT INTO `otot_terms` VALUES("7","CSS3","css3","0");
INSERT INTO `otot_terms` VALUES("8","Javascript","javascript","0");
INSERT INTO `otot_terms` VALUES("9","Corsi di formazione","corsi-di-formazione","0");
INSERT INTO `otot_terms` VALUES("10","Java","java","0");
INSERT INTO `otot_terms` VALUES("11","Milano","milano","0");
INSERT INTO `otot_terms` VALUES("12","Spring","spring","0");
INSERT INTO `otot_terms` VALUES("13","Struts","struts","0");
INSERT INTO `otot_terms` VALUES("14","Hibernate","hibernate","0");
INSERT INTO `otot_terms` VALUES("15","Roma","roma","0");


DROP TABLE IF EXISTS `otot_usermeta`;

CREATE TABLE `otot_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_usermeta` VALUES("1","1","nickname","onyxadm");
INSERT INTO `otot_usermeta` VALUES("2","1","first_name","");
INSERT INTO `otot_usermeta` VALUES("3","1","last_name","");
INSERT INTO `otot_usermeta` VALUES("4","1","description","");
INSERT INTO `otot_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `otot_usermeta` VALUES("6","1","comment_shortcuts","false");
INSERT INTO `otot_usermeta` VALUES("7","1","admin_color","fresh");
INSERT INTO `otot_usermeta` VALUES("8","1","use_ssl","0");
INSERT INTO `otot_usermeta` VALUES("9","1","show_admin_bar_front","true");
INSERT INTO `otot_usermeta` VALUES("10","1","otot_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `otot_usermeta` VALUES("11","1","otot_user_level","10");
INSERT INTO `otot_usermeta` VALUES("12","1","dismissed_wp_pointers","addtoany_settings_pointer");
INSERT INTO `otot_usermeta` VALUES("13","1","show_welcome_panel","0");
INSERT INTO `otot_usermeta` VALUES("14","1","session_tokens","a:3:{s:64:\"687de00b6306f485f34d586adda054177d1ef56cb4257fd9d00d76b49fbc6881\";a:4:{s:10:\"expiration\";i:1480545246;s:2:\"ip\";s:13:\"151.28.239.94\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36\";s:5:\"login\";i:1479335646;}s:64:\"916e84aa37a260a67e4aaa5c444e7a81fdd9ec9a527747281d6b7a4078cd3c6d\";a:4:{s:10:\"expiration\";i:1480279011;s:2:\"ip\";s:12:\"151.25.7.255\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36\";s:5:\"login\";i:1480106211;}s:64:\"b7c9b00a29282503ff3c9e30473e1aab0b812ae507217f9f934ae3e605b9dfd0\";a:4:{s:10:\"expiration\";i:1480279011;s:2:\"ip\";s:12:\"151.25.7.255\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36\";s:5:\"login\";i:1480106211;}}");
INSERT INTO `otot_usermeta` VALUES("15","1","otot_dashboard_quick_press_last_post_id","232");
INSERT INTO `otot_usermeta` VALUES("23","2","first_name","Stefania");
INSERT INTO `otot_usermeta` VALUES("24","2","last_name","Romano");
INSERT INTO `otot_usermeta` VALUES("25","2","description","");
INSERT INTO `otot_usermeta` VALUES("26","2","rich_editing","true");
INSERT INTO `otot_usermeta` VALUES("16","1","closedpostboxes_post","a:0:{}");
INSERT INTO `otot_usermeta` VALUES("17","1","metaboxhidden_post","a:3:{i:0;s:13:\"trackbacksdiv\";i:1;s:16:\"commentstatusdiv\";i:2;s:9:\"authordiv\";}");
INSERT INTO `otot_usermeta` VALUES("18","1","closedpostboxes_page","a:0:{}");
INSERT INTO `otot_usermeta` VALUES("19","1","metaboxhidden_page","a:2:{i:0;s:16:\"commentstatusdiv\";i:1;s:9:\"authordiv\";}");
INSERT INTO `otot_usermeta` VALUES("20","1","otot_user-settings","hidetb=1&editor=tinymce&libraryContent=browse&editor_expand=off");
INSERT INTO `otot_usermeta` VALUES("21","1","otot_user-settings-time","1478020404");
INSERT INTO `otot_usermeta` VALUES("22","2","nickname","Stefania Romano");
INSERT INTO `otot_usermeta` VALUES("27","2","comment_shortcuts","false");
INSERT INTO `otot_usermeta` VALUES("28","2","admin_color","fresh");
INSERT INTO `otot_usermeta` VALUES("29","2","use_ssl","0");
INSERT INTO `otot_usermeta` VALUES("30","2","show_admin_bar_front","true");
INSERT INTO `otot_usermeta` VALUES("31","2","otot_capabilities","a:1:{s:6:\"editor\";b:1;}");
INSERT INTO `otot_usermeta` VALUES("32","2","otot_user_level","7");
INSERT INTO `otot_usermeta` VALUES("33","2","dismissed_wp_pointers","");
INSERT INTO `otot_usermeta` VALUES("54","1","itsec_user_activity_last_seen","1480265246");
INSERT INTO `otot_usermeta` VALUES("55","1","itsec-settings-view","grid");
INSERT INTO `otot_usermeta` VALUES("56","1","meta-box-order_dashboard","a:4:{s:6:\"normal\";s:48:\"aggiungi_annunci_a_dashboard,dashboard_right_now\";s:4:\"side\";s:58:\"dashboard_quick_press,dashboard_primary,dashboard_activity\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}");
INSERT INTO `otot_usermeta` VALUES("38","3","first_name","Guglielmo");
INSERT INTO `otot_usermeta` VALUES("39","3","last_name","Puglia");
INSERT INTO `otot_usermeta` VALUES("40","3","description","");
INSERT INTO `otot_usermeta` VALUES("41","3","rich_editing","true");
INSERT INTO `otot_usermeta` VALUES("34","2","session_tokens","a:1:{s:64:\"b1935d89a9904973d1955ec52efcc931275c79574a5d786da3efced5c7981e70\";a:4:{s:10:\"expiration\";i:1479313753;s:2:\"ip\";s:13:\"188.217.27.74\";s:2:\"ua\";s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0\";s:5:\"login\";i:1478104153;}}");
INSERT INTO `otot_usermeta` VALUES("37","3","nickname","Guglielmo Puglia");
INSERT INTO `otot_usermeta` VALUES("35","1","closedpostboxes_annunci","a:0:{}");
INSERT INTO `otot_usermeta` VALUES("36","1","metaboxhidden_annunci","a:0:{}");
INSERT INTO `otot_usermeta` VALUES("42","3","comment_shortcuts","false");
INSERT INTO `otot_usermeta` VALUES("43","3","admin_color","fresh");
INSERT INTO `otot_usermeta` VALUES("44","3","use_ssl","0");
INSERT INTO `otot_usermeta` VALUES("45","3","show_admin_bar_front","true");
INSERT INTO `otot_usermeta` VALUES("46","3","otot_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `otot_usermeta` VALUES("47","3","otot_user_level","10");
INSERT INTO `otot_usermeta` VALUES("48","3","dismissed_wp_pointers","");
INSERT INTO `otot_usermeta` VALUES("49","3","default_password_nag","");
INSERT INTO `otot_usermeta` VALUES("50","3","session_tokens","a:1:{s:64:\"feeb0f2f47f5a4612ba88d95b7e10f1ef709d35e437b39ff8e95c3eb4052a3f7\";a:4:{s:10:\"expiration\";i:1479301802;s:2:\"ip\";s:11:\"79.7.222.75\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0.1 Safari/602.2.14\";s:5:\"login\";i:1479129002;}}");
INSERT INTO `otot_usermeta` VALUES("51","3","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `otot_usermeta` VALUES("52","3","metaboxhidden_nav-menus","a:3:{i:0;s:21:\"add-post-type-annunci\";i:1;s:12:\"add-post_tag\";i:2;s:17:\"add-parole_chiave\";}");
INSERT INTO `otot_usermeta` VALUES("53","3","otot_dashboard_quick_press_last_post_id","196");
INSERT INTO `otot_usermeta` VALUES("57","1","closedpostboxes_dashboard","a:0:{}");
INSERT INTO `otot_usermeta` VALUES("58","1","metaboxhidden_dashboard","a:3:{i:0;s:19:\"dashboard_right_now\";i:1;s:21:\"dashboard_quick_press\";i:2;s:17:\"dashboard_primary\";}");


DROP TABLE IF EXISTS `otot_users`;

CREATE TABLE `otot_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `otot_users` VALUES("1","onyxadm","$P$BoFOESFrBrc81AuX3bnuOz350K1AGB/","onyxadm","c.alberti@onyxtechnology.it","","2016-10-03 13:37:30","","0","onyxadm");
INSERT INTO `otot_users` VALUES("2","Stefania Romano","$P$B47dFoyADKXC2LjvHCToglMXJ51GG3.","stefania-romano","s.romano@onyxtechnology.it","","2016-11-01 15:44:47","","0","Stefania Romano");
INSERT INTO `otot_users` VALUES("3","Guglielmo Puglia","$P$Be4UcMIrYCrLW8rLgl.mgfyoB64rJF/","guglielmo-puglia","g.puglia@onyxtechnology.it","","2016-11-12 20:09:59","","0","Guglielmo Puglia");




